#include "RT58xSerial.h"

RT58xSerial Serial0(0);
RT58xSerial Serial1(1);
RT58xSerial Serial2(2);

//=== Constructor ===
RT58xSerial::RT58xSerial(void)
{
    init(0);
}

RT58xSerial::RT58xSerial(int uart_id)
{
    init(uart_id);
}

//=== Private ===
void RT58xSerial ::init(int uart_id)
{
    this->uart_id = uart_id;
    switch (this->uart_id)
    {
    case 0:
        pin_set_mode(16, MODE_UART); /*GPIO16 as UART0 RX*/
        pin_set_mode(17, MODE_UART); /*GPIO17 as UART0 TX*/
        break;
    case 1:
        pin_set_mode(28, MODE_UART); /*GPIO28 as UART1 TX*/
        pin_set_mode(29, MODE_UART); /*GPIO29 as UART1 RX*/
        break;
    case 2:
        pin_set_mode(30, MODE_UART); /*GPIO30 as UART2 TX*/
        pin_set_mode(31, MODE_UART); /*GPIO31 as UART2 RX*/
        break;
    default:
        break;
    }
}

void RT58xSerial::deinit(void)
{
    uart_uninit(this->uart_id);
    enter_critical_section();
    circular_buf_free(this->rxBufHandle);
    circular_buf_free(this->txBufHandle);
    leave_critical_section();
}

void RT58xSerial::uart_event_handler(uint32_t event, void *p_context)
{
    if (event & UART_EVENT_TX_DONE)
    {
        // /*if you use multi-tasking, signal the waiting task here.*/
        RT58xSerial *pxSerial = (RT58xSerial *)p_context;
        if (circular_buf_get(pxSerial->txBufHandle, &pxSerial->sendOneByte) == 0)
        {
            uart_tx(pxSerial->uart_id, &pxSerial->sendOneByte, 1);
        }
    }

    if (event & UART_EVENT_RX_DONE)
    {
        /*if you use multi-tasking, signal the waiting task here.*/
        RT58xSerial *pxSerial = (RT58xSerial *)p_context;
        circular_buf_try_put(pxSerial->rxBufHandle, pxSerial->recvOneByte);
        uart_rx(pxSerial->uart_id, &pxSerial->recvOneByte, 1);
    }

    if (event & (UART_EVENT_RX_OVERFLOW | UART_EVENT_RX_BREAK |
                 UART_EVENT_RX_FRAMING_ERROR | UART_EVENT_RX_PARITY_ERROR))
    {
        // it's almost impossible for those error case.
        // do something ...
    }
}

void RT58xSerial::config(unsigned long buad, uint16_t config)
{
    enter_critical_section();
    this->rxBufHandle = circular_buf_init(this->rxBuf, sizeof(rxBuf));
    this->txBufHandle = circular_buf_init(this->txBuf, sizeof(txBuf));
    leave_critical_section();

    uart_config_t uart_cfg;

    /* init buad rate */
    uart_cfg.baudrate = (uart_baudrate_t)((2000000 * 2 + (buad >> 1)) / buad);
    switch (config & SERIAL_DATA_MASK)
    {
    case SERIAL_DATA_5:
        uart_cfg.databits = UART_DATA_BITS_5;
        break;
    case SERIAL_DATA_6:
        uart_cfg.databits = UART_DATA_BITS_6;
        break;
    case SERIAL_DATA_7:
        uart_cfg.databits = UART_DATA_BITS_7;
        break;
    case SERIAL_DATA_8:
    default:
        uart_cfg.databits = UART_DATA_BITS_8;
        break;
    }

    /* init parity */
    switch (config & SERIAL_PARITY_MASK)
    {
    case SERIAL_PARITY_EVEN:
        uart_cfg.parity = UART_PARITY_EVEN;
        break;
    case SERIAL_PARITY_ODD:
        uart_cfg.parity = UART_PARITY_ODD;
        break;
    case SERIAL_PARITY_MARK:
        uart_cfg.parity = UART_PARITY_MARK;
        break;
    case SERIAL_PARITY_SPACE:
        uart_cfg.parity = UART_PARITY_SPACE;
        break;
    case SERIAL_PARITY_NONE:
    default:
        uart_cfg.parity = UART_PARITY_NONE;
        break;
    }

    switch (config & SERIAL_STOP_BIT_MASK)
    {
    case SERIAL_STOP_BIT_2:
        uart_cfg.stopbit = UART_STOPBIT_TWO;
        break;
    case SERIAL_STOP_BIT_1:
    default:
        uart_cfg.stopbit = UART_STOPBIT_ONE;
        break;
        break;
    }

    uart_cfg.hwfc = UART_HWFC_DISABLED;

    /* Important: p_contex will be the second parameter in uart callback.
     * In this example, we do NOT use p_context, (So we just use uart_id for sample)
     * but you can use it for whaterever you want. (It can be NULL, too)
     */
    uart_cfg.p_context = this;
    uart_cfg.stopbit = UART_STOPBIT_ONE;
    uart_cfg.interrupt_priority = IRQ_PRIORITY_NORMAL;
    uart_init(this->uart_id, &uart_cfg, this->uart_event_handler);
    uart_rx(this->uart_id, &this->recvOneByte, 1);
}
