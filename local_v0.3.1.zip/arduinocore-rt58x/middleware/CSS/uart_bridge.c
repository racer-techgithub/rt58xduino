/**************************************************************************************************
 *    INCLUDES
 *************************************************************************************************/
 #include <stdio.h>

#include "string.h"
#include "cm3_mcu.h"
#include "project_config.h"

#include "uart_drv.h"
#include "retarget.h"

#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "queue.h"

#include "comm_subsystem_ahb_phy.h"
#include "rf_common_init.h"

#include "Ruci.h"

#include "uart_bridge.h"

//include ble fw header
/**************************************************************************************************
 *    MACROS
 *************************************************************************************************/
/**************************************************************************************************
 *    CONSTANTS AND DEFINES
 *************************************************************************************************/
#define UASB_SLEEP_ENABLE           (DISABLE)
#define UASB_APCI_ENABLE            (DISABLE)
#define UASB_BREAK_ENABLE           (DISABLE)
#define UASB_RX_PKT_DUMP_ENABLE     (DISABLE)
#define BLE_SANITY_WITH_PY          (1)
#define CHECK_RX_PACKET_CORRECT     (0)
#define UASB_COMM_Q_MAX_SIZE        (16u)
#define UASB_PCI_TXDONE_EVENT_ENABLE    (ENABLE)

/**************************************************************************************************
 *    TYPEDEFS
 *************************************************************************************************/
struct uasb_comm_cmd_state{
    uint8_t  rp;
    uint8_t  wp;
    uint8_t  cmd_queue[UASB_COMM_Q_MAX_SIZE];
};

typedef enum
{
    UASB_UART_RTS_SET = 0,
    UASB_UART_RTS_CLR
} uasb_uart_rts_status_t;

#define ms_sec(N)           (N*1000)
#ifndef GPIO_TEST_UB
#define GPIO_TEST_UB        (2)
#endif

/**************************************************************************************************
 *    GLOBAL VARIABLES
 *************************************************************************************************/
QueueHandle_t xrf_ub_uart_to_down_qhandle;
QueueHandle_t xrf_ub_down_to_uart_qhandle;
TaskHandle_t xrf_ub_uart_to_down_taskHandle;
TaskHandle_t xrf_ub_down_to_uart_taskHandle;

static struct ruci_hci_message_struct gruci_hci_message_tx_block;
static struct ble_hci_acl_data_sn_struct ghci_message_tx_data;
static uint8_t gble_comm_tx_sn;

uint8_t     guasb_comm_cmd_state;
struct      uasb_comm_cmd_state guasb_comm_cmd_state_q;

uint8_t     gUasbUartBuff[UASB_MAX_UART_LEN+10];       //no wrap around
uint8_t     gUasbUartTxBuff[UASB_MAX_UART_LEN+10];     //no wrap around
uint8_t     gUasbUart2SpiBuff[UASB_MAX_UART_LEN+10];      //no wrap around

volatile    uint8_t     gUasbUartTxStart;
volatile    uint8_t     gUasbSpiMutexTx;

uint8_t     guart_byte_data;
uint16_t    gUasbUartIdx;

uint16_t    gUasbTargetLen;
uint16_t    gUasbUart2SpicLen;

volatile    UASB_SPI_CTRL_STATE     gUasbSpiState;
uint8_t     gUasbMcuState;
uint8_t     gApciIntState;

volatile    uint8_t     gUasbRxReportCnt;

bool        gUasbPySanity = false;
bool        gUasbInterface = false;

/**************************************************************************************************
 *    EXTERN
 *************************************************************************************************/
extern void commsubsystem_disable_interrupt(void);
extern void commsubsystem_enable_interrupt(void);

void uasb_data_rx_parse(void);
bool uasb_rx_report_handle(void); //UASB_RxReportUartTx(void)
#if (UASB_SLEEP_ENABLE)
void uasb_gpiotest_isr(uint32_t pin, void *isr_param);
void uasb_dtu_sleep_ctrl(void);
void uasb_utd_sleep_ctrl(void);
#endif

/**************************************************************************************************
 *    LOCAL FUNCTIONS
 *************************************************************************************************/
void uasb_comm_add_state(uint8_t state){

    /* Igonre NONE state CMD add */
    if(state == 0)
    return;

    enter_critical_section();

    /* Check current space is available to add command */
    if(guasb_comm_cmd_state_q.cmd_queue[guasb_comm_cmd_state_q.wp] == 0){

        guasb_comm_cmd_state_q.cmd_queue[guasb_comm_cmd_state_q.wp] = state;

        /* update write point value and check if already wrap around */
        if((++guasb_comm_cmd_state_q.wp) == UASB_COMM_Q_MAX_SIZE){
            guasb_comm_cmd_state_q.wp = 0;
        }
    }
    else{
        BREAK();
    }

    leave_critical_section();

}

uint8_t uasb_comm_get_state(void){

    uint8_t ret, i = 0;

    //To Prevent This queue could be updated by ISR
    enter_critical_section();

    while (i < UASB_COMM_Q_MAX_SIZE)
    {
        i++;
        ret = guasb_comm_cmd_state_q.cmd_queue[guasb_comm_cmd_state_q.rp];
        if(ret!=0)
        {
            guasb_comm_cmd_state_q.cmd_queue[guasb_comm_cmd_state_q.rp] = 0;
            i = UASB_COMM_Q_MAX_SIZE;
        }

        if(++guasb_comm_cmd_state_q.rp == UASB_COMM_Q_MAX_SIZE)
        {
            guasb_comm_cmd_state_q.rp = 0;
        }

    }

    //Resume Interrupt
    leave_critical_section();

    return ret;
}

void uasb_comm_q_init(void){

    uint8_t i;

    guasb_comm_cmd_state_q.rp = 0;
    guasb_comm_cmd_state_q.wp = 0;

    for(i=0;i<UASB_COMM_Q_MAX_SIZE;i++){
        guasb_comm_cmd_state_q.cmd_queue[i] = 0;
    }
}

bool uasb_comm_queue_exists(void)
{
    bool queueExists = FALSE;

    enter_critical_section();

    if (guasb_comm_cmd_state_q.wp != guasb_comm_cmd_state_q.rp)
    {
        queueExists = TRUE;
    }

    leave_critical_section();

    return queueExists;
}

void wdt_init(void)
{
    wdt_config_mode_t wdt_mode;

    /*
     *Remark: We should set each field of wdt_mode.
     *Otherwise, some field will become undefined.
     *It could be BUG.
     */
    wdt_mode.int_enable = 0;
    wdt_mode.reset_enable = 1;
    wdt_mode.lock_enable = 1;
    wdt_mode.prescale = WDT_PRESCALE_32;        /* SYS_CLK/32. 1M Hz*/

    Wdt_Start(wdt_mode, ms_sec(50), 0, NULL);   /*0.5 seconds*/

}

void uasb_error_reboot(void)
{
#if (UASB_BREAK_ENABLE == ENABLE)
    BREAK();
#else
    enter_critical_section();
    wdt_init();
    BREAK();
#endif
}

void uasb_task_resume(void)
{
    vTaskResume(xrf_ub_uart_to_down_taskHandle);
    vTaskResume(xrf_ub_down_to_uart_taskHandle);
}

void uart1_isr(uint32_t event, void *p_context)
{

    /*Notice:
        UART_EVENT_TX_DONE  is for asynchronous mode send
        UART_EVENT_RX_DONE  is for synchronous  mode receive

        if system wants to use p_context as parameter, it can cast
        the type of p_context to original type.  like

        uint32_t  phandle;

        phandle = (uint32_t *) p_context;

     */

	if (event & UART_EVENT_TX_DONE) {
        /*if you use multi-tasking, signal the waiting task here.*/
        gUasbUartTxStart = 0;
    }

    if (event & UART_EVENT_RX_DONE) {

        /*if you use multi-tasking, signal the waiting task here.*/
        gUasbUartBuff[gUasbUartIdx++] = guart_byte_data;

        uart_rx(CHOOSE_UART, &guart_byte_data, 1);

#if (UASB_UART_HW_FC_SUPPORTED)
        if (gUasbUartIdx > UASB_MAX_UART_LEN/2) {
            /* Set RTS to wait for Local UART RX Buffer Available*/
            uart_set_modem_status(CHOOSE_UART, UASB_UART_RTS_SET);
        }
#endif

        //uasb_data_rx_parse();
        gpio_pin_toggle(22);

    }

    if (event & (UART_EVENT_RX_OVERFLOW | UART_EVENT_RX_BREAK |
            UART_EVENT_RX_FRAMING_ERROR | UART_EVENT_RX_PARITY_ERROR )) {

        //it's almost impossible for those error case.
        //do something ...
        if(event & UART_EVENT_RX_FRAMING_ERROR){

        }
        else{
            //wait WDT
            //while(1);
        }
    }

    #if (UASB_SLEEP_ENABLE == ENABLE)
    //uasb_task_resume();
    #endif

}

void uasb_uart_tx(uint16_t length)//UASB_Uart_Tx(uint16_t length)
{
    gUasbUartTxStart = 1;
    uart_tx(CHOOSE_UART, gUasbUartTxBuff, length);
}

bool uasb_uart_log_tx(uint8_t *str, uint16_t length)
{

    if(gUasbUartTxStart == 1){
        return false;
    }

    memcpy(gUasbUartTxBuff, str, length);
    uasb_uart_tx(length);

    return true;
}

void uasb_uart_init(bool baud_rate_high)
{
    static uint32_t  handle;

    uart_config_t  uart1_drv_config;

    /* uart buffer init */
    memset(gUasbUartBuff,0,UASB_MAX_UART_LEN+10);
    memset(gUasbUart2SpiBuff,0,UASB_MAX_UART_LEN+10);

    gUasbUartIdx = 0;
    gUasbTargetLen = 0;
    gUasbSpiMutexTx = 0;
    gUasbUart2SpicLen = 0;

    /*init uart1, 115200, 8bits 1 stopbit, none parity, no flow control.*/
    if(baud_rate_high == true){
        uart1_drv_config.baudrate = UART_BAUDRATE_1000000;//UART_BAUDRATE_1000000;//UART_BAUDRATE_115200;//UART_BAUDRATE_19200;//
    }
    else{
        uart1_drv_config.baudrate = UART_BAUDRATE_115200;//UART_BAUDRATE_19200;//
    }
    uart1_drv_config.databits = UART_DATA_BITS_8;
#if (UASB_UART_HW_FC_SUPPORTED)
    uart1_drv_config.hwfc     = UART_HWFC_ENABLED;
#else
    uart1_drv_config.hwfc     = UART_HWFC_DISABLED;
#endif
    uart1_drv_config.parity   = UART_PARITY_NONE;

    /* Important: p_contex will be the second parameter in uart callback.
     * In this example, we do NOT use p_context, (So we just use handle for sample)
     * but you can use it for whaterever you want. (It can be NULL, too)
     */
    handle = 0;
    uart1_drv_config.p_context = (void *) &handle;

    uart1_drv_config.stopbit  = UART_STOPBIT_ONE;
    uart1_drv_config.interrupt_priority = IRQ_PRIORITY_NORMAL;

    /* init uart 1*/
    uart_init(CHOOSE_UART, &uart1_drv_config, uart1_isr);
#if (UASB_UART_HW_FC_SUPPORTED)
    /* Initialized to clear RTS */
    uart_set_modem_status(CHOOSE_UART, UASB_UART_RTS_CLR);
#endif

    /* set uart 1 DMA RX buf */
    uart_rx(CHOOSE_UART, &guart_byte_data, 1);

}


#if (UASB_RX_PKT_DUMP_ENABLE)
#define BMU_PAGE_SIZE_BIT_SHIFT             (0x006)
#define BMU_PAGE_SIZE_BIT_MASK              (0x03f)
#define BMU_PAGE_SIZE                       (0x040)
#define MEM_BASE_ADDR_SHARED_BUFFER         (0x4000)
#define MEM_BASE_ADDR_BMU_LINK_TABLE        (0x5F80)
#define MEM_PKT_DUMP_BUF_SIZE               (0x0200)
#define REG_BMU_CFG                         (0x0010)
#define REG_NULL_CFG                        (0x0014)
#define REG_RX_PKT_HEAD                     (0x004C)
#define REG_RX_PKT_LEN                      (0x0054)
#define REG_RX_PKT_HEAD_VALID_LEN_MASK      (0x7F)
#define REG_COMMON_WORD_LEN                 (0x04)

uint8_t MAC_RX_PKT_BUF[MEM_PKT_DUMP_BUF_SIZE];

bool uasb_asserted = FALSE;

void uasb_get_mac_normal_rx_queue (uint32_t bufferLength, uint8_t *pOutput)
{
    uint32_t regTemp;
    uint16_t tempLength;
    uint16_t bufferAddress;
    uint16_t linkTableAddress;
    uint16_t pageNum;
    uint16_t loopIdx;
    uint16_t pInput;

    if (bufferLength) {
        tempLength = bufferLength;

        pageNum = ((tempLength + BMU_PAGE_SIZE_BIT_MASK) >> BMU_PAGE_SIZE_BIT_SHIFT);

        commsubsystem_read_memory_from_isr(REG_RX_PKT_HEAD, (uint8_t *)&regTemp, REG_COMMON_WORD_LEN);

        bufferAddress = (uint16_t)(regTemp & REG_RX_PKT_HEAD_VALID_LEN_MASK);

        for (loopIdx = 0; loopIdx < pageNum ; loopIdx++) {

            pInput = (uint16_t)(MEM_BASE_ADDR_SHARED_BUFFER + (bufferAddress << BMU_PAGE_SIZE_BIT_SHIFT));

            if (bufferLength > BMU_PAGE_SIZE)
                commsubsystem_read_memory_from_isr(pInput, pOutput, BMU_PAGE_SIZE);
            else
                commsubsystem_read_memory_from_isr(pInput, pOutput, (bufferLength + 3) & 0x04);

            pOutput += (BMU_PAGE_SIZE);
            tempLength = (tempLength >= BMU_PAGE_SIZE) ? tempLength - BMU_PAGE_SIZE : 0;

            linkTableAddress = MEM_BASE_ADDR_BMU_LINK_TABLE + bufferAddress;

            commsubsystem_read_memory_from_isr(linkTableAddress, (uint8_t *)&regTemp, REG_COMMON_WORD_LEN);

            bufferAddress = (uint16_t)(regTemp & REG_RX_PKT_HEAD_VALID_LEN_MASK);
        }

        printf("[UASB]: Mac Normal Rx Packet\r\n");

        pOutput = MAC_RX_PKT_BUF;

        for (loopIdx = 0; loopIdx < bufferLength/4 ; loopIdx++) {
            printf("[UASB]: 0x%x 0x%x 0x%x 0x%x\r\n",
                    pOutput[4*loopIdx+0],
                    pOutput[4*loopIdx+1],
                    pOutput[4*loopIdx+2],
                    pOutput[4*loopIdx+3]);
        }
    }
}


void uasb_get_mac_local_rx_queue (uint32_t bufferLength, uint8_t *pOutput)
{
    uint32_t regTemp;
    uint16_t bufferAddress;
    uint16_t loopIdx;
    uint16_t pInput;

    if (bufferLength) {

        commsubsystem_read_memory_from_isr(REG_NULL_CFG, (uint8_t *)&regTemp, REG_COMMON_WORD_LEN);

        bufferAddress = (uint16_t)((regTemp >> 8) & REG_RX_PKT_HEAD_VALID_LEN_MASK);

        pInput = (uint16_t)(MEM_BASE_ADDR_SHARED_BUFFER + (bufferAddress << BMU_PAGE_SIZE_BIT_SHIFT));

        commsubsystem_read_memory_from_isr(pInput, pOutput, BMU_PAGE_SIZE);

        printf("[UASB]: Mac Local Rx Packet\r\n");

        for (loopIdx = 0; loopIdx < bufferLength/4 ; loopIdx++) {
            printf("[UASB]: 0x%x 0x%x 0x%x 0x%x\r\n",
                    pOutput[4*loopIdx+0],
                    pOutput[4*loopIdx+1],
                    pOutput[4*loopIdx+2],
                    pOutput[4*loopIdx+3]);
        }
    }
}


void uasb_get_mac_rx_packet (void)
{
    uint32_t regTemp;
    uint16_t bufferLength;
    uint8_t *pOutput = MAC_RX_PKT_BUF;
    bool     isNullRxQ = FALSE;

    memset(MAC_RX_PKT_BUF, 0, sizeof(MAC_RX_PKT_BUF));

    commsubsystem_read_memory_from_isr(REG_BMU_CFG, (uint8_t *)&regTemp, REG_COMMON_WORD_LEN);

    isNullRxQ = (bool)(regTemp & BIT1);

    commsubsystem_read_memory_from_isr(REG_RX_PKT_LEN, (uint8_t *)&regTemp, REG_COMMON_WORD_LEN);

    if (bufferLength) {
        if (isNullRxQ) {
            bufferLength = (uint16_t)((regTemp >> 16) & 0x0FFF);
            printf("[UASB]: Mac Local Rx Packet Length:%d\r\n", bufferLength);
            uasb_get_mac_local_rx_queue(bufferLength, pOutput);
        } else {
            bufferLength = (uint16_t)(regTemp & 0x0FFF);
            printf("[UASB]: Mac Normal Rx Packet Length:%d\r\n", bufferLength);
            uasb_get_mac_normal_rx_queue(bufferLength, pOutput);
        }
    }
}


void uasb_assert_handler (void)
{
    uint32_t value;

    printf("[UASB]: Assert -\r\n");

    uasb_get_mac_rx_packet();

    commsubsystem_read_memory_from_isr(0x4008, (uint8_t *)&value, 4);

    uasb_asserted = TRUE;
}
#endif


/* Uart_Spi_Bridge ISR status handle function for RT569 SW Interrupt */
void uasb_isr(uint8_t intStatus)
{
    //uint8_t readSfr;

#if 0
    commsubsystem_host_wakeup();
    if(commsubsystem_check_power_state() != 0x03){
        /* FOR LEVEL TRIGGER ONLY, the MCU will keep entering INT if status not cleared */
        return;
    }
#endif

#if (UASB_APCI_ENABLE == ENABLE)
    // Status -----------------------------------------------------------------
    if (intStatus & (UASB_INT_CMD_DONE|UASB_INT_CMD_FAIL|UASB_INT_TX_DONE))
    {
        uasb_comm_add_state((UASB_INT_CMD_DONE|UASB_INT_CMD_FAIL|UASB_INT_TX_DONE));

        gApciIntState = intStatus;
        gUasbMcuState = (uint8_t)commsubsystem_read_mcu_state();
    }
#else
    // CMD --------------------------------------------------------------------
    if (intStatus & UASB_INT_CMD_DONE)
    {
        /* HCI Event */
        uasb_comm_add_state(UASB_INT_CMD_DONE);

        gUasbMcuState = (uint8_t)commsubsystem_read_mcu_state();
        commsubsystem_send_host_cmd(gUasbMcuState);

    }
    // Status -----------------------------------------------------------------
    if (intStatus & UASB_INT_TX_DONE)
    {
        uasb_comm_add_state(UASB_INT_TX_DONE);

        gUasbMcuState = (uint8_t)commsubsystem_read_mcu_state();
		commsubsystem_send_host_cmd(gUasbMcuState);
    }
#endif
    // Status -----------------------------------------------------------------
    if (intStatus & UASB_INT_SYS_ASSERT)
    {
#if (UASB_RX_PKT_DUMP_ENABLE)
        uasb_assert_handler();
#else
        uint32_t value;
        commsubsystem_mem_read(0x4008, (uint8_t *)&value, 4);
        while(1);
#endif

        //uasb_comm_add_state(UASB_INT_SYS_ASSERT);
        //BREAK();
    }

    // RX packet --------------------------------------------------------------
    if (intStatus & UASB_INT_RX_DONE)
    {
#if (UASB_RX_PKT_DUMP_ENABLE)
        if (!uasb_asserted)
#endif
        {
            uasb_comm_add_state(UASB_INT_RX_DONE);
        }
    }

#if 0   /* only under test 32K RCO mode */
    // RTC Wakeup --------------------------------------------------------------
    if (intStatus & UASB_INT_RTC_WAKE)
    {
        uasb_comm_add_state(UASB_INT_RTC_WAKE);
    }
#endif

    commsubsystem_clean_interrupt(intStatus);//Clean Interrupt

    #if (UASB_SLEEP_ENABLE == ENABLE)
    //uasb_task_resume();
    #endif

}

void uasb_data_rx_parse(void)
{
    bool is_uart_fail = false;
    uint8_t  u8RuciType;
    uint16_t u16DataLen = 0xFFFF;

    if(gUasbUartIdx == 0)return;

    u8RuciType = gUasbUartBuff[0];

    /*ready to check length */
    switch((u8RuciType&0xF0)>>4)
    {
        case RUCI_TYPE_PCI:  /* PCI */
            if(gUasbUartIdx >= UASB_PCI_LEN_OFFSET)
            {
                /* Get Length */
                if(u8RuciType != RUCI_PCI_DATA_HEADER)
                {
                    u16DataLen = gUasbUartBuff[UASB_RUCI_PCI_LEN_OFFST];
                    gUasbTargetLen = u16DataLen+UASB_RUCI_PCI_PARA_OFFST;
                }
                else if(gUasbUartIdx >= UASB_PCI_LEN_OFFSET+1)
                {
                    u16DataLen = gUasbUartBuff[UASB_RUCI_PCI_LEN_OFFST]|(gUasbUartBuff[UASB_RUCI_PCI_LEN_OFFST+1] << 8);
                    gUasbTargetLen = u16DataLen+UASB_RUCI_PCI_PARA_OFFST+1;   /* 2 byte len of DATA */
                }
            }
            break;
        case RUCI_TYPE_BLE:    /* HCI */

            if(u8RuciType != UASB_RUCI_HCI_CMD && u8RuciType != UASB_RUCI_ACL_DATA){
                is_uart_fail = true;
                break;
            }

            if(gUasbUartIdx >= UASB_HCI_LEN_SIZE)
            {
                /* Get Length */
                if(u8RuciType == UASB_RUCI_HCI_EVENT)   /* Event */
                {
                    u16DataLen = gUasbUartBuff[UASB_RUCI_HCI_EVENT_LEN_OFST];
                    gUasbTargetLen = u16DataLen+UASB_RUCI_HCI_EVENT_LEN_OFST+1;
                }
                else
                {
                    if(u8RuciType == UASB_RUCI_HCI_CMD && gUasbUartIdx >= UASB_HCI_LEN_SIZE+1)
                    {
                        u16DataLen = gUasbUartBuff[UASB_RUCI_HCI_CMD_DATA_LEN_OFST];
                        gUasbTargetLen = u16DataLen+UASB_RUCI_HCI_CMD_DATA_LEN_OFST+1;
                    }
                    else if(u8RuciType == UASB_RUCI_ACL_DATA && gUasbUartIdx >= UASB_HCI_LEN_SIZE+2)
                    {
                        u16DataLen = gUasbUartBuff[UASB_RUCI_HCI_CMD_DATA_LEN_OFST]|
                                     (gUasbUartBuff[UASB_RUCI_HCI_CMD_DATA_LEN_OFST+1] << 8);
                        gUasbTargetLen = u16DataLen+UASB_RUCI_HCI_CMD_DATA_LEN_OFST+2;
                    }
                }
            }
            break;
        case RUCI_TYPE_CMN:  /* CMN */
            if(gUasbUartIdx >= UASB_CMN_LEN_OFFSET)
            {
                u16DataLen = gUasbUartBuff[UASB_RUCI_CMN_LEN_OFFST];
                gUasbTargetLen = u16DataLen+UASB_RUCI_CMN_PARA_OFFST;
            }
            break;
        case RUCI_TYPE_SF:  /* SF */
            if(gUasbUartIdx >= UASB_SF_LEN_SIZE)
            {
                u16DataLen = gUasbUartBuff[UASB_RUCI_SF_LEN_OFST] + (gUasbUartBuff[UASB_RUCI_SF_LEN_OFST + 1] << 8);
                gUasbTargetLen = u16DataLen + UASB_SF_LEN_SIZE;

                if(u8RuciType != RUCI_CODE_IO_WRITE && u8RuciType != RUCI_CODE_MEM_WRITE){
                    if(gUasbTargetLen > 2120){
                        is_uart_fail = true;
                    }
                }

            }
            break;
#if (UASB_APCI_ENABLE == ENABLE)
        case RUCI_TYPE_APCI:  /* APCI */
            if(gUasbUartIdx >= UASB_PCI_LEN_OFFSET)
            {
                /* Get Length */
                if(gUasbUartIdx >= UASB_PCI_LEN_OFFSET+1)
                {
                    u16DataLen = gUasbUartBuff[UASB_RUCI_PCI_LEN_OFFST]|(gUasbUartBuff[UASB_RUCI_PCI_LEN_OFFST+1] << 8);
                    gUasbTargetLen = u16DataLen+UASB_RUCI_PCI_PARA_OFFST+1;   /* 2 byte len of DATA */
                }
            }
            break;
#endif
        default:
            //uasb_error_reboot();//BREAK();//while(1);   /* no matched command */
            //break;
            /* UART data error handling */
            is_uart_fail = true;
            break;
    }

    if(is_uart_fail == true || gUasbTargetLen > UASB_MAX_UART_LEN){
        enter_critical_section();
        gUasbUartIdx--;
        memcpy(gUasbUartBuff,gUasbUartBuff+1,gUasbUartIdx);
        leave_critical_section();
        return;
    }

    enter_critical_section();

    if(gUasbUartIdx >= gUasbTargetLen && gUasbTargetLen > 0)
    {
        /* all necessary data already received */
        /* notify function in UASB_Loop */

        if(gUasbSpiMutexTx == 0)
        {
            memcpy(gUasbUart2SpiBuff,gUasbUartBuff,gUasbTargetLen);
            gUasbUart2SpicLen = gUasbTargetLen;
        }
        else
        {
            BREAK();
        }

        /* clear UART Buffer */
        memset(gUasbUartBuff,0,gUasbTargetLen);

        /* copy remaining data in buffer */
        if(gUasbUartIdx-gUasbTargetLen)
        {
            memcpy(gUasbUartBuff,gUasbUartBuff+gUasbTargetLen,(gUasbUartIdx-gUasbTargetLen));
        }

        gUasbUartIdx -= gUasbTargetLen;

        gUasbTargetLen = 0;

    }

#if (UASB_UART_HW_FC_SUPPORTED)
    /* SW handled UART RX buffer, Clear RTS */
    uart_set_modem_status(CHOOSE_UART, UASB_UART_RTS_CLR);
#endif

    leave_critical_section();

    /* error handling for no enough length parameter */

    /* LED flashing */
    gpio_pin_clear(22);


}


#if (BLE_SANITY_WITH_PY)
#define TX_UART_DATA_WORKAROUND (TRUE)
uint8_t gAclDataBuf[UASB_MAX_UART_LEN+1];
uint8_t gAclSeqNo;

bool uasb_data_q_write569(uint8_t qId)// UASB_DataQWrite569(uint8_t qId)
{

    RF_MCU_TXQ_ERROR    tx_q_error = RF_MCU_TXQ_ERR_INIT;

    #if (TX_UART_DATA_WORKAROUND)
    uint32_t tx_data_idx;
    uint8_t tx_data_duplicate, tx_data_length;
    #endif

    /* to check state before issue TX send */
    commsubsystem_host_wakeup();
    if(commsubsystem_check_power_state() != 0x03){
        return false;
    }

    gAclSeqNo++;

    gAclDataBuf[0] = 0x02;
    gAclDataBuf[1] = gAclSeqNo;

    memcpy(&gAclDataBuf[2], &gUasbUart2SpiBuff[1], gUasbUart2SpicLen-1);

    #if (TX_UART_DATA_WORKAROUND)
    tx_data_length = (gAclDataBuf[4]);
    tx_data_duplicate = tx_data_length;

    for (tx_data_idx = 6 ; tx_data_idx < 6+tx_data_length ; tx_data_idx++) {
        if (gAclDataBuf[tx_data_idx] != tx_data_duplicate) {
            gAclDataBuf[tx_data_idx] = tx_data_duplicate;
        }
    }
    #endif

    tx_q_error = commsubsystem_send_tx_queue(qId, gAclDataBuf, gUasbUart2SpicLen+1);

    if(tx_q_error != RF_MCU_TXQ_SET_SUCCESS)
    {
        BREAK();
    }

    return true;
}
#else
#define TX_UART_DATA_WORKAROUND (FALSE)
#endif

bool uasb_ble_write_command(uint8_t *tx_data_ptr, uint8_t tx_data_len)
{
    #if 0
    /* to check state before issue TX send */
    commsubsystem_host_wakeup();
    if(commsubsystem_check_power_state() != 0x03){
        return false;
    }
    #else
    commsubsystem_host_wakeup();
    #endif

    if(commsubsystem_send_cmd_queue(tx_data_ptr, (uint32_t)tx_data_len) != RF_MCU_TX_CMDQ_SET_SUCCESS){

        /* command fail */
        uasb_error_reboot();
        //return false;
    }

    return true;
}

bool uasb_ble_write_tx_data(uint8_t *tx_data_ptr, uint16_t tx_data_len)
{
    uint32_t reg_val;
    uint8_t txq_id;
    RF_MCU_TXQ_ERROR tx_q_error;


    #if 0
    /* to check state before issue TX send */
    commsubsystem_host_wakeup();
    if(commsubsystem_check_power_state() != 0x03){
        return false;
    }
    #else
    commsubsystem_host_wakeup();
    #endif

    /* Check empty TXQ */
    commsubsystem_mem_read(0x0048, (uint8_t*)&reg_val, 4);

    if (!reg_val){
        uasb_error_reboot();//BREAK();
    }

    /* TX Q is Full */
    if((reg_val & 0x7F) == 0x00){
        return false;
    }

    for (txq_id = 0; txq_id < 7; txq_id++)
    {
        if (reg_val & (1 << txq_id))
            break;
    }

    /* Send data to TXQ */
    tx_q_error = RF_MCU_TXQ_ERR_INIT;
    tx_q_error = commsubsystem_send_tx_queue(txq_id,tx_data_ptr,tx_data_len);

    if(tx_q_error != RF_MCU_TXQ_SET_SUCCESS){
        //BREAK();
        uasb_error_reboot();
    }

    return true;

}

bool uasb_data_q_write(uint8_t qId, uint8_t *tx_data_ptr, uint16_t tx_data_len)// UASB_DataQWrite(uint8_t qId)
{
    // Send TX packet

    RF_MCU_TXQ_ERROR    tx_q_error = RF_MCU_TXQ_ERR_INIT;

    /* to check state before issue TX send */
    commsubsystem_host_wakeup();
    if(commsubsystem_check_power_state() != 0x03){
        return false;
    }

    tx_q_error = commsubsystem_send_tx_queue(qId, tx_data_ptr, (uint32_t)tx_data_len);

    if(tx_q_error != RF_MCU_TXQ_SET_SUCCESS)
    {
        //BREAK();
        uasb_error_reboot();
    }

    return true;

}

bool uasb_cmd_q_write(uint8_t *tx_data_ptr, uint8_t tx_data_len) //UASB_CmdQWrite(void)
{

    RF_MCU_TX_CMDQ_ERROR   txCmdqError = RF_MCU_TX_CMDQ_ERR_INIT;

    /* to check state before issue cmd send */
    commsubsystem_host_wakeup();
    if(commsubsystem_check_power_state() != 0x03){
        return false;
    }

    txCmdqError = commsubsystem_send_cmd_queue(tx_data_ptr, (uint32_t)tx_data_len);
    if(txCmdqError != RF_MCU_TX_CMDQ_SET_SUCCESS)
    {
        //BREAK();
        uasb_error_reboot();
    }

    return true;

}


uint16_t uasb_sf_sfr_read(void)// UASB_SfSfrRead(void)
{
    uint16_t cmdOutLen = SIZE_HEADER + SIZE_SUBHEADER + SIZE_RET_VALUE;
    sRUCI_PARA_SFR_READ     *pCmdIn, *pCmdOut;

    pCmdIn = (sRUCI_PARA_SFR_READ*)(gUasbUart2SpiBuff);
    pCmdOut = (sRUCI_PARA_SFR_READ*)(gUasbUartTxBuff);
    pCmdOut->RuciHeader.u8 = pCmdIn->RuciHeader.u8;
    pCmdOut->Subheader = pCmdIn->Subheader;
    if (pCmdIn->Addr > 0xF)
    {
        *((&pCmdOut->Subheader) + 1) = UASB_SF_CMD_FAIL;
        return (cmdOutLen);
    }

    cmdOutLen += 1;

    #if 0
    *((&pCmdOut->Subheader) + 1) = UASB_SF_CMD_SUCCESS;
    *((&pCmdOut->Subheader) + 2) = Rafael_SPI_SFR_Read(pCmdIn->Addr);
    return (cmdOutLen);
    #else
    /* the SFR read should be refine in RT57x */
    return 0;
    #endif

}

uint16_t uasb_sf_sfr_write(void)// UASB_SfSfrWrite(void)
{
    uint16_t cmdOutLen = SIZE_HEADER + SIZE_SUBHEADER + SIZE_RET_VALUE;
    sRUCI_PARA_SFR_WRITE    *pCmdIn, *pCmdOut;

    pCmdIn = (sRUCI_PARA_SFR_WRITE*)(gUasbUart2SpiBuff);
    pCmdOut = (sRUCI_PARA_SFR_WRITE*)(gUasbUartTxBuff);
    pCmdOut->RuciHeader.u8 = pCmdIn->RuciHeader.u8;
    pCmdOut->Subheader = pCmdIn->Subheader;
    if (pCmdIn->Addr > 0xF)
    {
        *((&pCmdOut->Subheader) + 1) = UASB_SF_CMD_FAIL;
        return (cmdOutLen);
    }

    #if 0
    *((&pCmdOut->Subheader) + 1) = UASB_SF_CMD_SUCCESS;
    Rafael_SPI_SFR_Write(pCmdIn->Addr, pCmdIn->Data);
    return (cmdOutLen);
    #else
    /* the SFR read should be refine in RT57x */
    return 0;
    #endif

}

uint16_t uasb_sf_io_read(void)// UASB_SfIoRead(void)
{
    uint16_t cmdOutLen = SIZE_HEADER + SIZE_SUBHEADER + SIZE_RET_VALUE;
    sRUCI_PARA_IO_READ      *pCmdIn, *pCmdOut;

    pCmdIn = (sRUCI_PARA_IO_READ*)(gUasbUart2SpiBuff);
    pCmdOut = (sRUCI_PARA_IO_READ*)(gUasbUartTxBuff);
    pCmdOut->RuciHeader.u8 = pCmdIn->RuciHeader.u8;
    pCmdOut->Subheader = pCmdIn->Subheader;
    if ((pCmdIn->DataLength > 2117) || (pCmdIn->DataLength > UASB_MAX_UART_LEN) || (pCmdIn->Qidx > 1))
    {
        *((&pCmdOut->Subheader) + 1) = UASB_SF_CMD_FAIL;
        return (cmdOutLen);
    }
    cmdOutLen += pCmdIn->DataLength;
    *((&pCmdOut->Subheader) + 1) = UASB_SF_CMD_SUCCESS;

    commsubsystem_io_read(pCmdIn->Qidx, ((&pCmdOut->Subheader) + 2), pCmdIn->DataLength);//Rafael_SPI_IO_Read(pCmdIn->Qidx, ((&pCmdOut->Subheader) + 2), pCmdIn->DataLength);

    return (cmdOutLen);
}

uint16_t uasb_sf_io_write(void)// UASB_SfIoWrite(void)
{
    uint16_t cmdOutLen = SIZE_HEADER + SIZE_SUBHEADER + SIZE_RET_VALUE;
    sRUCI_PARA_IO_WRITE     *pCmdIn, *pCmdOut;

    pCmdIn = (sRUCI_PARA_IO_WRITE*)(gUasbUart2SpiBuff);
    pCmdOut = (sRUCI_PARA_IO_WRITE*)(gUasbUartTxBuff);
    pCmdOut->RuciHeader.u8 = pCmdIn->RuciHeader.u8;
    pCmdOut->Subheader = pCmdIn->Subheader;
    if ((pCmdIn->DataLength > 2110) || (pCmdIn->DataLength > UASB_MAX_UART_LEN) || (pCmdIn->Qidx > 7))
    {
        *((&pCmdOut->Subheader) + 1) = UASB_SF_CMD_FAIL;
        return (cmdOutLen);
    }
    *((&pCmdOut->Subheader) + 1) = UASB_SF_CMD_SUCCESS;

    commsubsystem_io_write(pCmdIn->Qidx, pCmdIn->Data, pCmdIn->DataLength);//Rafael_SPI_IO_Write(pCmdIn->Qidx, pCmdIn->Data, pCmdIn->DataLength);

    return (cmdOutLen);
}

uint16_t uasb_sf_mem_read(void)// UASB_SfMemRead(void)
{
    uint16_t cmdOutLen = SIZE_HEADER + SIZE_SUBHEADER + SIZE_RET_VALUE;
    sRUCI_PARA_MEM_READ     *pCmdIn, *pCmdOut;

    pCmdIn = (sRUCI_PARA_MEM_READ*)(gUasbUart2SpiBuff);
    pCmdOut = (sRUCI_PARA_MEM_READ*)(gUasbUartTxBuff);
    pCmdOut->RuciHeader.u8 = pCmdIn->RuciHeader.u8;
    pCmdOut->Subheader = pCmdIn->Subheader;
    if ((pCmdIn->DataLength > 2048) || (pCmdIn->DataLength > UASB_MAX_UART_LEN))
    {
        *((&pCmdOut->Subheader) + 1) = UASB_SF_CMD_FAIL;
        return (cmdOutLen);
    }

    cmdOutLen += pCmdIn->DataLength;
    *((&pCmdOut->Subheader) + 1) = UASB_SF_CMD_SUCCESS;

    /* wake up IC before read memory */
    do{
        commsubsystem_host_wakeup();
    }while(commsubsystem_check_power_state() != 0x03);//while(commsubsystem_check_power_state() != 0x03);

    commsubsystem_mem_read(pCmdIn->Addr, ((&pCmdOut->Subheader) + 2), pCmdIn->DataLength);//Rafael_SPI_Memory_Read(pCmdIn->Addr, ((&pCmdOut->Subheader) + 2), pCmdIn->DataLength);

    return (cmdOutLen);

}

uint16_t uasb_sf_mem_write(void)// UASB_SfMemWrite(void)
{
    uint16_t cmdOutLen = SIZE_HEADER + SIZE_SUBHEADER + SIZE_RET_VALUE;
    sRUCI_PARA_MEM_WRITE    *pCmdIn, *pCmdOut;

    pCmdIn = (sRUCI_PARA_MEM_WRITE*)(gUasbUart2SpiBuff);
    pCmdOut = (sRUCI_PARA_MEM_WRITE*)(gUasbUartTxBuff);
    pCmdOut->RuciHeader.u8 = pCmdIn->RuciHeader.u8;
    pCmdOut->Subheader = pCmdIn->Subheader;
    if ((pCmdIn->DataLength > 2048) || (pCmdIn->DataLength > UASB_MAX_UART_LEN))
    {
        *((&pCmdOut->Subheader) + 1) = UASB_SF_CMD_FAIL;
        return (cmdOutLen);
    }
    *((&pCmdOut->Subheader) + 1) = UASB_SF_CMD_SUCCESS;

    /* wake up IC before write memory */
    do{
        commsubsystem_host_wakeup();
    }while(commsubsystem_check_power_state() != 0x03);

    commsubsystem_mem_write(pCmdIn->Addr, pCmdIn->Data, pCmdIn->DataLength);//Rafael_SPI_Memory_Write(pCmdIn->Addr, pCmdIn->Data, pCmdIn->DataLength);

    return (cmdOutLen);
}

uint16_t  uasb_sf_host_reg_read(void)
{
    uint16_t cmdOutLen = SIZE_HEADER + SIZE_SUBHEADER + SIZE_RET_VALUE;
    sRUCI_PARA_REG_READ     *pCmdIn, *pCmdOut;

    pCmdIn = (sRUCI_PARA_REG_READ*)(gUasbUart2SpiBuff);
    pCmdOut = (sRUCI_PARA_REG_READ*)(gUasbUartTxBuff);
    pCmdOut->RuciHeader.u8 = pCmdIn->RuciHeader.u8;
    pCmdOut->Subheader = pCmdIn->Subheader;
    cmdOutLen += 4;
    *((&pCmdOut->Subheader) + 1) = UASB_SF_CMD_SUCCESS;
    *((uint32_t*)((&pCmdOut->Subheader) + 2)) = inp32(pCmdIn->Addr);

    return (cmdOutLen);
}

uint16_t  uasb_sf_host_reg_write(void)
{
    uint16_t cmdOutLen = SIZE_HEADER + SIZE_SUBHEADER + SIZE_RET_VALUE;
    sRUCI_PARA_REG_WRITE    *pCmdIn, *pCmdOut;
    uint16_t    delayCnt;

    pCmdIn = (sRUCI_PARA_REG_WRITE*)(gUasbUart2SpiBuff);
    pCmdOut = (sRUCI_PARA_REG_WRITE*)(gUasbUartTxBuff);
    pCmdOut->RuciHeader.u8 = pCmdIn->RuciHeader.u8;
    pCmdOut->Subheader = pCmdIn->Subheader;
    *((&pCmdOut->Subheader) + 1) = UASB_SF_CMD_SUCCESS;
    outp32(pCmdIn->Addr, pCmdIn->Data);

    // Delay 100us for avoiding sleep mode issue
    for (delayCnt = 0; delayCnt < 32000; delayCnt++);

    return (cmdOutLen);
}

uint16_t  uasb_sf_host_pmu_cfg_by_rf(void)
{
    uint16_t cmdOutLen = SIZE_HEADER + SIZE_SUBHEADER + SIZE_RET_VALUE;
    sRUCI_PARA_PMU_CFG_BY_RF    *pCmdIn, *pCmdOut;

    pCmdIn = (sRUCI_PARA_PMU_CFG_BY_RF*)(gUasbUart2SpiBuff);
    pCmdOut = (sRUCI_PARA_PMU_CFG_BY_RF*)(gUasbUartTxBuff);
    pCmdOut->RuciHeader.u8 = pCmdIn->RuciHeader.u8;
    pCmdOut->Subheader = pCmdIn->Subheader;
    *((&pCmdOut->Subheader) + 1) = UASB_SF_CMD_FAIL; /* Not yet supported for RT58x */

    return (cmdOutLen);
}

/* MCU state of Host event */
void uasb_mcu_state_uart_tx(void)//UASB_McuStateUartTx(void)
{
    gUasbUartTxBuff[0] = RUCI_HOST_EVENT_HEADER;  /* RUCI Header */
    gUasbUartTxBuff[1] = RUCI_CODE_MCU_STATE;     /* RUCI subheader */
    gUasbUartTxBuff[2] = RUCI_PARA_LEN_MCU_STATE; /* Length */
    gUasbUartTxBuff[3] = gUasbMcuState;           /* MCU State */
    uasb_uart_tx(RUCI_LEN_MCU_STATE);
    gUasbMcuState = 0;
}

/* MCU state of Host event */
void uasb_apci_int_state_uart_tx(void)//UASB_ApciIntStateUartTx(void)
{
    gUasbUartTxBuff[0] = RUCI_HOST_EVENT_HEADER;  /* RUCI Header */
    gUasbUartTxBuff[1] = RUCI_CODE_APCI_INT_STATE;     /* RUCI subheader */
    gUasbUartTxBuff[2] = RUCI_PARA_LEN_APCI_INT_STATE; /* Length */
    gUasbUartTxBuff[3] = gApciIntState;
    gUasbUartTxBuff[4] = gUasbMcuState;           /* MCU State */
    uasb_uart_tx(RUCI_LEN_APCI_INT_STATE);
    gUasbMcuState = 0;
}

void uasb_ble_hdlr(void)//UASB_BleHdlr()
{

    pRUCI_HEAD pRuciHead = (pRUCI_HEAD)(gUasbUart2SpiBuff);

    uint16_t length;

    //allocate task q and deliver to donw to up task.
    struct ruci_hci_message_struct *ruci_hci_message_ptr;

    /* request memory */
    ruci_hci_message_ptr = pvPortMalloc(sizeof(struct ruci_hci_message_struct));

    switch (pRuciHead->u8)
    {
        case UASB_RUCI_ACL_DATA:
        case UASB_RUCI_HCI_CMD:
        length = gUasbUart2SpicLen;
        break;
        default:
            //BREAK();
            uasb_error_reboot();
    }

    memcpy(ruci_hci_message_ptr->ruci_hci_message.general_data_array,gUasbUart2SpiBuff,length);

    // deliver to DTU task
    while(xQueueSend(xrf_ub_down_to_uart_qhandle, (void *) &ruci_hci_message_ptr, (TickType_t) 0) != pdPASS);


}

void uasb_pci_hdlr(void)//UASB_PciHdlr()
{
    uint16_t length;
    //allocate task q and deliver to donw to up task.
    struct ruci_hci_message_struct *ruci_hci_message_ptr;

    /* request memory */
    ruci_hci_message_ptr = pvPortMalloc(sizeof(struct ruci_hci_message_struct));

    #if 0

    pRUCI_HEAD pRuciHead;
    pRuciHead = (pRUCI_HEAD)(gUasbUart2SpiBuff);

    switch (pRuciHead->u8)
    {
        case (RUCI_PCI_DATA_HEADER):
            while(uasb_data_q_write(0)!=true);//while(UASB_DataQWrite(0)!=true);
            break;

        default:
            while(uasb_cmd_q_write()!=true);//while(UASB_CmdQWrite()!=true);
            break;
    }
    #endif

    length = gUasbUart2SpicLen;
    memcpy(ruci_hci_message_ptr->ruci_hci_message.general_data_array,gUasbUart2SpiBuff,length);

    // deliver to DTU task
    while(xQueueSend(xrf_ub_down_to_uart_qhandle, (void *) &ruci_hci_message_ptr, (TickType_t) 0) != pdPASS);


}

void uasb_apci_hdlr(void)//UASB_ApciHdlr()
{
#if (UASB_APCI_ENABLE == ENABLE)

    pRUCI_HEAD pRuciHead;

    pRuciHead = (pRUCI_HEAD)(gUasbUart2SpiBuff);
    switch (pRuciHead->u8)
    {
        default:
            //while(uasb_cmd_q_write()!=true);//while(UASB_CmdQWrite()!=true);
            break;
    }
#endif

}

void uasb_cmn_hdlr(void)
{
    uint16_t length;
    //allocate task q and deliver to donw to up task.
    struct ruci_hci_message_struct *ruci_hci_message_ptr;

    /* request memory */
    ruci_hci_message_ptr = pvPortMalloc(sizeof(struct ruci_hci_message_struct));

    length = gUasbUart2SpicLen;
    memcpy(ruci_hci_message_ptr->ruci_hci_message.general_data_array,gUasbUart2SpiBuff,length);

    // deliver to DTU task
    while(xQueueSend(xrf_ub_down_to_uart_qhandle, (void *) &ruci_hci_message_ptr, (TickType_t) 0) != pdPASS);


}

void uasb_sf_hdlr(void)//UASB_SfHdlr(void)
{
    pRUCI_HEAD pRuciHead;
    uint16_t cmdOutLen;

    pRuciHead = (pRUCI_HEAD)(gUasbUart2SpiBuff);
    switch (pRuciHead->u8)
    {
        case (RUCI_HOST_CMD_HEADER):
            /* Command parser */
            switch (gUasbUart2SpiBuff[SIZE_HEADER])
            {
                case (RUCI_CODE_SFR_READ):
                    /* SFR read */
                    cmdOutLen = uasb_sf_sfr_read();//UASB_SfSfrRead();
                    break;
                case (RUCI_CODE_SFR_WRITE):
                    /* SFR write */
                    cmdOutLen = uasb_sf_sfr_write();//UASB_SfSfrWrite();
                    break;
                case (RUCI_CODE_IO_READ):
                    /* IO read */
                    cmdOutLen = uasb_sf_io_read();//UASB_SfIoRead();
                    break;
                case (RUCI_CODE_IO_WRITE):
                    /* IO write */
                    cmdOutLen = uasb_sf_io_write();//UASB_SfIoWrite();
                    break;
                case (RUCI_CODE_MEM_READ):
                    /* Memory read */
                    cmdOutLen = uasb_sf_mem_read();//UASB_SfMemRead();
                    break;
                case (RUCI_CODE_MEM_WRITE):
                    /* Memory write */
                    cmdOutLen = uasb_sf_mem_write();//UASB_SfMemWrite();
                    break;
                case (RUCI_CODE_REG_READ):
                    /* Host register read */
                    cmdOutLen = uasb_sf_host_reg_read();
                    break;
                case (RUCI_CODE_REG_WRITE):
                    /* Host register write */
                    cmdOutLen = uasb_sf_host_reg_write();
                    break;
                case (RUCI_CODE_PMU_CFG_BY_RF):
                    /* Host PMU configuration */
                    cmdOutLen = uasb_sf_host_pmu_cfg_by_rf();
                    break;
                default:
                    return;
            }
            break;
        default:
            uasb_error_reboot();//BREAK();
    }

    /* Command response */
    uasb_uart_tx(cmdOutLen);//UASB_Uart_Tx(cmdOutLen);

}

/* this check queue is used to confirm if any data from RF ready to transmit to UART */
void uasb_uart_to_down_check_queue(void)
{
    uint16_t tx_length;
    uint8_t transport_id;
    struct ruci_hci_message_struct *ruci_hci_message_ptr;
    //BaseType_t xQueRecCheck;

    if(gUasbUartTxStart == 1)return;

    //xQueRecCheck = xQueueReceive(xrf_ub_uart_to_down_qhandle, (void *) &ruci_hci_message_ptr, (TickType_t) 0);

    if(xQueueReceive(xrf_ub_uart_to_down_qhandle, (void *) &ruci_hci_message_ptr, (TickType_t) 0) == pdPASS){

        transport_id = ruci_hci_message_ptr->ruci_hci_message.general_data_array[0];

        switch(transport_id){
            case UASB_RUCI_ACL_DATA:
                /* count total length */
                tx_length = ruci_hci_message_ptr->ruci_hci_message.general_data_array[3]|
                    (ruci_hci_message_ptr->ruci_hci_message.general_data_array[4]<<8);
                #if (CHECK_RX_PACKET_CORRECT)
                    /* check RX data */
                    for(uint16_t i = 0 ; i < tx_length ; i++){
                        if(ruci_hci_message_ptr->ruci_hci_message.hci_acl_data.data[i] != (uint8_t)tx_length){
                            uasb_error_reboot();//while(1);
                        }
                    }
                #endif
                tx_length = tx_length + 1/*transport*/ + 2/*handle*/ + 2/*length*/;
                break;
		    case UASB_RUCI_HCI_EVENT:
                /* count total length */
                tx_length = ruci_hci_message_ptr->ruci_hci_message.general_data_array[2]
                    + 1/*transport*/ + 1/*event code*/ + 1/*length*/;
                break;
            case RUCI_PCI_EVENT_HEADER:
            case RUCI_CMN_EVENT_HEADER:
                tx_length = ruci_hci_message_ptr->ruci_hci_message.ruci_cmd.length + 3; /*RUCI Header + SubHeader + Length*/
            break;
            case RUCI_PCI_DATA_HEADER:
                tx_length = ruci_hci_message_ptr->ruci_hci_message.ruci_data.length + 4; /*RUCI Header + SubHeader + 2B Length*/
                if(tx_length > UASB_MAX_UART_LEN){
                    vPortFree(ruci_hci_message_ptr);
                    return;
                }
            break;
            default:
                uasb_error_reboot();//BREAK();
        }


        //enter_critical_section();

        //check transport type, check tx length, copy to uart tx buf
        memcpy(gUasbUartTxBuff,ruci_hci_message_ptr->ruci_hci_message.general_data_array,tx_length);

        vPortFree(ruci_hci_message_ptr);

        //trigger uart TX
        uasb_uart_tx(tx_length);

        //leave_critical_section();

    }

}

/* to handle data from UART to RF via Bus */
static void uasb_uart_to_down_task(void *parameters_ptr)
{
    pRUCI_HEAD pRuciHead;

    for(;;) {

        uasb_data_rx_parse();

        /* check if data from UART */
        if(gUasbUart2SpicLen)
        {
            gUasbSpiMutexTx = 1;
            pRuciHead = (pRUCI_HEAD)(gUasbUart2SpiBuff);

            /* trigger SPI to RT569 */
            switch(pRuciHead->bf.type)
            {
                case (RUCI_TYPE_BLE):
                    uasb_ble_hdlr();//UASB_BleHdlr();
                    break;
                case (RUCI_TYPE_PCI):
                    uasb_pci_hdlr();//UASB_PciHdlr();
                    break;
                case (RUCI_TYPE_APCI):
                    uasb_apci_hdlr();//UASB_ApciHdlr();
                    break;
                case (RUCI_TYPE_CMN):
                    uasb_cmn_hdlr();
                    break;
                case (RUCI_TYPE_SF):
                    uasb_sf_hdlr();//UASB_SfHdlr();
                    break;
                default:
                    uasb_error_reboot();//BREAK();
            }

            /* wait SPI done */
            memset(gUasbUart2SpiBuff,0,gUasbUart2SpicLen);
            gUasbUart2SpicLen = 0;
            gUasbSpiMutexTx = 0;

        }

        uasb_uart_to_down_check_queue();

#if (UASB_SLEEP_ENABLE == ENABLE)
        /* suspend */
        uasb_utd_sleep_ctrl();
#endif
    }

}


/* CMDR from BUS to UART */
void uasb_cmd_event_handle(void) //UASB_CmdEventUartTx(void)
{
    uint16_t volatile rxLen;
    RF_MCU_RX_CMDQ_ERROR   rxCmdError;
    struct ruci_hci_message_struct *ruci_hci_message_ptr;

    /* request memory */
    ruci_hci_message_ptr = pvPortMalloc(sizeof(struct ruci_hci_message_struct));

    /* read cmd queue */
    rxCmdError = RF_MCU_RX_CMDQ_ERR_INIT;
    rxLen = commsubsystem_read_cmd_queue(ruci_hci_message_ptr->ruci_hci_message.general_data_array,&rxCmdError);

    if (!rxLen && (rxCmdError != RF_MCU_RX_CMDQ_GET_SUCCESS))
    {
        uasb_error_reboot();//BREAK();
    }

    while(xQueueSend(xrf_ub_uart_to_down_qhandle, (void *) &ruci_hci_message_ptr, (TickType_t)0) != pdPASS);

}

/* TXDONE from BUS to UART */
void uasb_tx_done_event_handle(void)
{
#if (UASB_PCI_TXDONE_EVENT_ENABLE == ENABLE)
    struct ruci_hci_message_struct *ruci_hci_message_ptr;

    /* request memory */
    ruci_hci_message_ptr = pvPortMalloc(sizeof(struct ruci_hci_message_struct));

    /* generate TX done command by transport layer */
    ruci_hci_message_ptr->ruci_hci_message.general_data_array[0] = 0x16;
    ruci_hci_message_ptr->ruci_hci_message.general_data_array[1] = 0x01;
    ruci_hci_message_ptr->ruci_hci_message.general_data_array[2] = 0x03;
    ruci_hci_message_ptr->ruci_hci_message.general_data_array[3] = 0x17;
    ruci_hci_message_ptr->ruci_hci_message.general_data_array[4] = 0x01;
    ruci_hci_message_ptr->ruci_hci_message.general_data_array[5] = gUasbMcuState;

    while(xQueueSend(xrf_ub_uart_to_down_qhandle, (void *) &ruci_hci_message_ptr, (TickType_t)0) != pdPASS);
#endif

}

/* RX queue from SPI to UART */
bool uasb_rx_report_handle(void) //UASB_RxReportUartTx(void)
{
    uint16_t volatile   rxLen;
    RF_MCU_RXQ_ERROR        rx_queue_error;
    struct ruci_hci_message_struct *ruci_hci_message_ptr;
    //BaseType_t xHigherPriorityTaskWoken = pdFALSE;

    /* request memory */
    ruci_hci_message_ptr = pvPortMalloc(sizeof(struct ruci_hci_message_struct));

    if(ruci_hci_message_ptr == NULL){
        return false;
    }

    /* get data from RX Q*/
    rx_queue_error = RF_MCU_RXQ_ERR_INIT;

    rxLen = commsubsystem_read_rx_queue(ruci_hci_message_ptr->ruci_hci_message.general_data_array,&rx_queue_error);

    if (!rxLen && (rx_queue_error != RF_MCU_RXQ_GET_SUCCESS))
    {
        //uasb_error_reboot();
        vPortFree(ruci_hci_message_ptr);
        return false;
    }

    //while(xQueueSendFromISR(xrf_ub_uart_to_down_qhandle, (void *) &ruci_hci_message_ptr, &xHigherPriorityTaskWoken) != pdTRUE);
    while(xQueueSend(xrf_ub_uart_to_down_qhandle, (void *) &ruci_hci_message_ptr, (TickType_t)0) != pdPASS);

    return true;

}

uint32_t update_cnt = 0;
void uasb_rtc_wakeup_handle(void)
{
#if 0
#if 0
    uint32_t reg_val;

    if(((update_cnt++) % 10)==0){
        printf("\r\n58xreg:0x40200034:0x%08X",inp32(0x40200034));
        /* confirm PMU setting of 569 */
        commsubsystem_mem_read(0x0418, (uint8_t*)&reg_val, 4);
        printf("\r\n569reg:0x418:0x%08X",reg_val);
    }
    else{
        printf("#");
    }
#else
    printf("#");
#endif
#endif
}

void uasb_down_to_uart_check_queue(void)
{
    uint8_t transport_id,ruci_hci_cmd_length;
    uint16_t ruci_hci_acl_data_length;
    struct ruci_hci_message_struct *ruci_hci_message_ptr;

    //actually, it is safer to check if the data to RF is done or not.
    //if(check_rf_write_status()!= true)return;

    /* Peek if it's a HCI command, and return if command queue is full */
    if (xQueuePeek(xrf_ub_down_to_uart_qhandle, (void *) &ruci_hci_message_ptr,
                   (TickType_t) 0) == pdPASS)
    {
        transport_id = ruci_hci_message_ptr->ruci_hci_message.general_data_array[0];

        switch (transport_id)
        {
            case UASB_RUCI_HCI_CMD:
                if (commsubsystem_check_cmd_queue_full())
                {
                    return;
                }
                break;

            default:
                break;
        }
    }
    else
    {
        return;
    }

    if(xQueueReceive(xrf_ub_down_to_uart_qhandle, (void *) &ruci_hci_message_ptr, (TickType_t) 0) == pdPASS){

        transport_id = ruci_hci_message_ptr->ruci_hci_message.general_data_array[0];

        memcpy((uint8_t*)&gruci_hci_message_tx_block,(uint8_t*)ruci_hci_message_ptr,sizeof(struct ruci_hci_message_struct));

        switch (transport_id)
        {
		    case UASB_RUCI_HCI_CMD:
                /* count total length */
                ruci_hci_cmd_length = ruci_hci_message_ptr->ruci_hci_message.hci_command.length
                    + 1/*transport*/ + 2/*opcode*/ + 1/*length*/;

                while(uasb_ble_write_command((uint8_t*)&gruci_hci_message_tx_block,ruci_hci_cmd_length)!= true);
            break;
            case UASB_RUCI_ACL_DATA:

                /* add sequence number*/
                ghci_message_tx_data.transport_id = UASB_RUCI_ACL_DATA;
                ghci_message_tx_data.sequence = gble_comm_tx_sn;
                ghci_message_tx_data.handle = ruci_hci_message_ptr->ruci_hci_message.hci_acl_data.handle;
                ghci_message_tx_data.pb_flag = ruci_hci_message_ptr->ruci_hci_message.hci_acl_data.pb_flag;
                ghci_message_tx_data.bc_flag = ruci_hci_message_ptr->ruci_hci_message.hci_acl_data.bc_flag;
                ghci_message_tx_data.length = ruci_hci_message_ptr->ruci_hci_message.hci_acl_data.length;

                if(gUasbPySanity == true){
                    memset(ghci_message_tx_data.data,(uint8_t)(ghci_message_tx_data.length&0xFF),ghci_message_tx_data.length);
                }
                else{
                    memcpy(ghci_message_tx_data.data,ruci_hci_message_ptr->ruci_hci_message.hci_acl_data.data,ghci_message_tx_data.length);
                }

                /* count total length */
                ruci_hci_acl_data_length = ruci_hci_message_ptr->ruci_hci_message.hci_acl_data.length
                    + 1/*transport*/ + 1/* sequence */ + 2/*handle*/ + 2/*length*/;

                while(uasb_ble_write_tx_data((uint8_t*)&ghci_message_tx_data,ruci_hci_acl_data_length)!= true);

                gble_comm_tx_sn++;

            break;
            case RUCI_PCI_COMMON_CMD_HEADER:
            case RUCI_PCI_FSK_CMD_HEADER:
            case RUCI_PCI_BLE_CMD_HEADER:
            case RUCI_PCI15P4_MAC_CMD_HEADER:
            case RUCI_PCI_OQPSK_CMD_HEADER:
            case RUCI_CMN_SYS_CMD_HEADER:
            case RUCI_CMN_HAL_CMD_HEADER:

                /* count total length */
                ruci_hci_cmd_length = ruci_hci_message_ptr->ruci_hci_message.ruci_cmd.length+3; /*RUCI Header + SubHeader + 1B Length */
                while(uasb_cmd_q_write((uint8_t*)&gruci_hci_message_tx_block,ruci_hci_cmd_length)!= true);

            break;
            case RUCI_PCI_DATA_HEADER:
                ruci_hci_acl_data_length = ruci_hci_message_ptr->ruci_hci_message.ruci_data.length + 4; /*RUCI Header + SubHeader + 2B Length */
                while(uasb_data_q_write(0,(uint8_t*)&gruci_hci_message_tx_block,ruci_hci_acl_data_length)!= true);

            break;
            default:
                BREAK();
        }

        vPortFree(ruci_hci_message_ptr);

    }

}

void usab_check_state(void)
{
    uint8_t hci_state = uasb_comm_get_state();

    switch(hci_state){
        case UASB_INT_NO_STS:
        break;
        case UASB_INT_CMD_DONE:
            uasb_cmd_event_handle();
        break;
        case UASB_INT_TX_DONE:
            uasb_tx_done_event_handle();
        break;
        case UASB_INT_SYS_ASSERT:
        break;
        case UASB_INT_CMD_FAIL:
        break;
        case UASB_INT_RX_DONE:
            uasb_rx_report_handle();
        break;
        case UASB_INT_RTC_WAKE:
            uasb_rtc_wakeup_handle();
        break;
        default:
        BREAK();
    }

}

bool uasb_allow_task_suspend(void)
{
    bool allowSuspend = FALSE;

    //portENTER_CRITICAL();
    if ((uxQueueMessagesWaiting(xrf_ub_down_to_uart_qhandle) == 0) &&
        (uxQueueMessagesWaiting(xrf_ub_uart_to_down_qhandle) == 0) &&
        (gUasbUart2SpicLen == 0) &&
        (gUasbUartIdx == 0) &&
        (!uasb_comm_queue_exists()))
    {
        allowSuspend = TRUE;
    }
    //portEXIT_CRITICAL();

    return allowSuspend;
}

/* to handle data from RF to UART */
static void uasb_down_to_uart_task(void *parameters_ptr)
{
    for(;;) {
        usab_check_state();
        uasb_down_to_uart_check_queue();

#if (UASB_SLEEP_ENABLE == ENABLE)
        /* suspend */
        uasb_dtu_sleep_ctrl();
#endif
    }

}


#if (UASB_SLEEP_ENABLE)
uint32_t gpio_retent_table[MAX_NUMBER_OF_PINS];
void uasb_gpio_push_all(void)
{
    uint32_t volatile gpio_id = 0;
    for (gpio_id = 0 ; gpio_id < MAX_NUMBER_OF_PINS ; gpio_id++)
    {
        gpio_retent_table[gpio_id] = pin_get_mode(gpio_id);
    }
}

void uasb_gpio_pop_all(void)
{
    uint32_t volatile gpio_id = 0;
    for (gpio_id = 0 ; gpio_id < MAX_NUMBER_OF_PINS ; gpio_id++)
    {
        pin_set_mode(gpio_id, gpio_retent_table[gpio_id]);
    }
}


void uasb_gpio_sleep_all(void)
{
    uint32_t volatile gpio_id = 0;
    uint32_t volatile retry_times = 2;

    while (retry_times)
    {
        retry_times--;
        for (gpio_id = 0 ; gpio_id < MAX_NUMBER_OF_PINS ; gpio_id++)
        {
            if (gpio_id != GPIO_TEST_UB)
            {
                pin_set_mode(gpio_id, MODE_GPIO);
                gpio_cfg_input(gpio_id, GPIO_PIN_NOINT);
                pin_set_pullopt(gpio_id, PULL_UP_100K);
            }
        }
    }
}


void uasb_gpiotest_isr(uint32_t pin, void *isr_param)
{
    BaseType_t yieldRequired = pdFALSE;
    /* test if real wake up by IO */
    Lpm_Set_Low_Power_Level(LOW_POWER_LEVEL_NORMAL);
    Lpm_Low_Power_Mask(LOW_POWER_MASK_BIT_RESERVED31);

    yieldRequired |= xTaskResumeFromISR(xrf_ub_down_to_uart_taskHandle);
    yieldRequired |= xTaskResumeFromISR(xrf_ub_uart_to_down_taskHandle);
    portYIELD_FROM_ISR(yieldRequired);

    uasb_gpio_pop_all();
}


void uasb_dtu_sleep_ctrl(void)
{
    if ((gpio_pin_get(GPIO_TEST_UB) == 1) &&
        uasb_allow_task_suspend())
    {
        if (Lpm_Get_Low_Power_Mask_Status() == LOW_POWER_NO_MASK)
        {
            uasb_gpio_push_all();
            uasb_gpio_sleep_all();
        }
        Lpm_Set_Low_Power_Level(LOW_POWER_LEVEL_SLEEP0);
        Lpm_Low_Power_Unmask(LOW_POWER_MASK_BIT_RESERVED31);

        /* suspend until no more event */
        vTaskSuspend(xrf_ub_down_to_uart_taskHandle);
    }
}


void uasb_utd_sleep_ctrl(void)
{
    if ((gpio_pin_get(GPIO_TEST_UB) == 1) &&
        uasb_allow_task_suspend())
    {
        if (Lpm_Get_Low_Power_Mask_Status() == LOW_POWER_NO_MASK)
        {
            uasb_gpio_push_all();
            uasb_gpio_sleep_all();
        }
        Lpm_Set_Low_Power_Level(LOW_POWER_LEVEL_SLEEP0);
        Lpm_Low_Power_Unmask(LOW_POWER_MASK_BIT_RESERVED31);

        /* suspend until no more event */
        vTaskSuspend(xrf_ub_uart_to_down_taskHandle);
    }
}

void usab_sleep_gpio_init(void)
{
    /*set GPIO20 for gpio input wakeup source*/
    pin_set_mode(GPIO_TEST_UB, MODE_GPIO);

    /*In this example,  GPIO20 falling edge will generate wakeup interrupt*/
    pin_set_pullopt(GPIO_TEST_UB, PULL_UP_100K);

    gpio_cfg_input(GPIO_TEST_UB, GPIO_PIN_INT_EDGE_FALLING);

    gpio_register_isr(GPIO_TEST_UB, uasb_gpiotest_isr, NULL);

    /*enable gpio20 pin for interrupt source*/
    gpio_int_enable(GPIO_TEST_UB);

    /*enable debounce for GPIO20*/
    gpio_set_debounce_time(DEBOUNCE_SLOWCLOCKS_1024);
    gpio_debounce_enable(GPIO_TEST_UB);

    if (GPIO_TEST_UB == 2)
    {
        Lpm_Enable_Low_Power_Wakeup(LOW_POWER_WAKEUP_GPIO2);
    }
    else
    {
        /* implement other wakeup source here */
        BREAK();
    }
}
#endif


/**************************************************************************************************
 *    GLOBAL FUNCTIONS
 *************************************************************************************************/
void uasb_ble_sanity_set(bool py_sanity_en)
{
    gUasbPySanity = py_sanity_en;
}

void uasb_init_cmd_interface(RF_FW_LOAD_SELECT fw_select, bool init_interfrace_en)
{
    if(init_interfrace_en == true){
        rf_common_init_by_fw(fw_select,uasb_isr);
        gUasbInterface = true;
    }
    else{
        gUasbInterface = false;
    }
}
void uasb_init(bool baud_rate_high)
{

    uasb_comm_q_init();

    commsubsystem_dma_init();

#if (UASB_SLEEP_ENABLE)
    usab_sleep_gpio_init();
#endif

    /* init RF with BLE Controller FW */
    // rf_common_init_by_fw(RF_FW_LOAD_SELECT_BLE_CONTROLLER,uasb_isr);

    /* init UART */
    uasb_uart_init(baud_rate_high);

    /* init control state */
    gUasbSpiState = UASB_SPI_CTRL_INIT;

    gble_comm_tx_sn = 0;

    gUasbRxReportCnt = 0;

    gUasbPySanity = false;

    xrf_ub_uart_to_down_qhandle = xQueueCreate(30, sizeof(struct ruci_hci_message_struct *));
    xTaskCreate(uasb_uart_to_down_task, "TASK_RF_UB_UP_TO_DOWN", 1024, NULL, tskHIGH_PRIORITY, &xrf_ub_uart_to_down_taskHandle);

    xrf_ub_down_to_uart_qhandle = xQueueCreate(30, sizeof(struct ruci_hci_message_struct *));
    xTaskCreate(uasb_down_to_uart_task, "TASK_RF_UB_DOWN_TO_UP", 1024, NULL, tskHIGH_PRIORITY, &xrf_ub_down_to_uart_taskHandle);

}

