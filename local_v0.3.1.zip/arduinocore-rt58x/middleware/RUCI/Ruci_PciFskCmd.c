/******************************************************************************
*
* @File			Ruci_PciFskCmd.c
* @Version
* $Revision:4235
* $Date: 2022-02-07
* @Brief
* @Note
* Copyright (C) 2019 Rafael Microelectronics Inc. All rights reserved.
*
*****************************************************************************/

/******************************************************************************
* INCLUDES
******************************************************************************/
#include "Ruci_PciFskCmd.h"

#if (RUCI_ENDIAN_INVERSE)
#if (RUCI_ENABLE_PCI)

/******************************************************************************
* GLOBAL PARAMETERS
******************************************************************************/
// RUCI: InitiateFsk -----------------------------------------------------------
const uint8_t Ruci_ElmtType_InitiateFsk[] = {
    1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_InitiateFsk[] = {
    1, 1, 1, 1
};

// RUCI: SetFskModem -----------------------------------------------------------
const uint8_t Ruci_ElmtType_SetFskModem[] = {
    1, 1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetFskModem[] = {
    1, 1, 1, 1, 1
};

// RUCI: SetFskMac -------------------------------------------------------------
const uint8_t Ruci_ElmtType_SetFskMac[] = {
    1, 1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetFskMac[] = {
    1, 1, 1, 1, 1
};

// RUCI: SetFskPreamble --------------------------------------------------------
const uint8_t Ruci_ElmtType_SetFskPreamble[] = {
    1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetFskPreamble[] = {
    1, 1, 1, 1
};

// RUCI: SetFskSfd -------------------------------------------------------------
const uint8_t Ruci_ElmtType_SetFskSfd[] = {
    1, 1, 1, 4
};
const uint8_t Ruci_ElmtNum_SetFskSfd[] = {
    1, 1, 1, 1
};

#endif /* RUCI_ENABLE_PCI */
#endif /* RUCI_ENDIAN_INVERSE */
