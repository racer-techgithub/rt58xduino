/******************************************************************************
*
* @File			Ruci_HostEvent.c
* @Version
* $Revision:4235
* $Date: 2022-02-07
* @Brief
* @Note
* Copyright (C) 2019 Rafael Microelectronics Inc. All rights reserved.
*
*****************************************************************************/

/******************************************************************************
* INCLUDES
******************************************************************************/
#include "Ruci_HostEvent.h"

#if (RUCI_ENDIAN_INVERSE)
#if (RUCI_ENABLE_SF)

/******************************************************************************
* GLOBAL PARAMETERS
******************************************************************************/
// RUCI: McuState --------------------------------------------------------------
const uint8_t Ruci_ElmtType_McuState[] = {
    1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_McuState[] = {
    1, 1, 1, 1
};

// RUCI: HostCnfEvent ----------------------------------------------------------
const uint8_t Ruci_ElmtType_HostCnfEvent[] = {
    1, 1, 1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_HostCnfEvent[] = {
    1, 1, 1, 1, 1, 1
};

// RUCI: ApciIntState ----------------------------------------------------------
const uint8_t Ruci_ElmtType_ApciIntState[] = {
    1, 1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_ApciIntState[] = {
    1, 1, 1, 1, 1
};

#endif /* RUCI_ENABLE_SF */
#endif /* RUCI_ENDIAN_INVERSE */
