/******************************************************************************
*
* @File			Ruci_HostCmd.h
* @Version
* $Revision: 4235
* $Date: 2022-02-07
* @Brief
* @Note
* Copyright (C) 2019 Rafael Microelectronics Inc. All rights reserved.
*
******************************************************************************/
#ifndef _RUCI_HOST_CMD_H
#define _RUCI_HOST_CMD_H

#include "Ruci_Head.h"

#if (RUCI_ENABLE_SF)

/******************************************************************************
* DEFINES
*****************************************************************************/

#pragma pack(push)
#pragma pack(1)
#define RUCI_HOST_CMD_HEADER 0xF0

// RUCI: SfrRead ---------------------------------------------------------------
#define RUCI_SFR_READ                           RUCI_NUM_SFR_READ, Ruci_ElmtType_SfrRead, Ruci_ElmtNum_SfrRead
#define RUCI_CODE_SFR_READ                      0x01
#define RUCI_LEN_SFR_READ                       5
#define RUCI_NUM_SFR_READ                       4
#define RUCI_PARA_LEN_SFR_READ                  1
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SfrRead[];
extern const uint8_t Ruci_ElmtNum_SfrRead[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SFR_READ {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint16_t        Length;
    uint8_t         Addr;
} sRUCI_PARA_SFR_READ;

// RUCI: SfrWrite --------------------------------------------------------------
#define RUCI_SFR_WRITE                          RUCI_NUM_SFR_WRITE, Ruci_ElmtType_SfrWrite, Ruci_ElmtNum_SfrWrite
#define RUCI_CODE_SFR_WRITE                     0x02
#define RUCI_LEN_SFR_WRITE                      6
#define RUCI_NUM_SFR_WRITE                      5
#define RUCI_PARA_LEN_SFR_WRITE                 2
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SfrWrite[];
extern const uint8_t Ruci_ElmtNum_SfrWrite[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SFR_WRITE {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint16_t        Length;
    uint8_t         Addr;
    uint8_t         Data;
} sRUCI_PARA_SFR_WRITE;

// RUCI: IoRead ----------------------------------------------------------------
#define RUCI_IO_READ                            RUCI_NUM_IO_READ, Ruci_ElmtType_IoRead, Ruci_ElmtNum_IoRead
#define RUCI_CODE_IO_READ                       0x03
#define RUCI_LEN_IO_READ                        7
#define RUCI_NUM_IO_READ                        5
#define RUCI_PARA_LEN_IO_READ                   3
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_IoRead[];
extern const uint8_t Ruci_ElmtNum_IoRead[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_IO_READ {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint16_t        Length;
    uint8_t         Qidx;
    uint16_t        DataLength;
} sRUCI_PARA_IO_READ;

// RUCI: IoWrite ---------------------------------------------------------------
#define RUCI_IO_WRITE                           RUCI_NUM_IO_WRITE, Ruci_ElmtType_IoWrite, Ruci_ElmtNum_IoWrite
#define RUCI_CODE_IO_WRITE                      0x04
#define RUCI_LEN_IO_WRITE                       2117
#define RUCI_NUM_IO_WRITE                       6
#define RUCI_PARA_LEN_IO_WRITE                  2113
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_IoWrite[];
extern const uint8_t Ruci_ElmtNum_IoWrite[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_IO_WRITE {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint16_t        Length;
    uint8_t         Qidx;
    uint16_t        DataLength;
    uint8_t         Data[2110];
} sRUCI_PARA_IO_WRITE;

// RUCI: MemRead ---------------------------------------------------------------
#define RUCI_MEM_READ                           RUCI_NUM_MEM_READ, Ruci_ElmtType_MemRead, Ruci_ElmtNum_MemRead
#define RUCI_CODE_MEM_READ                      0x05
#define RUCI_LEN_MEM_READ                       8
#define RUCI_NUM_MEM_READ                       5
#define RUCI_PARA_LEN_MEM_READ                  4
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_MemRead[];
extern const uint8_t Ruci_ElmtNum_MemRead[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_MEM_READ {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint16_t        Length;
    uint16_t        Addr;
    uint16_t        DataLength;
} sRUCI_PARA_MEM_READ;

// RUCI: MemWrite --------------------------------------------------------------
#define RUCI_MEM_WRITE                          RUCI_NUM_MEM_WRITE, Ruci_ElmtType_MemWrite, Ruci_ElmtNum_MemWrite
#define RUCI_CODE_MEM_WRITE                     0x06
#define RUCI_LEN_MEM_WRITE                      2056
#define RUCI_NUM_MEM_WRITE                      6
#define RUCI_PARA_LEN_MEM_WRITE                 2052
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_MemWrite[];
extern const uint8_t Ruci_ElmtNum_MemWrite[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_MEM_WRITE {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint16_t        Length;
    uint16_t        Addr;
    uint16_t        DataLength;
    uint8_t         Data[2048];
} sRUCI_PARA_MEM_WRITE;

// RUCI: RegRead ---------------------------------------------------------------
#define RUCI_REG_READ                           RUCI_NUM_REG_READ, Ruci_ElmtType_RegRead, Ruci_ElmtNum_RegRead
#define RUCI_CODE_REG_READ                      0x07
#define RUCI_LEN_REG_READ                       8
#define RUCI_NUM_REG_READ                       4
#define RUCI_PARA_LEN_REG_READ                  4
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_RegRead[];
extern const uint8_t Ruci_ElmtNum_RegRead[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_REG_READ {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint16_t        Length;
    uint32_t        Addr;
} sRUCI_PARA_REG_READ;

// RUCI: RegWrite --------------------------------------------------------------
#define RUCI_REG_WRITE                          RUCI_NUM_REG_WRITE, Ruci_ElmtType_RegWrite, Ruci_ElmtNum_RegWrite
#define RUCI_CODE_REG_WRITE                     0x08
#define RUCI_LEN_REG_WRITE                      12
#define RUCI_NUM_REG_WRITE                      5
#define RUCI_PARA_LEN_REG_WRITE                 8
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_RegWrite[];
extern const uint8_t Ruci_ElmtNum_RegWrite[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_REG_WRITE {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint16_t        Length;
    uint32_t        Addr;
    uint32_t        Data;
} sRUCI_PARA_REG_WRITE;

// RUCI: PmuCfgByRf ------------------------------------------------------------
#define RUCI_PMU_CFG_BY_RF                      RUCI_NUM_PMU_CFG_BY_RF, Ruci_ElmtType_PmuCfgByRf, Ruci_ElmtNum_PmuCfgByRf
#define RUCI_CODE_PMU_CFG_BY_RF                 0x09
#define RUCI_LEN_PMU_CFG_BY_RF                  5
#define RUCI_NUM_PMU_CFG_BY_RF                  4
#define RUCI_PARA_LEN_PMU_CFG_BY_RF             1
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_PmuCfgByRf[];
extern const uint8_t Ruci_ElmtNum_PmuCfgByRf[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_PMU_CFG_BY_RF {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint16_t        Length;
    uint8_t         RfBand;
} sRUCI_PARA_PMU_CFG_BY_RF;

#pragma pack(pop)
#endif /* RUCI_ENABLE_SF */
#endif /* _RUCI_HOST_CMD_H */
