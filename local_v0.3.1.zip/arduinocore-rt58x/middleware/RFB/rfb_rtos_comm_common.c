/**
 * @file rfb_comm_common.c
 * @author
 * @date
 * @brief Apis for RFB communication subsystem and ruci format
 *
 * More detailed description can go here
 *
 *
 * @see http://
 */
/**************************************************************************************************
*    INCLUDES
*************************************************************************************************/
#include <string.h>
#include <stdio.h>
#include "project_config.h"
#include "cm3_mcu.h"
#include "Ruci.h"
#include "rfb_comm.h"
#include "rfb.h"
#include "rf_common_init.h"
#include "sys_arch.h"

#include "task_pci.h"
#include "mem_mgmt.h"
#include "zigbee_task.h"
#include "zigbee_task.h"

#include "util_log.h"
/**************************************************************************************************
 *    MACROS
 *************************************************************************************************/

/**************************************************************************************************
 *    CONSTANTS AND DEFINES
 *************************************************************************************************/
#define RX_ALWAYS_ON_MODE (0xFFFFFFFF)

/**************************************************************************************************
 *    TYPEDEFS
 *************************************************************************************************/
typedef struct _rfb_rx_ctrl_field_t {
    uint16_t        Length;
    uint8_t         CrcStatus;
    uint8_t         Rssi;
    uint8_t         Snr;
} rfb_rx_ctrl_field_t;

typedef struct _rfb_rx_buffer_s {
    rfb_rx_ctrl_field_t rx_control_field;
    uint8_t rx_data[MAX_RF_LEN];
} rfb_rx_buffer_t;

typedef struct _rfb_rx_queue_t {
    uint8_t rx_num;
    rfb_rx_buffer_t rx_buf[MAX_RX_BUFF_NUM];
} rfb_rx_queue_t;

/**************************************************************************************************
 *    GLOBAL VARIABLES
 *************************************************************************************************/
rfb_interrupt_event_t *rfb_interrupt_event;
static rfb_rx_queue_t g_rx_queue;
extern void enter_critical_section(void);
extern void leave_critical_section(void);
extern void commsubsystem_read_memory(uint16_t reg_address, uint8_t *p_rx_data, uint16_t rx_data_length);
/**************************************************************************************************
 *    LOCAL FUNCTIONS
 *************************************************************************************************/

RF_MCU_RX_CMDQ_ERROR rfb_event_read(uint8_t *packet_length, uint8_t *event_address)
{
    zboss_cmd_result_t zboss_cmd_result;

    if(sys_queue_recv(&g_zboss_cmd_result_handle, &zboss_cmd_result, 2000) == SYS_ARCH_TIMEOUT)
    {
        //err("rfb event wait timeout!!!\n");
        return RF_MCU_RX_CMDQ_ERR_INIT;
    }
    else
    {
        memcpy(event_address, zboss_cmd_result.value_ptr, zboss_cmd_result.length);
        *packet_length = zboss_cmd_result.length;
        if (zboss_cmd_result.length == 0)
        {
            return RF_MCU_RX_CMDQ_ERR_INIT;
        }
        else
        {
            mem_free(zboss_cmd_result.value_ptr);

            return RF_MCU_RX_CMDQ_GET_SUCCESS;
        }
    }
}

RF_MCU_RXQ_ERROR rfb_comm_rx_data_read(uint8_t *rx_data_address, rfb_rx_ctrl_field_t *rx_control_field)
{
    RF_MCU_RXQ_ERROR RxQueueError = RF_MCU_RXQ_ERR_INIT;
    commsubsystem_read_rx_queue(rx_data_address, &RxQueueError);
    RUCI_ENDIAN_CONVERT((uint8_t *)&sRxControlField, RUCI_RX_CONTROL_FIELD);
    /* Crc status , Rssi , and SNR will be put on first three byte of RX queue*/
    memcpy((uint8_t *)rx_control_field, &rx_data_address[2], RUCI_LEN_RX_CONTROL_FIELD - 2);
    return RxQueueError;
}

void rfb_send_cmd(uint8_t *cmd_address, uint8_t cmd_length)
{
    pci_task_common_queue_t pci_comm_msg;

    /* wake up RF to clear interrupt status */
    commsubsystem_host_wakeup();
    while (commsubsystem_check_power_state() != 0x03) {
        //printf("[W] PWR state error(%d) in rfb_send_cmd\n",commsubsystem_check_power_state());
    }

    pci_comm_msg.pci_msg_tag = PCI_MSG_TX_PCI_CMD;
    pci_comm_msg.pci_msg.param_type.pci_msg_ptr = mem_malloc(cmd_length);

    if (pci_comm_msg.pci_msg.param_type.pci_msg_ptr != NULL)
    {
        memcpy(pci_comm_msg.pci_msg.param_type.pci_msg_ptr, cmd_address, cmd_length);
        if (zboss_send_cmd_to_pci(pci_comm_msg) == FALSE)
        {
            mem_free(pci_comm_msg.pci_msg.param_type.pci_msg_ptr);
            //err("rfb cmd send fail!!!\n");
            //return false;
        }
    }


}
/**************************************************************************************************
 *    GLOBAL FUNCTIONS
 *************************************************************************************************/



RFB_EVENT_STATUS rfb_comm_frequency_set(uint32_t rf_frequency)
{
    sRUCI_PARA_SET_RF_FREQUENCY sSetFrequencyCmd = {0};
    sRUCI_PARA_CNF_EVENT sCnfEvent = {0};
    uint8_t event_len = 0;
    RF_MCU_RX_CMDQ_ERROR event_status = RF_MCU_RX_CMDQ_ERR_INIT;

    SET_RUCI_PARA_COMMON_RF_CHANNEL(&sSetFrequencyCmd, rf_frequency);

    RUCI_ENDIAN_CONVERT((uint8_t *)&sSetFrequencyCmd, RUCI_SET_RF_FREQUENCY);

    //enter_critical_section();
    rfb_send_cmd((uint8_t *)&sSetFrequencyCmd, RUCI_LEN_SET_RF_FREQUENCY);
    event_status = rfb_event_read(&event_len, (uint8_t *)&sCnfEvent);
    //leave_critical_section();

    RUCI_ENDIAN_CONVERT((uint8_t *)&sCnfEvent, RUCI_CNF_EVENT);
    if (event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_CNF_EVENT_NOT_AVAILABLE;
    if (sCnfEvent.PciCmdSubheader != RUCI_CODE_SET_RF_FREQUENCY)
        return RFB_CNF_EVENT_CONTENT_ERROR;
    if (sCnfEvent.Status != RFB_EVENT_SUCCESS)
        return (RFB_EVENT_STATUS)sCnfEvent.Status;

    return RFB_EVENT_SUCCESS;
}

RFB_EVENT_STATUS rfb_comm_single_tone_mode_set(uint8_t single_tone_mode)
{
    sRUCI_PARA_SET_SINGLE_TONE_MODE sStModeEnCmd_t = {0};
    sRUCI_PARA_CNF_EVENT sCnfEvent = {0};
    uint8_t event_len = 0;
    RF_MCU_RX_CMDQ_ERROR event_status = RF_MCU_RX_CMDQ_ERR_INIT;

    SET_RUCI_PARA_COMMON_SINGLE_TONE(&sStModeEnCmd_t, single_tone_mode);

    RUCI_ENDIAN_CONVERT((uint8_t *)&sStModeEnCmd_t, RUCI_SET_SINGLE_TONE_MODE);

    //enter_critical_section();
    rfb_send_cmd((uint8_t *)&sStModeEnCmd_t, RUCI_LEN_SET_SINGLE_TONE_MODE);
    event_status = rfb_event_read(&event_len, (uint8_t *)&sCnfEvent);
    //leave_critical_section();

    RUCI_ENDIAN_CONVERT((uint8_t *)&sCnfEvent, RUCI_CNF_EVENT);
    if (event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_CNF_EVENT_NOT_AVAILABLE;
    if (sCnfEvent.PciCmdSubheader != RUCI_CODE_SET_SINGLE_TONE_MODE)
        return RFB_CNF_EVENT_CONTENT_ERROR;
    if (sCnfEvent.Status != RFB_EVENT_SUCCESS)
        return (RFB_EVENT_STATUS)sCnfEvent.Status;
    return RFB_EVENT_SUCCESS;
}



RFB_EVENT_STATUS rfb_comm_rx_enable_set(bool rx_continuous, uint32_t rx_timeout)
{
    sRUCI_PARA_SET_RX_ENABLE sRxReqCmd = {0};
    sRUCI_PARA_CNF_EVENT sCnfEvent = {0};
    uint8_t event_len = 0;
    RF_MCU_RX_CMDQ_ERROR event_status = RF_MCU_RX_CMDQ_ERR_INIT;

    SET_RUCI_PARA_COMMON_RX_ENABLE(&sRxReqCmd, ((rx_continuous == true) ? RX_ALWAYS_ON_MODE : rx_timeout));

    RUCI_ENDIAN_CONVERT((uint8_t *)&sRxReqCmd, RUCI_SET_RX_ENABLE);

    //enter_critical_section();
    rfb_send_cmd((uint8_t *)&sRxReqCmd, RUCI_LEN_SET_RX_ENABLE);
    event_status = rfb_event_read(&event_len, (uint8_t *)&sCnfEvent);
    //leave_critical_section();

    RUCI_ENDIAN_CONVERT((uint8_t *)&sCnfEvent, RUCI_CNF_EVENT);
    if (event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_CNF_EVENT_NOT_AVAILABLE;
    if (sCnfEvent.PciCmdSubheader != RUCI_CODE_SET_RX_ENABLE)
        return RFB_CNF_EVENT_CONTENT_ERROR;
    if (sCnfEvent.Status != RFB_EVENT_SUCCESS)
        return (RFB_EVENT_STATUS)sCnfEvent.Status;

    return RFB_EVENT_SUCCESS;
}


RFB_EVENT_STATUS rfb_comm_rf_idle_set(void)
{
    sRUCI_PARA_SET_RF_IDLE sRfIdleSetCmd = {0};
    sRUCI_PARA_CNF_EVENT sCnfEvent = {0};
    uint8_t event_len = 0;
    RF_MCU_RX_CMDQ_ERROR event_status = RF_MCU_RX_CMDQ_ERR_INIT;

    SET_RUCI_PARA_COMMON_RF_IDLE(&sRfIdleSetCmd);

    RUCI_ENDIAN_CONVERT((uint8_t *)&sRfIdleSetCmd, RUCI_SET_RF_IDLE);

    //enter_critical_section();
    rfb_send_cmd((uint8_t *)&sRfIdleSetCmd, RUCI_LEN_SET_RF_IDLE);
    event_status = rfb_event_read(&event_len, (uint8_t *)&sCnfEvent);
    //leave_critical_section();

    RUCI_ENDIAN_CONVERT((uint8_t *)&sCnfEvent, RUCI_CNF_EVENT);
    if (event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_CNF_EVENT_NOT_AVAILABLE;
    if (sCnfEvent.PciCmdSubheader != RUCI_CODE_SET_RF_IDLE)
        return RFB_CNF_EVENT_CONTENT_ERROR;
    if (sCnfEvent.Status != RFB_EVENT_SUCCESS)
        return (RFB_EVENT_STATUS)sCnfEvent.Status;

    return RFB_EVENT_SUCCESS;
}


RFB_WRITE_TXQ_STATUS rfb_comm_tx_data_send(uint16_t packet_length, uint8_t *tx_data_address, uint8_t InitialCwAckRequest, uint8_t Dsn)
{
    sRUCI_PARA_SET_TX_CONTROL_FIELD sTxControlField = {0};
    static uint8_t txData[MAX_RF_LEN];
    pci_task_common_queue_t pci_comm_msg;

    /* wake up RF to clear interrupt status */
    commsubsystem_host_wakeup();
    while (commsubsystem_check_power_state() != 0x03) {
        //err("[TX] Pwr chk\n");
    }

    SET_RUCI_PARA_TX_CONTROL_FIELD(&sTxControlField, packet_length, InitialCwAckRequest, Dsn);

    RUCI_ENDIAN_CONVERT((uint8_t *)&sTxControlField, RUCI_SET_TX_CONTROL_FIELD);
    memcpy(&txData[0], (uint8_t *)&sTxControlField, RUCI_LEN_SET_TX_CONTROL_FIELD);
    memcpy(&txData[RUCI_LEN_SET_TX_CONTROL_FIELD], tx_data_address, packet_length);

    pci_comm_msg.pci_msg_tag = PCI_MSG_TX_PCI_DATA;
    pci_comm_msg.pci_msg.param_type.pci_msg_ptr = mem_malloc(packet_length + RUCI_LEN_SET_TX_CONTROL_FIELD);

    if (pci_comm_msg.pci_msg.param_type.pci_msg_ptr != NULL)
    {
        //printf("rfb data send 0x%02x%02x%02x %d %d\n", txData[0], txData[1], txData[2], packet_length, packet_length+RUCI_LEN_SET_TX_CONTROL_FIELD);
        memcpy(pci_comm_msg.pci_msg.param_type.pci_msg_ptr, txData, packet_length + RUCI_LEN_SET_TX_CONTROL_FIELD);

        if (zboss_send_data_to_pci(pci_comm_msg) == FALSE)
        {
            mem_free(pci_comm_msg.pci_msg.param_type.pci_msg_ptr);
            return RFB_WRITE_TXQ_FULL;
        }
    }
    else
    {
        send_data_to_pci_fail(TX_MALLOC_FULL);
        return RFB_WRITE_TXQ_FULL;
    }
    return RFB_WRITE_TXQ_SUCCESS;
}

void rfb_comm_init(rfb_interrupt_event_t *_rfb_interrupt_event)
{
    /* Rsgister Interrupt event for application use*/
    rfb_interrupt_event = _rfb_interrupt_event;

}

RFB_EVENT_STATUS rfb_comm_rssi_read(uint8_t *rssi)
{
    sRUCI_PARA_GET_RSSI sGetRssiCmd = {0};
    sRUCI_PARA_GET_RSSI_EVENT sGetRssiEvent = {0};
    sRUCI_PARA_CNF_EVENT sCnfEvent = {0};
    uint8_t event_len = 0;
    RF_MCU_RX_CMDQ_ERROR event_status = RF_MCU_RX_CMDQ_ERR_INIT;
    uint8_t get_rssi_event_len = 0;
    RF_MCU_RX_CMDQ_ERROR get_rssi_event_status = RF_MCU_RX_CMDQ_ERR_INIT;

    SET_RUCI_PARA_COMMON_GET_RSSI(&sGetRssiCmd);

    RUCI_ENDIAN_CONVERT((uint8_t *)&sGetRssiCmd, RUCI_GET_RSSI);

    //enter_critical_section();
    rfb_send_cmd((uint8_t *)&sGetRssiCmd, RUCI_LEN_GET_RSSI);
    event_status = rfb_event_read(&event_len, (uint8_t *)&sCnfEvent);
    get_rssi_event_status = rfb_event_read(&get_rssi_event_len, (uint8_t *)&sGetRssiEvent);
    //leave_critical_section();

    RUCI_ENDIAN_CONVERT((uint8_t *)&sCnfEvent, RUCI_CNF_EVENT);
    if (event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_CNF_EVENT_NOT_AVAILABLE;
    if (sCnfEvent.PciCmdSubheader != RUCI_CODE_GET_RSSI)
        return RFB_CNF_EVENT_CONTENT_ERROR;
    if (sCnfEvent.Status != RFB_EVENT_SUCCESS)
        return (RFB_EVENT_STATUS)sCnfEvent.Status;

    RUCI_ENDIAN_CONVERT((uint8_t *)&sGetRssiEvent, RUCI_GET_RSSI_EVENT);
    if (get_rssi_event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_RSP_EVENT_NOT_AVAILABLE;
    if (sGetRssiEvent.Subheader != RUCI_CODE_GET_RSSI_EVENT)
        return RFB_RSP_EVENT_CONTENT_ERROR;
    *rssi = sGetRssiEvent.Rssi;

    return RFB_EVENT_SUCCESS;
}

RFB_EVENT_STATUS rfb_comm_agc_set(uint8_t agc_enable, uint8_t lna_gain, uint8_t vga_gain, uint8_t tia_gain)
{
    sRUCI_PARA_SET_AGC sAgcSetCmd = {0};
    sRUCI_PARA_CNF_EVENT sCnfEvent = {0};
    uint8_t event_len = 0;
    RF_MCU_RX_CMDQ_ERROR event_status = RF_MCU_RX_CMDQ_ERR_INIT;

    SET_RUCI_PARA_COMMON_AGC(&sAgcSetCmd, (agc_enable & 0x01), lna_gain, vga_gain, tia_gain);

    RUCI_ENDIAN_CONVERT((uint8_t *)&sAgcSetCmd, RUCI_SET_AGC);

    //enter_critical_section();
    rfb_send_cmd((uint8_t *)&sAgcSetCmd, RUCI_LEN_SET_AGC);
    event_status = rfb_event_read(&event_len, (uint8_t *)&sCnfEvent);
    //leave_critical_section();

    RUCI_ENDIAN_CONVERT((uint8_t *)&sCnfEvent, RUCI_CNF_EVENT);
    if (event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_CNF_EVENT_NOT_AVAILABLE;
    if (sCnfEvent.PciCmdSubheader != RUCI_CODE_SET_AGC)
        return RFB_CNF_EVENT_CONTENT_ERROR;
    if (sCnfEvent.Status != RFB_EVENT_SUCCESS)
        return (RFB_EVENT_STATUS)sCnfEvent.Status;

    return RFB_EVENT_SUCCESS;
}

RFB_EVENT_STATUS rfb_comm_rf_sleep_set(bool sleep_enable_flag)
{
    sRUCI_PARA_SET_RF_SLEEP sRfSleepSetCmd = {0};
    sRUCI_PARA_CNF_EVENT sCnfEvent = {0};
    uint8_t event_len = 0;
    RF_MCU_RX_CMDQ_ERROR event_status = RF_MCU_RX_CMDQ_ERR_INIT;

    SET_RUCI_PARA_COMMON_RF_SLEEP(&sRfSleepSetCmd, sleep_enable_flag);

    sRfSleepSetCmd.EnableFlag = sleep_enable_flag;

    RUCI_ENDIAN_CONVERT((uint8_t *)&sRfSleepSetCmd, RUCI_SET_RF_SLEEP);

    //enter_critical_section();
    rfb_send_cmd((uint8_t *)&sRfSleepSetCmd, RUCI_LEN_SET_RF_SLEEP);
    event_status = rfb_event_read(&event_len, (uint8_t *)&sCnfEvent);
    //leave_critical_section();

    RUCI_ENDIAN_CONVERT((uint8_t *)&sCnfEvent, RUCI_CNF_EVENT);
    if (event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_CNF_EVENT_NOT_AVAILABLE;
    if (sCnfEvent.PciCmdSubheader != RUCI_CODE_SET_RF_SLEEP)
        return RFB_CNF_EVENT_CONTENT_ERROR;
    if (sCnfEvent.Status != RFB_EVENT_SUCCESS)
        return (RFB_EVENT_STATUS)sCnfEvent.Status;

    return RFB_EVENT_SUCCESS;
}

RFB_EVENT_STATUS rfb_comm_fw_version_get(uint32_t *rfb_version)
{
    sRUCI_PARA_GET_FW_VER sGetRfbVerCmd = {0};
    sRUCI_PARA_GET_FW_VER_EVENT sGetRfbVerEvent = {0};
    sRUCI_PARA_CMN_CNF_EVENT sCmnCnfEvent = {0};
    uint8_t event_len = 0;
    RF_MCU_RX_CMDQ_ERROR event_status = RF_MCU_RX_CMDQ_ERR_INIT;
    uint8_t get_rfb_ver_event_len = 0;
    RF_MCU_RX_CMDQ_ERROR get_rfb_ver_event_status = RF_MCU_RX_CMDQ_ERR_INIT;

    SET_RUCI_PARA_COMMON_GET_FW_VER(&sGetRfbVerCmd);

    RUCI_ENDIAN_CONVERT((uint8_t *)&sGetRfbVerCmd, RUCI_GET_FW_VER);

    //enter_critical_section();
    rfb_send_cmd((uint8_t *)&sGetRfbVerCmd, RUCI_LEN_GET_FW_VER);
    event_status = rfb_event_read(&event_len, (uint8_t *)&sCmnCnfEvent);
    get_rfb_ver_event_status = rfb_event_read(&get_rfb_ver_event_len, (uint8_t *)&sGetRfbVerEvent);
    //leave_critical_section();

    RUCI_ENDIAN_CONVERT((uint8_t *)&sCmnCnfEvent, RUCI_CMN_CNF_EVENT);
    if (event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_CNF_EVENT_NOT_AVAILABLE;
    if (sCmnCnfEvent.CmnCmdSubheader != RUCI_CODE_GET_FW_VER)
        return RFB_CNF_EVENT_CONTENT_ERROR;
    if (sCmnCnfEvent.Status != RFB_CMN_EVENT_SUCCESS)
        return (RFB_EVENT_STATUS)sCmnCnfEvent.Status;

    RUCI_ENDIAN_CONVERT((uint8_t *)&sGetRfbVerEvent, RUCI_GET_FW_VER_EVENT);
    if (get_rfb_ver_event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_RSP_EVENT_NOT_AVAILABLE;
    if (sGetRfbVerEvent.Subheader != RUCI_CODE_GET_FW_VER_EVENT)
        return RFB_RSP_EVENT_CONTENT_ERROR;
    *rfb_version = sGetRfbVerEvent.FwVer;

    return RFB_EVENT_SUCCESS;
}

RFB_EVENT_STATUS rfb_comm_auto_state_set(bool rxOnWhenIdle)
{
    sRUCI_PARA_SET_RFB_AUTO_STATE sRfbAutoStateSet = {0};
    sRUCI_PARA_CNF_EVENT sCnfEvent = {0};
    uint8_t event_len = 0;
    RF_MCU_RX_CMDQ_ERROR event_status = RF_MCU_RX_CMDQ_ERR_INIT;

    SET_RUCI_PARA_COMMON_RFB_AUTO_STATE(&sRfbAutoStateSet, rxOnWhenIdle);

    RUCI_ENDIAN_CONVERT((uint8_t *)&sRfbStateInit, RUCI_SET_RFB_AUTO_STATE);

    //enter_critical_section();
    rfb_send_cmd((uint8_t *)&sRfbAutoStateSet, RUCI_LEN_SET_RFB_AUTO_STATE);
    event_status = rfb_event_read(&event_len, (uint8_t *)&sCnfEvent);
    //leave_critical_section();

    RUCI_ENDIAN_CONVERT((uint8_t *)&sCnfEvent, RUCI_CNF_EVENT);
    if (event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_CNF_EVENT_NOT_AVAILABLE;
    if (sCnfEvent.PciCmdSubheader != RUCI_CODE_SET_RFB_AUTO_STATE)
        return RFB_CNF_EVENT_CONTENT_ERROR;
    if (sCnfEvent.Status != RFB_EVENT_SUCCESS)
        return (RFB_EVENT_STATUS)sCnfEvent.Status;
    return RFB_EVENT_SUCCESS;
}
