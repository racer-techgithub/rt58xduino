/* Tone.cpp

  A Tone Generator Library

  Written by Brett Hagman

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#define ARDUINO_MAIN
#include "Arduino.h"
#include "cm3_mcu.h"
#include "pwm.h"

static uint32_t prvPwmDuty[5] = {0, 0, 0, 0, 0};

static void prvToneConfig(pwm_id_t id, uint32_t frequency)
{
  pwm_seq_para_head_t pwm_para_config;
  pwm_para_config.pwm_play_cnt = 0;
  pwm_para_config.pwm_count_end_val = 0;
  pwm_para_config.pwm_seq_order = PWM_SEQ_ORDER_R;
  pwm_para_config.pwm_triggered_src = PWM_TRIGGER_SRC_SELF;
  pwm_para_config.pwm_seq_num = PWM_SEQ_NUM_1;
  pwm_para_config.pwm_id = id;
  pwm_para_config.pwm_clk_div = PWM_CLK_DIV_256;
  pwm_para_config.pwm_counter_mode = PWM_COUNTER_MODE_UP;
  pwm_para_config.pwm_dma_smp_fmt = PWM_DMA_SMP_FMT_1;
  pwm_para_config.pwm_seq_mode = PWM_SEQ_MODE_CONTINUOUS;

  uint32_t period = 0;
  if (frequency)
  {
    uint32_t xtal = 0;
    switch (get_ahb_system_clk())
    {
    case SYS_CLK_32MHZ:
      xtal = 32000000;
      break;
    case SYS_CLK_48MHZ:
      xtal = 48000000;
      break;
    case SYS_CLK_64MHZ:
      xtal = 64000000;
      break;
    default:
      break;
    }

    uint32_t min_clk_div = (uint32_t)PWM_CLK_DIV_1;
    uint32_t max_clk_div = (uint32_t)PWM_CLK_DIV_256 + 1;
    for (uint32_t i = min_clk_div; i < max_clk_div; i++)
    {
      pwm_para_config.pwm_clk_div = (pwm_clk_div_t)i;
      period = (xtal / (0x01 << i)) / frequency;
      if (period < 0x8000)
      {
        break;
      }
    }
  }

  prvPwmDuty[id] = PWM_FILL_SAMPLE_DATA_MODE1(0, period >> 1, period);
  pwm_seq_para_t *pwm_seq = &pwm_para_config.pwm_seq0;
  pwm_seq->pwm_element_num = 1;
  pwm_seq->pwm_rdma_addr = (uint32_t)&prvPwmDuty[id];
  pwm_seq->pwm_repeat_num = 0;
  pwm_seq->pwm_delay_num = 0;

  Pwm_Init(&pwm_para_config);
  Pwm_Start(&pwm_para_config);
}

// frequency (in hertz) and duration (in milliseconds).
void tone(uint8_t _pin, unsigned int frequency, unsigned long duration)
{
  switch (_pin)
  {
  case PIN_TONE0:
    pin_set_mode(_pin, 4);
    prvToneConfig(PWM_ID_0, frequency);
    break;
  case PIN_TONE1:
    NVIC_DisableIRQ(Pwm1_IRQn);
    pin_set_mode(_pin, 4);
    prvToneConfig(PWM_ID_1, frequency);
    break;
  case PIN_TONE2:
    NVIC_DisableIRQ(Pwm2_IRQn);
    pin_set_mode(_pin, 4);
    prvToneConfig(PWM_ID_2, frequency);
    break;
  case PIN_TONE3:
    NVIC_DisableIRQ(Pwm3_IRQn);
    pin_set_mode(_pin, 4);
    prvToneConfig(PWM_ID_3, frequency);
    break;
  case PIN_TONE4:
    NVIC_DisableIRQ(Pwm4_IRQn);
    pin_set_mode(_pin, 4);
    prvToneConfig(PWM_ID_4, frequency);
    break;
  default:
    break;
  }
}

void noTone(uint8_t _pin)
{
  switch (_pin)
  {
  case PIN_TONE0:
    Pwm_Stop(PWM_ID_0);
    break;
  case PIN_TONE1:
    Pwm_Stop(PWM_ID_1);
    break;
  case PIN_TONE2:
    Pwm_Stop(PWM_ID_2);
    break;
  case PIN_TONE3:
    Pwm_Stop(PWM_ID_3);
    break;
  case PIN_TONE4:
    Pwm_Stop(PWM_ID_4);
    break;
  default:
    return;
  }
  pinMode(_pin, OUTPUT);
  digitalWrite(_pin, LOW);
}
