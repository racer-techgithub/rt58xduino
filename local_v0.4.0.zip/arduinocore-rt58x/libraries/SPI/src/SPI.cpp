/*
  Copyright (c) 2016 Arduino.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "SPI.h"

const SPISettings DEFAULT_SPI_SETTINGS = SPISettings();

SPIClass::SPIClass(uint32_t spi_id)
{
	this->_spi_id = spi_id;
	this->settings = DEFAULT_SPI_SETTINGS;
	switch (this->_spi_id)
	{
	case 0:
		/*init SPI pin mux   -- for SPI0*/
		pin_set_mode(PIN_SPI0_SCK, MODE_QSPI0);	 /*SPI SCLK*/
		pin_set_mode(PIN_SPI0_MOSI, MODE_QSPI0); /*SPI DATA0*/
		pin_set_mode(PIN_SPI0_MISO, MODE_QSPI0); /*SPI DATA1*/
		break;
	case 1:
		/*init SPI pin mux   -- for SPI1*/
		pin_set_mode(PIN_SPI1_SCK, MODE_QSPI1);	 /*SPI SCLK*/
		pin_set_mode(PIN_SPI1_MOSI, MODE_QSPI1); /*SPI DATA0*/
		pin_set_mode(PIN_SPI1_MISO, MODE_QSPI1); /*SPI DATA1*/
		break;
	default:
		break;
	}
}

void SPIClass::config(SPISettings settings)
{
	qspi_transfer_mode_t mode;
	this->settings = settings;
	mode.SPI_BIT_ORDER = this->settings.bit_order == MSBFIRST ? SPI_MSB_ORDER : SPI_LSB_ORDER;
	mode.SPI_CPOL = (this->settings.data_mode == SPI_MODE0 || this->settings.data_mode == SPI_MODE1) ? 0 : 1;
	mode.SPI_CPHA = (this->settings.data_mode == SPI_MODE0 || this->settings.data_mode == SPI_MODE2) ? 0 : 1;
	mode.SPI_CS_POL = SPI_CHIPSEL_ACTIVE_LOW; /*CS low active, idled in high */
	mode.SPI_MASTER = SPI_MASTER_MODE;		  /*controller spi0 as SPI host*/
	mode.SPI_CS = 0;						  /*Select SS0 */
	if (this->settings.interface_clock >= 32000000)
	{
		mode.SPI_CLK = QSPI_CLK_32M;
	}
	else if (this->settings.interface_clock >= 16000000)
	{
		mode.SPI_CLK = QSPI_CLK_16M;
	}
	else if (this->settings.interface_clock >= 8000000)
	{
		mode.SPI_CLK = QSPI_CLK_8M;
	}
	else if (this->settings.interface_clock >= 4000000)
	{
		mode.SPI_CLK = QSPI_CLK_4M;
	}
	else if (this->settings.interface_clock >= 2000000)
	{
		mode.SPI_CLK = QSPI_CLK_2M;
	}
	else
	{
		mode.SPI_CLK = QSPI_CLK_1M;
	}

	qspi_init(this->_spi_id, &mode);
}

void SPIClass::begin()
{
	this->config(DEFAULT_SPI_SETTINGS);
}

void SPIClass::beginSlave()
{
	// TODO...
	Serial.println("SPIClass::beginSlave unImplemented.");
}

void SPIClass::end()
{
}

void SPIClass::beginTransaction(SPISettings settings)
{
	this->config(settings);
}

void SPIClass::endTransaction(void)
{
}

void SPIClass::setBitOrder(BitOrder order)
{
	this->settings.bit_order = order;
	this->config(this->settings);
}

void SPIClass::setDataMode(uint8_t uc_mode)
{
	this->settings.data_mode = uc_mode;
	this->config(this->settings);
}

void SPIClass::setClockDivider(uint16_t div)
{
	qspi_change_clk(this->_spi_id, div);
}

byte SPIClass::transfer(uint8_t data)
{
	spi_block_request_t req = {
		.write_buf = &data,
		.read_buf = &data,
		.length = sizeof(data)};
	spi_transfer_pio(this->_spi_id, &req);
	return data;
}

byte SPIClass::read()
{
	// read data
	uint8_t data = 0xFF;
	spi_block_request_t req = {
		.write_buf = &data,
		.read_buf = &data,
		.length = sizeof(data)};
	spi_transfer_pio(this->_spi_id, &req);
	return data;
}

void SPIClass::usingInterrupt(uint8_t intNum)
{
}

void SPIClass::write(uint8_t data)
{
	spi_block_request_t req = {
		.write_buf = &data,
		.read_buf = &data,
		.length = sizeof(data)};
	spi_transfer_pio(this->_spi_id, &req);
}

void SPIClass::transfer(void *data, size_t count)
{
	spi_block_request_t req = {
		.write_buf = (uint8_t *)data,
		.read_buf = (uint8_t *)data,
		.length = (uint16_t)count};
	spi_transfer_pio(this->_spi_id, &req);
}

uint16_t SPIClass::transfer16(uint16_t data)
{
	uint16_t send = __REV16(data);
	uint16_t recv = 0;
	spi_block_request_t req = {
		.write_buf = (uint8_t *)&send,
		.read_buf = (uint8_t *)&recv,
		.length = (uint16_t)sizeof(uint16_t)};
	spi_transfer_pio(this->_spi_id, &req);
	return __REV16(recv);
}

void SPIClass::attachInterrupt(void)
{
	// Should be enableInterrupt()
}

void SPIClass::detachInterrupt(void)
{
	// Should be disableInterrupt()
}

SPIClass SPI_A(0);
SPIClass SPI_B(1);
