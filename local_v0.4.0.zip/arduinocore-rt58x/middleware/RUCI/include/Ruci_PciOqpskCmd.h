/******************************************************************************
*
* @File			Ruci_PciOqpskCmd.h
* @Version
* $Revision: 4235
* $Date: 2022-02-07
* @Brief
* @Note
* Copyright (C) 2019 Rafael Microelectronics Inc. All rights reserved.
*
******************************************************************************/
#ifndef _RUCI_PCI_OQPSK_CMD_H
#define _RUCI_PCI_OQPSK_CMD_H

#include "Ruci_Head.h"

#if (RUCI_ENABLE_PCI)

/******************************************************************************
* DEFINES
*****************************************************************************/

#pragma pack(push)
#pragma pack(1)
#define RUCI_PCI_OQPSK_CMD_HEADER 0x14

// RUCI: InitiateOqpsk ---------------------------------------------------------
#define RUCI_INITIATE_OQPSK                     RUCI_NUM_INITIATE_OQPSK, Ruci_ElmtType_InitiateOqpsk, Ruci_ElmtNum_InitiateOqpsk
#define RUCI_CODE_INITIATE_OQPSK                0x01
#define RUCI_LEN_INITIATE_OQPSK                 3
#define RUCI_NUM_INITIATE_OQPSK                 3
#define RUCI_PARA_LEN_INITIATE_OQPSK            0
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_InitiateOqpsk[];
extern const uint8_t Ruci_ElmtNum_InitiateOqpsk[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_INITIATE_OQPSK {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
} sRUCI_PARA_INITIATE_OQPSK;

// RUCI: SetOqpskModem ---------------------------------------------------------
#define RUCI_SET_OQPSK_MODEM                    RUCI_NUM_SET_OQPSK_MODEM, Ruci_ElmtType_SetOqpskModem, Ruci_ElmtNum_SetOqpskModem
#define RUCI_CODE_SET_OQPSK_MODEM               0x02
#define RUCI_LEN_SET_OQPSK_MODEM                4
#define RUCI_NUM_SET_OQPSK_MODEM                4
#define RUCI_PARA_LEN_SET_OQPSK_MODEM           1
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetOqpskModem[];
extern const uint8_t Ruci_ElmtNum_SetOqpskModem[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_OQPSK_MODEM {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         DataRate;
} sRUCI_PARA_SET_OQPSK_MODEM;

// RUCI: SetOqpskMac -----------------------------------------------------------
#define RUCI_SET_OQPSK_MAC                      RUCI_NUM_SET_OQPSK_MAC, Ruci_ElmtType_SetOqpskMac, Ruci_ElmtNum_SetOqpskMac
#define RUCI_CODE_SET_OQPSK_MAC                 0x03
#define RUCI_LEN_SET_OQPSK_MAC                  5
#define RUCI_NUM_SET_OQPSK_MAC                  5
#define RUCI_PARA_LEN_SET_OQPSK_MAC             2
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetOqpskMac[];
extern const uint8_t Ruci_ElmtNum_SetOqpskMac[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_OQPSK_MAC {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         CrcType;
    uint8_t         WhiteningEn;
} sRUCI_PARA_SET_OQPSK_MAC;

// RUCI: SetOqpskExtraPreamble -------------------------------------------------
#define RUCI_SET_OQPSK_EXTRA_PREAMBLE           RUCI_NUM_SET_OQPSK_EXTRA_PREAMBLE, Ruci_ElmtType_SetOqpskExtraPreamble, Ruci_ElmtNum_SetOqpskExtraPreamble
#define RUCI_CODE_SET_OQPSK_EXTRA_PREAMBLE      0x04
#define RUCI_LEN_SET_OQPSK_EXTRA_PREAMBLE       4
#define RUCI_NUM_SET_OQPSK_EXTRA_PREAMBLE       4
#define RUCI_PARA_LEN_SET_OQPSK_EXTRA_PREAMBLE  1
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetOqpskExtraPreamble[];
extern const uint8_t Ruci_ElmtNum_SetOqpskExtraPreamble[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_OQPSK_EXTRA_PREAMBLE {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         ExtraPrambleLength;
} sRUCI_PARA_SET_OQPSK_EXTRA_PREAMBLE;

#pragma pack(pop)
#endif /* RUCI_ENABLE_PCI */
#endif /* _RUCI_PCI_OQPSK_CMD_H */
