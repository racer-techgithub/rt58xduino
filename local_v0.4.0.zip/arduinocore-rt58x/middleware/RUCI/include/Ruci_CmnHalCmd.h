/******************************************************************************
*
* @File			Ruci_CmnHalCmd.h
* @Version
* $Revision: 4235
* $Date: 2022-02-07
* @Brief
* @Note
* Copyright (C) 2019 Rafael Microelectronics Inc. All rights reserved.
*
******************************************************************************/
#ifndef _RUCI_CMN_HAL_CMD_H
#define _RUCI_CMN_HAL_CMD_H

#include "Ruci_Head.h"

#if (RUCI_ENABLE_CMN)

/******************************************************************************
* DEFINES
*****************************************************************************/

#pragma pack(push)
#pragma pack(1)
#define RUCI_CMN_HAL_CMD_HEADER 0x31

// RUCI: SetAgc ----------------------------------------------------------------
#define RUCI_SET_AGC                            RUCI_NUM_SET_AGC, Ruci_ElmtType_SetAgc, Ruci_ElmtNum_SetAgc
#define RUCI_CODE_SET_AGC                       0x01
#define RUCI_LEN_SET_AGC                        7
#define RUCI_NUM_SET_AGC                        7
#define RUCI_PARA_LEN_SET_AGC                   4
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetAgc[];
extern const uint8_t Ruci_ElmtNum_SetAgc[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_AGC {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         AgcEnable;
    uint8_t         LnaGain;
    uint8_t         VgaGain;
    uint8_t         TiaGain;
} sRUCI_PARA_SET_AGC;

// RUCI: SetCalibrationEnable --------------------------------------------------
#define RUCI_SET_CALIBRATION_ENABLE             RUCI_NUM_SET_CALIBRATION_ENABLE, Ruci_ElmtType_SetCalibrationEnable, Ruci_ElmtNum_SetCalibrationEnable
#define RUCI_CODE_SET_CALIBRATION_ENABLE        0x02
#define RUCI_LEN_SET_CALIBRATION_ENABLE         4
#define RUCI_NUM_SET_CALIBRATION_ENABLE         4
#define RUCI_PARA_LEN_SET_CALIBRATION_ENABLE    1
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetCalibrationEnable[];
extern const uint8_t Ruci_ElmtNum_SetCalibrationEnable[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_CALIBRATION_ENABLE {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         RfBand;
} sRUCI_PARA_SET_CALIBRATION_ENABLE;

// RUCI: SetCalibrationSetting -------------------------------------------------
#define RUCI_SET_CALIBRATION_SETTING            RUCI_NUM_SET_CALIBRATION_SETTING, Ruci_ElmtType_SetCalibrationSetting, Ruci_ElmtNum_SetCalibrationSetting
#define RUCI_CODE_SET_CALIBRATION_SETTING       0x03
#define RUCI_LEN_SET_CALIBRATION_SETTING        11
#define RUCI_NUM_SET_CALIBRATION_SETTING        8
#define RUCI_PARA_LEN_SET_CALIBRATION_SETTING   8
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetCalibrationSetting[];
extern const uint8_t Ruci_ElmtNum_SetCalibrationSetting[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_CALIBRATION_SETTING {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         RfBand;
    uint8_t         Status;
    uint8_t         RxFilter;
    uint8_t         TxLo[2];
    uint8_t         TxSb[3];
} sRUCI_PARA_SET_CALIBRATION_SETTING;

// RUCI: SetTxPower ------------------------------------------------------------
#define RUCI_SET_TX_POWER                       RUCI_NUM_SET_TX_POWER, Ruci_ElmtType_SetTxPower, Ruci_ElmtNum_SetTxPower
#define RUCI_CODE_SET_TX_POWER                  0x04
#define RUCI_LEN_SET_TX_POWER                   5
#define RUCI_NUM_SET_TX_POWER                   5
#define RUCI_PARA_LEN_SET_TX_POWER              2
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetTxPower[];
extern const uint8_t Ruci_ElmtNum_SetTxPower[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_TX_POWER {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         RfBand;
    uint8_t         TxPower;
} sRUCI_PARA_SET_TX_POWER;

// RUCI: GetTemperatureRpt -----------------------------------------------------
#define RUCI_GET_TEMPERATURE_RPT                RUCI_NUM_GET_TEMPERATURE_RPT, Ruci_ElmtType_GetTemperatureRpt, Ruci_ElmtNum_GetTemperatureRpt
#define RUCI_CODE_GET_TEMPERATURE_RPT           0x05
#define RUCI_LEN_GET_TEMPERATURE_RPT            3
#define RUCI_NUM_GET_TEMPERATURE_RPT            3
#define RUCI_PARA_LEN_GET_TEMPERATURE_RPT       0
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_GetTemperatureRpt[];
extern const uint8_t Ruci_ElmtNum_GetTemperatureRpt[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_GET_TEMPERATURE_RPT {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
} sRUCI_PARA_GET_TEMPERATURE_RPT;

// RUCI: GetVoltageRpt ---------------------------------------------------------
#define RUCI_GET_VOLTAGE_RPT                    RUCI_NUM_GET_VOLTAGE_RPT, Ruci_ElmtType_GetVoltageRpt, Ruci_ElmtNum_GetVoltageRpt
#define RUCI_CODE_GET_VOLTAGE_RPT               0x06
#define RUCI_LEN_GET_VOLTAGE_RPT                3
#define RUCI_NUM_GET_VOLTAGE_RPT                3
#define RUCI_PARA_LEN_GET_VOLTAGE_RPT           0
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_GetVoltageRpt[];
extern const uint8_t Ruci_ElmtNum_GetVoltageRpt[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_GET_VOLTAGE_RPT {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
} sRUCI_PARA_GET_VOLTAGE_RPT;

#pragma pack(pop)
#endif /* RUCI_ENABLE_CMN */
#endif /* _RUCI_CMN_HAL_CMD_H */
