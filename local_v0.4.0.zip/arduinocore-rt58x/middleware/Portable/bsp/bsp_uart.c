/** @file bsp_uart.c
 *
 * @license
 * @description
 */

#include "bsp.h"
#include "uart_drv.h"
#include "cm3_mcu.h"
//=============================================================================
//                  Constant Definition
//=============================================================================
#define BSP_UART_PORT_ID                1  
#define BSP_UART_BAUD_RATE              UART_BAUDRATE_115200

//=============================================================================
//                  Macro Definition
//=============================================================================

//=============================================================================
//                  Structure Definition
//=============================================================================

//=============================================================================
//                  Global Data Definition
//==============================================================================
static bsp_event_callback_t m_callback;
//=============================================================================
//                  Private Function Definition
//=============================================================================
static void uart_isr_event_handle(uint32_t event, void *p_context)
{
    if (event & UART_EVENT_TX_DONE) 
    {
        if(m_callback)
            m_callback(BSP_EVENT_UART_TX_DONE);  
    }
    if (event & UART_EVENT_RX_DONE) 
    {
        if(m_callback)
            m_callback(BSP_EVENT_UART_RX_DONE);
    }
    if(event & UART_EVENT_RX_BREAK)
    {
        if(m_callback)
            m_callback(BSP_EVENT_UART_BREAK);
    }
}
//=============================================================================
//                  Public Function Definition
//=============================================================================
int bsp_uart_init(bsp_event_callback_t callback)
{
    int     rval = 0;

    uart_config_t debug_console_drv_config;

    do {

        /*uart1 pinmux*/
        pin_set_mode(28, MODE_UART);     /*GPIO28 as UART0 RX*/
        pin_set_mode(29, MODE_UART);     /*GPIO29 as UART0 TX*/

        /*init debug console uart0, 8bits 1 stopbit, none parity, no flow control.*/
        debug_console_drv_config.baudrate = BSP_UART_BAUD_RATE;
        debug_console_drv_config.databits = UART_DATA_BITS_8;
        debug_console_drv_config.hwfc     = UART_HWFC_DISABLED;
        debug_console_drv_config.parity   = UART_PARITY_NONE;
        debug_console_drv_config.stopbit  = UART_STOPBIT_ONE;
        debug_console_drv_config.interrupt_priority = 0x06;
        
        rval = uart_init(BSP_UART_PORT_ID, &debug_console_drv_config, uart_isr_event_handle);       
    
        if (rval != 0)
            break;

        m_callback = callback;

    } while(0);    
    return rval;
}
uint32_t bsp_uart_send(uint8_t const *p_data, uint32_t length)
{
    return uart_tx(BSP_UART_PORT_ID, p_data, length);
}

uint32_t bsp_uart_recv(uint8_t *p_data, uint32_t length)
{
    return uart_rx(BSP_UART_PORT_ID, p_data, length);
}

uint8_t bsp_uart_rx_getbytes(uint32_t uart_id)
{
    return uart_rx_getbytes(uart_id);
}    
