/** @file bsp_button.h
 * @license
 * @description
 */

#ifndef __BSP_BUTTON_H__
#define __BSP_BUTTON_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "bsp.h"

#if (BOARD==A047)
#define BSP_BUTTON_COUNT        4
#define BSP_BUTTON_0            14
#define BSP_BUTTON_1            15
#define BSP_BUTTON_2            30
#define BSP_BUTTON_3            31
#else
#define BSP_BUTTON_COUNT        5
#define BSP_BUTTON_0            0
#define BSP_BUTTON_1            1
#define BSP_BUTTON_2            2
#define BSP_BUTTON_3            3
#define BSP_BUTTON_4            4
#endif
	
typedef struct 
{
    uint32_t pin_no;
    uint32_t active_state;
} bsp_button_cfg_t;

int bsp_button_init(bsp_event_callback_t callback);
int bsp_button_state_get(uint32_t button);

#ifdef __cplusplus
}
#endif

#endif
