/** @file bsp_uart.h
 * @license
 * @description
 */

#ifndef __BSP_UART_H__
#define __BSP_UART_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "bsp.h"

int bsp_uart_init(bsp_event_callback_t callback);
uint32_t bsp_uart_send(uint8_t const *p_data, uint32_t length);
uint32_t bsp_uart_recv(uint8_t *p_data, uint32_t length);
uint8_t bsp_uart_rx_getbytes(uint32_t uart_id);

#ifdef __cplusplus
}
#endif

#endif
