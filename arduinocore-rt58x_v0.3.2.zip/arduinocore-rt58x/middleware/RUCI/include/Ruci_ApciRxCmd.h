/******************************************************************************
*
* @File			Ruci_ApciRxCmd.h
* @Version
* $Revision: 4157
* $Date: 2021-12-27
* @Brief
* @Note
* Copyright (C) 2019 Rafael Microelectronics Inc. All rights reserved.
*
******************************************************************************/
#ifndef _RUCI_APCI_RX_CMD_H
#define _RUCI_APCI_RX_CMD_H

#include "Ruci_Head.h"

#if (RUCI_ENABLE_APCI)

/******************************************************************************
* DEFINES
*****************************************************************************/

#pragma pack(push)
#pragma pack(1)
#define RUCI_APCI_RX_CMD_HEADER 0x22

// RUCI: SetRxOn ---------------------------------------------------------------
#define RUCI_SET_RX_ON                          RUCI_NUM_SET_RX_ON, Ruci_ElmtType_SetRxOn, Ruci_ElmtNum_SetRxOn
#define RUCI_CODE_SET_RX_ON                     0x01
#define RUCI_LEN_SET_RX_ON                      3
#define RUCI_NUM_SET_RX_ON                      3
#define RUCI_PARA_LEN_SET_RX_ON                 0
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetRxOn[];
extern const uint8_t Ruci_ElmtNum_SetRxOn[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_RX_ON {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
} sRUCI_PARA_SET_RX_ON;

// RUCI: SetRxOff --------------------------------------------------------------
#define RUCI_SET_RX_OFF                         RUCI_NUM_SET_RX_OFF, Ruci_ElmtType_SetRxOff, Ruci_ElmtNum_SetRxOff
#define RUCI_CODE_SET_RX_OFF                    0x02
#define RUCI_LEN_SET_RX_OFF                     3
#define RUCI_NUM_SET_RX_OFF                     3
#define RUCI_PARA_LEN_SET_RX_OFF                0
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetRxOff[];
extern const uint8_t Ruci_ElmtNum_SetRxOff[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_RX_OFF {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
} sRUCI_PARA_SET_RX_OFF;

#pragma pack(pop)
#endif /* RUCI_ENABLE_APCI */
#endif /* _RUCI_APCI_RX_CMD_H */
