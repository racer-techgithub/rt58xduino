/******************************************************************************
*
* @File			Ruci_ApciRfCmd.h
* @Version
* $Revision: 4157
* $Date: 2021-12-27
* @Brief
* @Note
* Copyright (C) 2019 Rafael Microelectronics Inc. All rights reserved.
*
******************************************************************************/
#ifndef _RUCI_APCI_RF_CMD_H
#define _RUCI_APCI_RF_CMD_H

#include "Ruci_Head.h"

#if (RUCI_ENABLE_APCI)

/******************************************************************************
* DEFINES
*****************************************************************************/

#pragma pack(push)
#pragma pack(1)
#define RUCI_APCI_RF_CMD_HEADER 0x20

// RUCI: SetRfChannel ----------------------------------------------------------
#define RUCI_SET_RF_CHANNEL                     RUCI_NUM_SET_RF_CHANNEL, Ruci_ElmtType_SetRfChannel, Ruci_ElmtNum_SetRfChannel
#define RUCI_CODE_SET_RF_CHANNEL                0x01
#define RUCI_LEN_SET_RF_CHANNEL                 4
#define RUCI_NUM_SET_RF_CHANNEL                 4
#define RUCI_PARA_LEN_SET_RF_CHANNEL            1
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetRfChannel[];
extern const uint8_t Ruci_ElmtNum_SetRfChannel[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_RF_CHANNEL {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         RfChannel;
} sRUCI_PARA_SET_RF_CHANNEL;

// RUCI: SetRfContinuousWave ---------------------------------------------------
#define RUCI_SET_RF_CONTINUOUS_WAVE             RUCI_NUM_SET_RF_CONTINUOUS_WAVE, Ruci_ElmtType_SetRfContinuousWave, Ruci_ElmtNum_SetRfContinuousWave
#define RUCI_CODE_SET_RF_CONTINUOUS_WAVE        0x03
#define RUCI_LEN_SET_RF_CONTINUOUS_WAVE         4
#define RUCI_NUM_SET_RF_CONTINUOUS_WAVE         4
#define RUCI_PARA_LEN_SET_RF_CONTINUOUS_WAVE    1
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetRfContinuousWave[];
extern const uint8_t Ruci_ElmtNum_SetRfContinuousWave[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_RF_CONTINUOUS_WAVE {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         EnableFlag;
} sRUCI_PARA_SET_RF_CONTINUOUS_WAVE;

// RUCI: SetRfSleepOnOff -------------------------------------------------------
#define RUCI_SET_RF_SLEEP_ON_OFF                RUCI_NUM_SET_RF_SLEEP_ON_OFF, Ruci_ElmtType_SetRfSleepOnOff, Ruci_ElmtNum_SetRfSleepOnOff
#define RUCI_CODE_SET_RF_SLEEP_ON_OFF           0x04
#define RUCI_LEN_SET_RF_SLEEP_ON_OFF            4
#define RUCI_NUM_SET_RF_SLEEP_ON_OFF            4
#define RUCI_PARA_LEN_SET_RF_SLEEP_ON_OFF       1
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetRfSleepOnOff[];
extern const uint8_t Ruci_ElmtNum_SetRfSleepOnOff[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_RF_SLEEP_ON_OFF {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         EnableFlag;
} sRUCI_PARA_SET_RF_SLEEP_ON_OFF;

// RUCI: DetectEnergy ----------------------------------------------------------
#define RUCI_DETECT_ENERGY                      RUCI_NUM_DETECT_ENERGY, Ruci_ElmtType_DetectEnergy, Ruci_ElmtNum_DetectEnergy
#define RUCI_CODE_DETECT_ENERGY                 0x05
#define RUCI_LEN_DETECT_ENERGY                  4
#define RUCI_NUM_DETECT_ENERGY                  4
#define RUCI_PARA_LEN_DETECT_ENERGY             1
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_DetectEnergy[];
extern const uint8_t Ruci_ElmtNum_DetectEnergy[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_DETECT_ENERGY {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         RfChannel;
} sRUCI_PARA_DETECT_ENERGY;

// RUCI: SetModem --------------------------------------------------------------
#define RUCI_SET_MODEM                          RUCI_NUM_SET_MODEM, Ruci_ElmtType_SetModem, Ruci_ElmtNum_SetModem
#define RUCI_CODE_SET_MODEM                     0x06
#define RUCI_LEN_SET_MODEM                      6
#define RUCI_NUM_SET_MODEM                      6
#define RUCI_PARA_LEN_SET_MODEM                 3
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetModem[];
extern const uint8_t Ruci_ElmtNum_SetModem[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_MODEM {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         ModemType;
    uint8_t         ClockMode;
    uint8_t         DataRate;
} sRUCI_PARA_SET_MODEM;

// RUCI: SetAccessAddress ------------------------------------------------------
#define RUCI_SET_ACCESS_ADDRESS                 RUCI_NUM_SET_ACCESS_ADDRESS, Ruci_ElmtType_SetAccessAddress, Ruci_ElmtNum_SetAccessAddress
#define RUCI_CODE_SET_ACCESS_ADDRESS            0x07
#define RUCI_LEN_SET_ACCESS_ADDRESS             7
#define RUCI_NUM_SET_ACCESS_ADDRESS             4
#define RUCI_PARA_LEN_SET_ACCESS_ADDRESS        4
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetAccessAddress[];
extern const uint8_t Ruci_ElmtNum_SetAccessAddress[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_ACCESS_ADDRESS {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint32_t        AccessAddress;
} sRUCI_PARA_SET_ACCESS_ADDRESS;

// RUCI: SetAccessAddressFilter ------------------------------------------------
#define RUCI_SET_ACCESS_ADDRESS_FILTER          RUCI_NUM_SET_ACCESS_ADDRESS_FILTER, Ruci_ElmtType_SetAccessAddressFilter, Ruci_ElmtNum_SetAccessAddressFilter
#define RUCI_CODE_SET_ACCESS_ADDRESS_FILTER     0x08
#define RUCI_LEN_SET_ACCESS_ADDRESS_FILTER      4
#define RUCI_NUM_SET_ACCESS_ADDRESS_FILTER      4
#define RUCI_PARA_LEN_SET_ACCESS_ADDRESS_FILTER 1
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetAccessAddressFilter[];
extern const uint8_t Ruci_ElmtNum_SetAccessAddressFilter[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_ACCESS_ADDRESS_FILTER {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         AccessAddressFilterEnable;
} sRUCI_PARA_SET_ACCESS_ADDRESS_FILTER;

#pragma pack(pop)
#endif /* RUCI_ENABLE_APCI */
#endif /* _RUCI_APCI_RF_CMD_H */
