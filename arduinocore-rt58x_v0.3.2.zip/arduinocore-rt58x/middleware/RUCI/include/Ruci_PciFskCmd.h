/******************************************************************************
*
* @File			Ruci_PciFskCmd.h
* @Version
* $Revision: 4235
* $Date: 2022-02-07
* @Brief
* @Note
* Copyright (C) 2019 Rafael Microelectronics Inc. All rights reserved.
*
******************************************************************************/
#ifndef _RUCI_PCI_FSK_CMD_H
#define _RUCI_PCI_FSK_CMD_H

#include "Ruci_Head.h"

#if (RUCI_ENABLE_PCI)

/******************************************************************************
* DEFINES
*****************************************************************************/

#pragma pack(push)
#pragma pack(1)
#define RUCI_PCI_FSK_CMD_HEADER 0x11

// RUCI: InitiateFsk -----------------------------------------------------------
#define RUCI_INITIATE_FSK                       RUCI_NUM_INITIATE_FSK, Ruci_ElmtType_InitiateFsk, Ruci_ElmtNum_InitiateFsk
#define RUCI_CODE_INITIATE_FSK                  0x01
#define RUCI_LEN_INITIATE_FSK                   4
#define RUCI_NUM_INITIATE_FSK                   4
#define RUCI_PARA_LEN_INITIATE_FSK              1
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_InitiateFsk[];
extern const uint8_t Ruci_ElmtNum_InitiateFsk[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_INITIATE_FSK {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         BandType;
} sRUCI_PARA_INITIATE_FSK;

// RUCI: SetFskModem -----------------------------------------------------------
#define RUCI_SET_FSK_MODEM                      RUCI_NUM_SET_FSK_MODEM, Ruci_ElmtType_SetFskModem, Ruci_ElmtNum_SetFskModem
#define RUCI_CODE_SET_FSK_MODEM                 0x02
#define RUCI_LEN_SET_FSK_MODEM                  5
#define RUCI_NUM_SET_FSK_MODEM                  5
#define RUCI_PARA_LEN_SET_FSK_MODEM             2
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetFskModem[];
extern const uint8_t Ruci_ElmtNum_SetFskModem[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_FSK_MODEM {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         DataRate;
    uint8_t         ModIndex;
} sRUCI_PARA_SET_FSK_MODEM;

// RUCI: SetFskMac -------------------------------------------------------------
#define RUCI_SET_FSK_MAC                        RUCI_NUM_SET_FSK_MAC, Ruci_ElmtType_SetFskMac, Ruci_ElmtNum_SetFskMac
#define RUCI_CODE_SET_FSK_MAC                   0x03
#define RUCI_LEN_SET_FSK_MAC                    5
#define RUCI_NUM_SET_FSK_MAC                    5
#define RUCI_PARA_LEN_SET_FSK_MAC               2
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetFskMac[];
extern const uint8_t Ruci_ElmtNum_SetFskMac[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_FSK_MAC {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         CrcType;
    uint8_t         WhiteningEn;
} sRUCI_PARA_SET_FSK_MAC;

// RUCI: SetFskPreamble --------------------------------------------------------
#define RUCI_SET_FSK_PREAMBLE                   RUCI_NUM_SET_FSK_PREAMBLE, Ruci_ElmtType_SetFskPreamble, Ruci_ElmtNum_SetFskPreamble
#define RUCI_CODE_SET_FSK_PREAMBLE              0x04
#define RUCI_LEN_SET_FSK_PREAMBLE               4
#define RUCI_NUM_SET_FSK_PREAMBLE               4
#define RUCI_PARA_LEN_SET_FSK_PREAMBLE          1
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetFskPreamble[];
extern const uint8_t Ruci_ElmtNum_SetFskPreamble[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_FSK_PREAMBLE {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         PreambleLength;
} sRUCI_PARA_SET_FSK_PREAMBLE;

// RUCI: SetFskSfd -------------------------------------------------------------
#define RUCI_SET_FSK_SFD                        RUCI_NUM_SET_FSK_SFD, Ruci_ElmtType_SetFskSfd, Ruci_ElmtNum_SetFskSfd
#define RUCI_CODE_SET_FSK_SFD                   0x05
#define RUCI_LEN_SET_FSK_SFD                    7
#define RUCI_NUM_SET_FSK_SFD                    4
#define RUCI_PARA_LEN_SET_FSK_SFD               4
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetFskSfd[];
extern const uint8_t Ruci_ElmtNum_SetFskSfd[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_FSK_SFD {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint32_t        SfdContent;
} sRUCI_PARA_SET_FSK_SFD;

#pragma pack(pop)
#endif /* RUCI_ENABLE_PCI */
#endif /* _RUCI_PCI_FSK_CMD_H */
