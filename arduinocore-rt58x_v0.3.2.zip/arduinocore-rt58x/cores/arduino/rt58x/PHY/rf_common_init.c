/**
 * @file common_init.c
 * @author
 * @date
 * @brief Brief single line description use for indexing
 *
 * More detailed description can go here
 *
 *
 * @see http://
 */
/**************************************************************************************************
*    INCLUDES
*************************************************************************************************/
#include <stdbool.h>
#include <string.h>
#include "chip_define.h"
#include "comm_subsystem_ahb_phy.h"
#include "rf_common_init.h"
#include "Ruci.h"
#if (RF_CAL_TYPE == RF_CAL_ON)
#include "mp_sector.h"
#endif

#if (CHIP_VERSION == RT58X_MPA)

#if (RF_FW_INCLUDE_PCI == TRUE)
#include "prg_pci_mp_asic_fw.h"
#endif

#if (RF_FW_INCLUDE_BLE == TRUE)
#include "prg_ble_mp_asic_fw.h"
#endif

#if (RF_FW_INCLUDE_MULTI_2P4G == TRUE)
#include "prg_multi_mp_asic_fw.h"
#endif

#if (RF_CAL_TYPE == RF_CAL_ON)
#include "prg_rfk_mp_asic_fw.h"
#endif

#elif (CHIP_VERSION == RT58X_MPB)

#if (RF_FW_INCLUDE_PCI == TRUE)
#include "prg_pci_mpb_asic_fw.h"
#endif

#if (RF_FW_INCLUDE_BLE == TRUE)
#include "prg_ble_mpb_asic_fw.h"
#endif

#if (RF_FW_INCLUDE_MULTI_2P4G == TRUE)
#include "prg_multi_mpb_asic_fw.h"
#endif

#if (RF_CAL_TYPE == RF_CAL_ON)
#include "prg_rfk_mpb_asic_fw.h"
#endif

#endif


/**************************************************************************************************
*    GLOBAL PARAMETERS
*************************************************************************************************/
#if (RF_CAL_TYPE == RF_CAL_ON)
mp_cal_rf_band_support_t    rf_band_info;
mp_cal_rf_trim_t            rf_cal_info[RF_BAND_MAX];
#endif


/**************************************************************************************************
 *    LOCAL FUNCTIONS
 *************************************************************************************************/
#if (RF_CAL_TYPE == RF_CAL_ON)
RF_MCU_RX_CMDQ_ERROR rf_common_event_get(uint8_t *packet_length, uint8_t *event_address)
{
    RF_MCU_RX_CMDQ_ERROR rx_confirm_error = RF_MCU_RX_CMDQ_ERR_INIT;
    uint8_t state = 0;
    do {
        state = (uint8_t)commsubsystem_read_mcu_state();
        state = state & RF_MCU_STATE_EVENT_DONE;
    } while (RF_MCU_STATE_EVENT_DONE != state);
    commsubsystem_send_host_cmd(RF_MCU_STATE_EVENT_DONE);
    state = 0;
    do {
        state = (uint8_t)commsubsystem_read_mcu_state();
        state = state & RF_MCU_STATE_EVENT_DONE;
    } while (0 != state);

    (*packet_length)  = commsubsystem_read_cmd_queue(event_address, &rx_confirm_error);

    return rx_confirm_error;
}

void rf_common_cmd_send(uint8_t *cmd_address, uint8_t cmd_length)
{
    /* wake up RF to clear interrupt status */
    commsubsystem_host_wakeup();
    while (commsubsystem_check_power_state() != 0x03) {
        //printf("[W] PWR state error(%d) in rf_common_cmd_send\n",commsubsystem_check_power_state());
    }
    while (RF_MCU_TX_CMDQ_SET_SUCCESS != commsubsystem_send_cmd_queue(cmd_address, cmd_length)) {
        // printf("[E] command queue is FULL\n");
    }
}

void rf_common_cal_isr_hdlr(uint8_t interrupt_status)
{
    commsubsystem_clean_interrupt(interrupt_status);
}

bool rf_common_cal_enable(RF_BAND band_idx, mp_cal_rf_trim_t *p_rf_cal_info)
{
    sRUCI_PARA_INITIATE_BLE sBleInitCmd;
    sRUCI_PARA_INITIATE_FSK sFskInitCmd;
    sRUCI_PARA_SET_CALIBRATION_ENABLE sRfCalCmd;
    sRUCI_PARA_SET_CALIBRATION_ENABLE_EVENT sRfCalCmdEvent;
    sRUCI_PARA_CNF_EVENT sCnfEvent;
    sRUCI_PARA_CMN_CNF_EVENT sCmnCnfEvent;
    uint8_t event_len;
    RF_MCU_RX_CMDQ_ERROR event_status = RF_MCU_RX_CMDQ_ERR_INIT;
    uint8_t set_calibration_enable_event_len = 0;
    RF_MCU_RX_CMDQ_ERROR set_calibration_enable_event_status = RF_MCU_RX_CMDQ_ERR_INIT;

    /* Send HW initialization command */
    if (band_idx == RF_BAND_2P4G)
    {
        SET_RUCI_PARA_BLE_INIT(&sBleInitCmd);
        RUCI_ENDIAN_CONVERT((uint8_t *)&sBleInitCmd, RUCI_INITIATE_BLE);

        enter_critical_section();
        event_len = 0;
        rf_common_cmd_send((uint8_t *)&sBleInitCmd, RUCI_LEN_INITIATE_BLE);
        event_status = rf_common_event_get(&event_len, (uint8_t *)&sCnfEvent);
        leave_critical_section();

        RUCI_ENDIAN_CONVERT((uint8_t *)&sCnfEvent, RUCI_CNF_EVENT);
        if ((event_status != RF_MCU_RX_CMDQ_GET_SUCCESS) ||
            (sCnfEvent.PciCmdSubheader != RUCI_CODE_INITIATE_BLE) ||
            (sCnfEvent.Status != 0))
            return false;
    }
    else
    {
        SET_RUCI_PARA_FSK_INIT(&sFskInitCmd, 0);
        RUCI_ENDIAN_CONVERT((uint8_t *)&sFskInitCmd, RUCI_INITIATE_FSK);

        enter_critical_section();
        event_len = 0;
        rf_common_cmd_send((uint8_t *)&sFskInitCmd, RUCI_LEN_INITIATE_FSK);
        event_status = rf_common_event_get(&event_len, (uint8_t *)&sCnfEvent);
        leave_critical_section();

        RUCI_ENDIAN_CONVERT((uint8_t *)&sCnfEvent, RUCI_CNF_EVENT);
        if ((event_status != RF_MCU_RX_CMDQ_GET_SUCCESS) ||
            (sCnfEvent.PciCmdSubheader != RUCI_CODE_INITIATE_FSK) ||
            (sCnfEvent.Status != 0))
            return false;
    }

    /* Send Calibration command */
    SET_RUCI_PARA_COMMON_CALIBRATION_EN(&sRfCalCmd, 0);
    RUCI_ENDIAN_CONVERT((uint8_t *)&sRfCalCmd, RUCI_SET_CALIBRATION_ENABLE);

    enter_critical_section();
    event_len = 0;
    rf_common_cmd_send((uint8_t *)&sRfCalCmd, RUCI_LEN_SET_CALIBRATION_ENABLE);
    event_status = rf_common_event_get(&event_len, (uint8_t *)&sCmnCnfEvent);
    set_calibration_enable_event_status = rf_common_event_get(&set_calibration_enable_event_len, (uint8_t *)&sRfCalCmdEvent);
    leave_critical_section();

    RUCI_ENDIAN_CONVERT((uint8_t *)&sCmnCnfEvent, RUCI_CMN_CNF_EVENT);
    if ((event_status != RF_MCU_RX_CMDQ_GET_SUCCESS) ||
        (sCmnCnfEvent.CmnCmdSubheader != RUCI_CODE_SET_CALIBRATION_ENABLE) ||
        (sCmnCnfEvent.Status != 0))
        return false;

    RUCI_ENDIAN_CONVERT((uint8_t *)&sRfCalCmdEvent, RUCI_SET_CALIBRATION_ENABLE_EVENT);
    if ((set_calibration_enable_event_status != RF_MCU_RX_CMDQ_GET_SUCCESS) ||
        (sRfCalCmdEvent.Subheader != RUCI_CODE_SET_CALIBRATION_ENABLE_EVENT))
        return false;

    /* Update calibration results */
    p_rf_cal_info->cal_cfg = sRfCalCmdEvent.Status;
    p_rf_cal_info->rx_filter_cap = sRfCalCmdEvent.RxFilter;
    p_rf_cal_info->tx_dc_offset_i = sRfCalCmdEvent.TxLo[0];
    p_rf_cal_info->tx_dc_offset_q = sRfCalCmdEvent.TxLo[1];
    p_rf_cal_info->tx_iqc_a = sRfCalCmdEvent.TxSb[0];
    p_rf_cal_info->tx_iqc_b = sRfCalCmdEvent.TxSb[1];
    p_rf_cal_info->tx_iqc_c = sRfCalCmdEvent.TxSb[2];

    return true;
}

#endif

bool rf_common_cal_init()
{
    #if (RF_CAL_TYPE == RF_CAL_ON)
    mp_cal_rf_trim_t            *p_rf_cal_info;
    COMM_SUBSYSTEM_ISR_CONFIG   isr_config;
    RF_BAND                     band_idx;
    bool                        is_start_up, is_fw_loaded;
    uint32_t                    regValue;
    uint32_t                    mp_id_map[RF_BAND_MAX] = {MP_ID_RFTRIM_2P4G, MP_ID_RFTRIM_SUBG0, MP_ID_RFTRIM_SUBG1, MP_ID_RFTRIM_SUBG2};

    /* Initial setting */
    is_start_up = false;
    is_fw_loaded = false;

    /* Check if it's start-up or not */
    // Check retention register. If bit 0 = 0 or bit 1 = 0, it means the calibration has been executed at start-up.
    sys_get_retention_reg(7, &regValue);
    if (((regValue & 0x00000003) != 0x00000003))
        is_start_up = true;

    /* Read RF band info from MP sector */
    if (MpCalRftrimRead(MP_ID_RF_BAND_SUPPORT, MP_CNT_RF_BAND_SUPPORT, (uint8_t*)(&rf_band_info)) != STATUS_SUCCESS)
    {
        // Force to 2.4GHz RF if MP sector doesn't exist
        rf_band_info.rf_band = RF_BAND_SUPP(RF_BAND_2P4G) | RF_BAND_SUPP(RF_BAND_SUB1G0);
    }

    /* RF calibration loop */
    for (band_idx = 0; band_idx < RF_BAND_MAX; band_idx++)
    {
        /* By RF band if it's not supported */
        if (!(rf_band_info.rf_band & RF_BAND_SUPP(band_idx)))
            continue;

        /* Read from MP sector */
        p_rf_cal_info = &rf_cal_info[band_idx];
        if (MpCalRftrimRead(mp_id_map[band_idx], MP_CNT_RFTRIM, (uint8_t*)(p_rf_cal_info)) != STATUS_SUCCESS)
        {
            // Force to AON mode if MP sector doesn't exist
            p_rf_cal_info->mode = RF_CAL_AON;
        }
        else if ((p_rf_cal_info->mode != RF_CAL_MP) && (p_rf_cal_info->mode != RF_CAL_STARTUP) && (p_rf_cal_info->mode != RF_CAL_AON))
        {
            // Force to AON mode if mode is out of range
            p_rf_cal_info->mode = RF_CAL_AON;
        }

        /* Bypass calibration if it's in MP calibration mode */
        if (p_rf_cal_info->mode == RF_CAL_MP)
            continue;
        /* Bypass calibration if it's not (AON calibration mode) or (start-up) or (empty calibration default setting) */
        if (!((is_start_up) || (p_rf_cal_info->mode == RF_CAL_AON) ||
            ((p_rf_cal_info->cal_cfg == 0xFFFF) && (p_rf_cal_info->rx_filter_cap == 0xFFFF) &&
            (p_rf_cal_info->tx_dc_offset_i == 0xFFFF) && (p_rf_cal_info->tx_dc_offset_q == 0xFFFF) &&
            (p_rf_cal_info->tx_iqc_a == 0xFFFF) && (p_rf_cal_info->tx_iqc_b == 0xFFFF) && (p_rf_cal_info->tx_iqc_c == 0xFFFF))))
            continue;

        /* Download RF calibration FW */
        if (!is_fw_loaded)
        {
            isr_config.commsubsystem_isr = rf_common_cal_isr_hdlr;
            isr_config.content = 0;
            if(commsubsystem_init(true, firmware_program_rfk, sizeof(firmware_program_rfk), isr_config, RF_MCU_INIT_NO_ERROR) != RF_MCU_INIT_NO_ERROR)
                return false;
            is_fw_loaded = true;
        }

        /* RF calibration */
        if (rf_common_cal_enable(band_idx, p_rf_cal_info) == false)
            return false;

        /* Store calibration results if RF calibration is in STARTUP mode */
        if (p_rf_cal_info->mode == RF_CAL_STARTUP)
            MpCalRftrimWrite(mp_id_map[band_idx], p_rf_cal_info);
    }

    /* Update retention register */
    sys_set_retention_reg(7, regValue|0x00000003);  // Raise bit 0 and bit 1
    #endif

    return true;
}

bool rf_common_cal_set()
{
    #if (RF_CAL_TYPE == RF_CAL_ON)
    mp_cal_rf_trim_t                    *p_rf_cal_info;
    uint16_t                            int_enable;
    sRUCI_PARA_SET_CALIBRATION_SETTING  sRfCalSettingCmd;
    sRUCI_PARA_CMN_CNF_EVENT            sCmnCnfEvent;
    uint8_t                             event_len = 0;
    RF_MCU_RX_CMDQ_ERROR                event_status = RF_MCU_RX_CMDQ_ERR_INIT;
    RF_BAND                             band_idx;
    // uint32_t                            mp_id_map[RF_BAND_MAX] = {MP_ID_RFTRIM_2P4G, MP_ID_RFTRIM_SUBG0, MP_ID_RFTRIM_SUBG1, MP_ID_RFTRIM_SUBG2};

    /* Using polling mode. Store interrupt setting and disable all interrupt */
    int_enable = commsubsystem_get_interrupt();
    commsubsystem_set_interrupt(0x0000);

    /* Send calibration setting */
    for (band_idx = 0; band_idx < RF_BAND_MAX; band_idx++)
    {
        /* By RF band if it's not supported */
        if (!(rf_band_info.rf_band & RF_BAND_SUPP(band_idx)))
            continue;

        /* Read setting from MP sector */
        p_rf_cal_info = &rf_cal_info[band_idx];

        /* Update calibration setting to lower layer HW */
        SET_RUCI_PARA_COMMON_CALIBRATION_SETTING(&sRfCalSettingCmd, band_idx, (uint8_t)(p_rf_cal_info->cal_cfg),
            (uint8_t)(p_rf_cal_info->rx_filter_cap), (uint8_t)(p_rf_cal_info->tx_dc_offset_i), (uint8_t)(p_rf_cal_info->tx_dc_offset_q),
            (uint8_t)(p_rf_cal_info->tx_iqc_a), (uint8_t)(p_rf_cal_info->tx_iqc_b), (uint8_t)(p_rf_cal_info->tx_iqc_c));
        RUCI_ENDIAN_CONVERT((uint8_t *)&sRfCalSettingCmd, RUCI_SET_CALIBRATION_SETTING);

        enter_critical_section();
        event_len = 0;
        rf_common_cmd_send((uint8_t *)&sRfCalSettingCmd, RUCI_LEN_SET_CALIBRATION_SETTING);
        event_status = rf_common_event_get(&event_len, (uint8_t *)&sCmnCnfEvent);
        leave_critical_section();

        RUCI_ENDIAN_CONVERT((uint8_t *)&sCmnCnfEvent, RUCI_CMN_CNF_EVENT);
        if ((event_status != RF_MCU_RX_CMDQ_GET_SUCCESS) ||
            (sCmnCnfEvent.CmnCmdSubheader != RUCI_CODE_SET_CALIBRATION_SETTING) ||
            (sCmnCnfEvent.Status != 0))
            return false;
    }

    /* Enable interrupt */
    commsubsystem_clean_interrupt(0xFF);
    commsubsystem_set_interrupt(int_enable);
    #endif

    return true;
}

bool ruci_ver_check(void)
{
    sRUCI_PARA_GET_FW_VER sGetRfbVerCmd = {0};
    sRUCI_PARA_GET_FW_VER_EVENT sGetRfbVerEvent = {0};
    sRUCI_PARA_CMN_CNF_EVENT sCmnCnfEvent = {0};
    uint8_t event_len = 0;
    RF_MCU_RX_CMDQ_ERROR event_status = RF_MCU_RX_CMDQ_ERR_INIT;
    uint8_t get_rfb_ver_event_len = 0;
    RF_MCU_RX_CMDQ_ERROR get_rfb_ver_event_status = RF_MCU_RX_CMDQ_ERR_INIT;

    SET_RUCI_PARA_COMMON_GET_FW_VER(&sGetRfbVerCmd);

    RUCI_ENDIAN_CONVERT((uint8_t *)&sGetRfbVerCmd, RUCI_GET_FW_VER);

    enter_critical_section();
    rf_common_cmd_send((uint8_t *)&sGetRfbVerCmd, RUCI_LEN_GET_FW_VER);
    event_status = rf_common_event_get(&event_len, (uint8_t *)&sCmnCnfEvent);
    get_rfb_ver_event_status = rf_common_event_get(&get_rfb_ver_event_len, (uint8_t *)&sGetRfbVerEvent);
    leave_critical_section();

    RUCI_ENDIAN_CONVERT((uint8_t *)&sCmnCnfEvent, RUCI_CNF_EVENT);
    if ((event_status != RF_MCU_RX_CMDQ_GET_SUCCESS) 
        || (sCmnCnfEvent.CmnCmdSubheader != RUCI_CODE_GET_FW_VER)
        || (sCmnCnfEvent.Status != 0))
        return false;

    RUCI_ENDIAN_CONVERT((uint8_t *)&sGetRfbVerEvent, RUCI_GET_FW_VER_EVENT);
    if ((get_rfb_ver_event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        || (sGetRfbVerEvent.Subheader != RUCI_CODE_GET_FW_VER_EVENT))
        return false;
    if(RUCI_VERSION != sGetRfbVerEvent.RuciFwVer)
        return false;
    return true;
}
/**************************************************************************************************
 *    GLOBAL FUNCTIONS
 *************************************************************************************************/
/* RF Common initialization with different FW */
bool rf_common_init_by_fw(RF_FW_LOAD_SELECT fw_select, COMM_SUBSYSTEM_ISR_t isr_func)
{

    const uint8_t *fw_load;
    uint32_t firmware_size;
    COMM_SUBSYSTEM_ISR_CONFIG isr_config;

    if(fw_select == RF_FW_LOAD_SELECT_RUCI_CMD){
#if (RF_FW_INCLUDE_PCI == TRUE)
        /* Pure MAC FW */
        fw_load = firmware_program_ruci;
        firmware_size = sizeof(firmware_program_ruci);
#else
        return false;
#endif
    }
    else if(fw_select == RF_FW_LOAD_SELECT_BLE_CONTROLLER){
#if (RF_FW_INCLUDE_BLE == TRUE)
        /* Pure BLE FW */
        fw_load = firmware_program_ble;
        firmware_size = sizeof(firmware_program_ble);
#else
        return false;
#endif
    }
    else if(fw_select == RF_FW_LOAD_SELECT_MULTI_PROTCOL_2P4G){
#if (RF_FW_INCLUDE_MULTI_2P4G == TRUE)
        /* Multi protocol FW for 2.4G */
        fw_load = firmware_program_multi;
        firmware_size = sizeof(firmware_program_multi);
#else
        return false;
#endif
    }
    else if(fw_select == RF_FW_LOAD_SELECT_RFK){
#if (RF_CAL_TYPE == RF_CAL_ON)
        /* RF calibration FW */
        fw_load = firmware_program_rfk;
        firmware_size = sizeof(firmware_program_rfk);
#else
        return false;
#endif
    }
    else{
        return false;
    }

    /* ISR initialization */
    isr_config.commsubsystem_isr = isr_func;
    isr_config.content = 0;

    /* RF calibration */
    if (rf_common_cal_init() == false)
        return false;

    /* RF Chip initialization */
    if(commsubsystem_init(true,fw_load,firmware_size,isr_config,RF_MCU_INIT_NO_ERROR) != RF_MCU_INIT_NO_ERROR){
        return false;
    }
#if 0
    /* Check RUCI version */
    if (ruci_ver_check() == false)
        return false;
#endif
    /* Set calibration setting */
    if (rf_common_cal_set() == false)
        return false;

    return true;
}




