#pragma once
#ifndef __PINS_ARDUINO_H__
#define __PINS_ARDUINO_H__

#define PIN_GPIO_0 (0)
#define PIN_GPIO_1 (1)
#define PIN_GPIO_2 (2)
#define PIN_GPIO_3 (3)
#define PIN_GPIO_4 (4)
#define PIN_GPIO_5 (5)
#define PIN_GPIO_6 (6)
#define PIN_GPIO_7 (7)
#define PIN_GPIO_8 (8)
#define PIN_GPIO_9 (9)
#define PIN_GPIO_10 (10)
#define PIN_GPIO_11 (11)
#define PIN_GPIO_12 (12)
#define PIN_GPIO_13 (13)
#define PIN_GPIO_14 (14)
#define PIN_GPIO_15 (15)
#define PIN_GPIO_16 (16)
#define PIN_GPIO_17 (17)
#define PIN_GPIO_18 (18)
#define PIN_GPIO_19 (19)
#define PIN_GPIO_20 (20)
#define PIN_GPIO_21 (21)
#define PIN_GPIO_22 (22)
#define PIN_GPIO_23 (23)
#define PIN_GPIO_24 (24)
#define PIN_GPIO_25 (25)
#define PIN_GPIO_26 (26)
#define PIN_GPIO_27 (27)
#define PIN_GPIO_28 (28)
#define PIN_GPIO_29 (29)
#define PIN_GPIO_30 (30)
#define PIN_GPIO_31 (31)

#define PIN_SPI0_SCK PIN_GPIO_6
#define PIN_SPI0_CS PIN_GPIO_7
#define PIN_SPI0_MOSI PIN_GPIO_8
#define PIN_SPI0_MISO PIN_GPIO_9

#define PIN_SPI1_SCK PIN_GPIO_28
#define PIN_SPI1_CS PIN_GPIO_29
#define PIN_SPI1_MOSI PIN_GPIO_30
#define PIN_SPI1_MISO PIN_GPIO_31

#define PIN_PWM0 PIN_GPIO_8
#define PIN_PWM1 PIN_GPIO_9
#define PIN_PWM2 PIN_GPIO_14
#define PIN_PWM3 PIN_GPIO_15
#define PIN_PWM4 PIN_GPIO_18 // no pwm output

#define PIN_TONE0 PIN_PWM0
#define PIN_TONE1 PIN_PWM1
#define PIN_TONE2 PIN_PWM2
#define PIN_TONE3 PIN_PWM3
#define PIN_TONE4 PIN_PWM4 // no pwm output

#endif // !__PINS_ARDUINO_H__
