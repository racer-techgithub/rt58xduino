/******************************************************************************
*
* @File			Ruci_CmnSysCmd.h
* @Version
* $Revision: 4235
* $Date: 2022-02-07
* @Brief
* @Note
* Copyright (C) 2019 Rafael Microelectronics Inc. All rights reserved.
*
******************************************************************************/
#ifndef _RUCI_CMN_SYS_CMD_H
#define _RUCI_CMN_SYS_CMD_H

#include "Ruci_Head.h"

#if (RUCI_ENABLE_CMN)

/******************************************************************************
* DEFINES
*****************************************************************************/

#pragma pack(push)
#pragma pack(1)
#define RUCI_CMN_SYS_CMD_HEADER 0x30

// RUCI: GetFwVer --------------------------------------------------------------
#define RUCI_GET_FW_VER                         RUCI_NUM_GET_FW_VER, Ruci_ElmtType_GetFwVer, Ruci_ElmtNum_GetFwVer
#define RUCI_CODE_GET_FW_VER                    0x01
#define RUCI_LEN_GET_FW_VER                     3
#define RUCI_NUM_GET_FW_VER                     3
#define RUCI_PARA_LEN_GET_FW_VER                0
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_GetFwVer[];
extern const uint8_t Ruci_ElmtNum_GetFwVer[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_GET_FW_VER {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
} sRUCI_PARA_GET_FW_VER;

#pragma pack(pop)
#endif /* RUCI_ENABLE_CMN */
#endif /* _RUCI_CMN_SYS_CMD_H */
