#ifndef __RT58X_SERIAL_H__
#define __RT58X_SERIAL_H__

#ifdef __cplusplus

#include "HardwareSerial.h"
#include <stdlib.h>
#include <stdint.h>
#include <stddef.h>
#include <assert.h>

extern "C"
{
#include "cm3_mcu.h"
#include "sysctrl.h"
#include "uart_drv.h"
#include "circular_buffer.h"
}

class RT58xSerial : public arduino::HardwareSerial
{
private:
    int uart_id;
    void init(int uart_id);
    void deinit();
    void config(unsigned long buad, uint16_t config);
    cbuf_handle_t rxBufHandle;
    cbuf_handle_t txBufHandle;
    uint8_t rxBuf[256];
    uint8_t txBuf[256];
    uint8_t recvOneByte;
    uint8_t sendOneByte;
    static void uart_event_handler(uint32_t event, void *p_context);

public:
    RT58xSerial();
    RT58xSerial(int uart_id);
    virtual void begin(unsigned long baud) override
    {
        this->config(baud, SERIAL_8N1);
    }
    virtual void begin(unsigned long baud, uint16_t config) override
    {
        this->config(baud, config);
    }
    virtual void end() override
    {
        this->deinit();
    }
    virtual int available(void) override
    {
        int size;
        enter_critical_section();
        size = circular_buf_capacity(this->rxBufHandle) - circular_buf_size(this->rxBufHandle);
        leave_critical_section();
        return size;
    }
    virtual int peek(void) override
    {
        uint8_t val;
        int status;
        enter_critical_section();
        status = circular_buf_peek(this->rxBufHandle, &val, 1);
        leave_critical_section();
        return status == 0 ? val : -1;
    }
    virtual int read(void) override
    {
        uint8_t val;
        int status = -1;
        enter_critical_section();
        status = circular_buf_get(this->rxBufHandle, &val);
        leave_critical_section();
        return status == 0 ? val : -1;
    }
    virtual void flush(void) override
    {
        size_t size = 0;
        for (;;)
        {
            enter_critical_section();
            size = circular_buf_size(this->txBufHandle);
            leave_critical_section();
            if (size == 0)
            {
                return;
            }
            __WFI();
        }
    }
    virtual size_t write(uint8_t c) override
    {
        if (uart_tx_in_progress(this->uart_id) == false)
        {
            this->sendOneByte = c;
            uart_tx(this->uart_id, (uint8_t *)&this->sendOneByte, 1);
            return 1;
        }
        int status = -1;
        enter_critical_section();
        status = circular_buf_try_put(this->txBufHandle, c);
        leave_critical_section();
        return status == 0 ? 1 : 0;
    }
    virtual size_t write(const uint8_t *buffer, size_t size) override
    {
        int status = -1;
        for (uint32_t i = 0; i < size; i++)
        {
            enter_critical_section();
            status = circular_buf_try_put(this->txBufHandle, buffer[i]);
            leave_critical_section();
            if (status == -1)
            {
                break;
            }
        }
        if (uart_tx_in_progress(this->uart_id) == false)
        {
            enter_critical_section();
            status = circular_buf_get(this->txBufHandle, &this->sendOneByte);
            leave_critical_section();
            if (status == 0)
            {
                uart_tx(this->uart_id, &this->sendOneByte, 1);
            }
        }
        return 0;
    }
    using Print::write; // pull in write(str) and write(buf, size) from Print
    virtual operator bool() { return true; }
};

extern RT58xSerial Serial0;
extern RT58xSerial Serial1;
extern RT58xSerial Serial2;

#define Serial Serial0

#endif // ! __cplusplus
#endif // ! __RT58X_SERIAL_H__