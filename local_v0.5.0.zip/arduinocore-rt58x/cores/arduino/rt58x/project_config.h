/******************************************************************************
* @file     project_config.h
* @version
* @brief   define project config
*
* @copyright
******************************************************************************/

#include "chip_define.h"

#ifndef ___PROJECT_CONFIG_H__
#define ___PROJECT_CONFIG_H__

#define MODULE_ENABLE(module) (module > 0)

/*
 * If system support multi-tasking, some hardware need mutex to protect
 */
#define SUPPORT_MULTITASKING 1

#if (CHIP_VERSION >= RT58X_MPA)

#endif

/*enable this option, UART1 will support CTS/RTS pin for flow control*/
#define SUPPORT_UART1_FLOWCNTL 0

/*Support AES  */
#define CRYPTO_AES_ENABLE 1

/*Support ECC SECP192R1/P192 curve */
#define CRYPTO_SECP192R1_ENABLE 0

/*Support ECC SECP256R1/P256 curve */
#define CRYPTO_SECP256R1_ENABLE 1

/* Support ECC SECT163R2/B163 curve */
#define CRYPTO_SECT163R2_ENABLE 0

/* SUPPORT_FREERTOS_PORT */
#ifndef SUPPORT_FREERTOS_PORT
#define SUPPORT_FREERTOS_PORT 1
#endif // !SUPPORT_FREERTOS_PORT


/*SUPPORT_FREERTOS_SLEEP */
#ifndef SUPPORT_FREERTOS_SLEEP
#define SUPPORT_FREERTOS_SLEEP 0
#endif // !SUPPORT_FREERTOS_SLEEP

/*SUPPORT_FREERTOS_NEST_CRITICAL */
#ifndef SUPPORT_FREERTOS_NEST_CRITICAL
#define SUPPORT_FREERTOS_NEST_CRITICAL 0
#endif // !SUPPORT_FREERTOS_NEST_CRITICAL


/* Main Oscillator frequency = 64MHz */
#ifndef SET_SYS_CLK
#define SET_SYS_CLK SYS_CLK_64MHZ
#endif // !SET_SYS_CLK


/* Main Oscillator frequency = 40KHz */
#define LFSOC_CLK 40000

/* BLE_SUPPORT_NUM_CONN_MAX */
#ifndef BLE_SUPPORT_NUM_CONN_MAX
#define BLE_SUPPORT_NUM_CONN_MAX 1
#endif // !BLE_SUPPORT_NUM_CONN_MAX


#endif
