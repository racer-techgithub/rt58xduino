/**
 * @file radio.h
 * @author
 * @date
 * @brief Brief single line description use for indexing
 *
 * More detailed description can go here
 *
 *
 * @see http://
 */
#ifndef _RADIO_H_
#define _RADIO_H_
#include <stdbool.h>
#include "middleware/RFB/Include/rfb_comm.h"
#include "middleware/RFB/Include/rfb.h"
/**************************************************************************************************
 *    INCLUDES
 *************************************************************************************************/

/**************************************************************************************************
 *    Global Prototypes
 *************************************************************************************************/
#endif
