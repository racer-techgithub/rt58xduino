/** @file ble_cmd_common.c
 *
 * @brief Define BLE common definition, structure and functions.
 *
 */

/**************************************************************************************************
 *    INCLUDES
 *************************************************************************************************/
#include <string.h>
#include "FreeRTOS.h"
#include "middleware/ble_api.h"
#include "middleware/ble_common.h"
#include "middleware/ble_printf.h"

/**************************************************************************************************
 *    PUBLIC FUNCTIONS
 *************************************************************************************************/

/** BLE Set PHY controller initialization function.
 */
ble_err_t
ble_cmd_phy_controller_init(void)
{
    int status;
    ble_tlv_t *p_ble_tlv;
    ble_common_controller_info_t *ble_common_controller_info;

    status = BLE_ERR_OK;
    p_ble_tlv = pvPortMalloc(sizeof(ble_tlv_t) + sizeof(ble_common_controller_info_t));

    if (p_ble_tlv != NULL)
    {
        p_ble_tlv->type = TYPE_BLE_COMMON_CONTROLLER_INIT;
        p_ble_tlv->length = sizeof(ble_common_controller_info_t);
        ble_common_controller_info = (ble_common_controller_info_t *)p_ble_tlv->value;
        ble_common_controller_info->company_id = BLE_COMPANY_ID;
        ble_common_controller_info->version = BLE_STACK_VERSION;
        memcpy(ble_common_controller_info->le_event_mask, g_le_event_mask, BLE_EVENT_MASK_LENGTH);
        memcpy(ble_common_controller_info->public_addr, g_ble_default_public_addr, BLE_ADDR_LEN);

        status = ble_event_msg_sendto(p_ble_tlv);
        if (status != BLE_ERR_OK) // send to BLE stack
        {
            info_color(LOG_RED, "<TYPE_BLE_COMMON_CONTROLLER_INIT> Send msg to BLE stack fail\n");
        }
        vPortFree(p_ble_tlv);
    }
    else
    {
        info_color(LOG_RED, "<TYPE_BLE_COMMON_CONTROLLER_INIT> malloc fail\n");
        status = BLE_ERR_ALLOC_MEMORY_FAIL;
    }

    return (ble_err_t)status;
}
