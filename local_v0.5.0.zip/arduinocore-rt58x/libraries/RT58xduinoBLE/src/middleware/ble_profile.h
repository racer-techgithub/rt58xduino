/**************************************************************************/ /**
                                                                              * @file  ble_profile.h
                                                                              * @brief Provide the declarations that for BLE Profile subsystem needed.
                                                                              *****************************************************************************/

#ifndef _BLE_PROFILE_H_
#define _BLE_PROFILE_H_

#include "middleware/ble_common.h"
#include "middleware/ble_service_common.h"
#include <stdint.h>

/**************************************************************************
 * Profile Application GENERAL Public Definitions and Functions
 **************************************************************************/
/** @defgroup profileAppGeneralFunc Profile Application General Definitions and Functions
 * @{
 * @details Here shows the general definitions of the application profile.
 * @}
 **************************************************************************/
/** Define the maximum number of BLE GAPS link. */
#define MAX_NUM_CONN_GAPS 1

/** Define the maximum number of BLE GATTS link. */
#define MAX_NUM_CONN_GATTS 1

/** Define the maximum number of BLE DIS link. */
#define MAX_NUM_CONN_DIS 1

/** Define the maximum number of BLE TRSPS link. */
#define MAX_NUM_CONN_TRSPS 1

/**************************************************************************
 * Profile Application LINK Public Definitions and Functions
 **************************************************************************/
#ifndef ATT_MAX_COUNT
#define ATT_MAX_COUNT 256
#endif // !ATT_MAX_COUNT
/**************************************************************************
 * Global Functions
 **************************************************************************/

/**************************************************************************
 * Extern Definitions
 **************************************************************************/

/** Extern maximum Number of Host Connection Link Definition. */
extern const uint8_t max_num_conn_host;

/** Extern BLE Connection Links Definition. */
extern ble_att_role_by_id_t att_db_link[];

/** Extern BLE Connection Link Parameter Table Definition. */
extern ble_att_db_mapping_by_id_t att_db_mapping[];

/** Extern BLE Connection Link Mapping Size Definition. */
extern ble_att_db_mapping_by_id_size_t att_db_mapping_size[];

#endif //_BLE_PROFILE_H_
