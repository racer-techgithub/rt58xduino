
#include "middleware/ble_common.h"
#include "middleware/ble_att_gatt.h"
#include "middleware/ble_profile.h"

#ifndef COUNTOF
#define COUNTOF(x) (sizeof(x) / sizeof(x[0]))
#endif // !COUNTOF

/** BLE Connection Links Definition
 * @attention Do NOT modify the name of this definition.
 * @note If there does not support server or client please set to "((const ble_att_param_t **)0)" which means NULL.
 */
ble_att_role_by_id_t att_db_link[] =
    {
        {
            // Link 0
            ((const ble_att_param_t **)0),
            // Client Profile
            ((const ble_att_param_t **)0),
            // Server Profile
        },
};

/** BLE Connection Link Parameter Table Definition
 * @attention Do NOT modify the name of this definition.
 * @note If there does not support server or client please set to "((ble_att_handle_param_t *)0)" which means NULL.
 */
ble_att_db_mapping_by_id_t att_db_mapping[] =
    {
        {
            // Link 0
            ((ble_att_handle_param_t *)0),
            // Client Link Parameter
            ((ble_att_handle_param_t *)0),
            // Server Link Parameter
        },
};

/** BLE Connection Link Mapping Size Definition
 * @attention Do NOT modify the name of this definition.
 * @note If there does not support server or client please set to 0.
 */
ble_att_db_mapping_by_id_size_t att_db_mapping_size[] =
    {
        {
            // Link 0
            0,
            // Client Link Mapping Size
            0,
            // Server Link Mapping Size
        },
};

/** Maximum Number of Host Connection Link Definition
 * @attention Do NOT modify this definition.
 * @note Defined for host layer.
 */
const uint8_t max_num_conn_host = (COUNTOF(att_db_mapping_size));

/** Host Connection Link Information Definition
 * @attention Do NOT modify this definition.
 * @note Defined for host layer.
 */
uint8_t *param_rsv_host[COUNTOF(att_db_mapping_size)][(REF_SIZE_LE_HOST_PARA >> 2)];