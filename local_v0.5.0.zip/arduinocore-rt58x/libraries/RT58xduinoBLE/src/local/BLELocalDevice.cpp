/*
  This file is part of the ArduinoBLE library.
  Copyright (c) 2018 Arduino SA. All rights reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "utility/ATT.h"
#include "utility/HCI.h"
#include "utility/GAP.h"
#include "utility/GATT.h"
#include "utility/L2CAPSignaling.h"
#include "utility/RT58xBle.h"

#include "BLELocalDevice.h"

#include "middleware/ble_api.h"
#include "middleware/ble_common.h"
#include "middleware/ble_att_gatt.h"
#include "middleware/ble_advertising.h"
#include "middleware/ble_att_gatt.h"
#include "util_log.h"
#include "middleware/ble_service_common.h"

#if defined(ARDUINO_PORTENTA_H7_M4) || defined(ARDUINO_PORTENTA_H7_M7)
#ifndef BT_REG_ON
#define BT_REG_ON PJ_12
#endif
#endif

BLELocalDevice::BLELocalDevice()
{
  _advertisingData.setFlags(BLEFlagsGeneralDiscoverable | BLEFlagsBREDRNotSupported);
}

BLELocalDevice::~BLELocalDevice()
{
}

int BLELocalDevice::begin()
{

  RT58xBLE.begin();

  ble_err_t status = BLE_ERR_OK;
  status = ble_cmd_phy_controller_init();
  if (status != BLE_ERR_OK)
  {
    return status;
  }
  // set ble mac address
  const ble_gap_addr_t DEVICE_ADDR = {
      .addr_type = RANDOM_ADDR,
      .addr = {0x21, 0x22, 0x23, 0x24, 0x25, 0xC6}};
  status = ble_cmd_device_addr_set((ble_gap_addr_t *)&DEVICE_ADDR);
  if (status != BLE_ERR_OK)
  {
    return status;
  }
  // Set preferred data length
  status = ble_cmd_suggest_data_len_set(BLE_GATT_DATA_LENGTH_MAX);
  if (status != BLE_ERR_OK)
  {
    return status;
  }
  // set preferred MTU size and data length
  status = ble_cmd_default_mtu_size_set(APP_P_HOST_ID, BLE_GATT_ATT_MTU_MAX);
  if (status != BLE_ERR_OK)
  {
    info_color(LOG_RED, "ble_cmd_default_mtu_size_set() status = %d\n", status);
    return status;
  }

  GATT.begin();

  return status == BLE_ERR_OK;
}

void BLELocalDevice::end()
{
  GATT.end();
}

void BLELocalDevice::poll()
{
  RT58xBLE.poll();
}

void BLELocalDevice::poll(unsigned long timeout)
{
  HCI.poll(timeout);
}

bool BLELocalDevice::connected() const
{
  HCI.poll();

  return ATT.connected();
}

bool BLELocalDevice::disconnect()
{
  return ATT.disconnect();
}

String BLELocalDevice::address() const
{
  uint8_t addr[6] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
  HCI.readBdAddr(addr);

  char result[18];
  sprintf(result, "%02x:%02x:%02x:%02x:%02x:%02x", addr[5], addr[4], addr[3], addr[2], addr[1], addr[0]);

  return result;
}

int BLELocalDevice::rssi()
{
  BLEDevice central = ATT.central();

  if (central)
  {
    return central.rssi();
  }

  return 127;
}

bool BLELocalDevice::setAdvertisedServiceUuid(const char *advertisedServiceUuid)
{
  return _advertisingData.setAdvertisedServiceUuid(advertisedServiceUuid);
}

bool BLELocalDevice::setAdvertisedService(const BLEService &service)
{
  return setAdvertisedServiceUuid(service.uuid());
}

bool BLELocalDevice::setAdvertisedServiceData(uint16_t uuid, const uint8_t data[], int length)
{
  return _advertisingData.setAdvertisedServiceData(uuid, data, length);
}

bool BLELocalDevice::setManufacturerData(const uint8_t manufacturerData[], int manufacturerDataLength)
{
  return _advertisingData.setManufacturerData(manufacturerData, manufacturerDataLength);
}

bool BLELocalDevice::setManufacturerData(const uint16_t companyId, const uint8_t manufacturerData[], int manufacturerDataLength)
{
  return _advertisingData.setManufacturerData(companyId, manufacturerData, manufacturerDataLength);
}

bool BLELocalDevice::setLocalName(const char *localName)
{
  return _scanResponseData.setLocalName(localName);
}

void BLELocalDevice::setAdvertisingData(BLEAdvertisingData &advertisingData)
{
  _advertisingData = advertisingData;
  if (!_advertisingData.hasFlags())
  {
    _advertisingData.setFlags(BLEFlagsGeneralDiscoverable | BLEFlagsBREDRNotSupported);
  }
}

void BLELocalDevice::setScanResponseData(BLEAdvertisingData &scanResponseData)
{
  _scanResponseData = scanResponseData;
}

BLEAdvertisingData &BLELocalDevice::getAdvertisingData()
{
  return _advertisingData;
}

BLEAdvertisingData &BLELocalDevice::getScanResponseData()
{
  return _scanResponseData;
}

void BLELocalDevice::setDeviceName(const char *deviceName)
{
  GATT.setDeviceName(deviceName);
}

void BLELocalDevice::setAppearance(uint16_t appearance)
{
  GATT.setAppearance(appearance);
}

void BLELocalDevice::addService(BLEService &service)
{
  GATT.addService(service);
}

int BLELocalDevice::advertise()
{
  updateAttributes();
  _advertisingData.updateData();
  _scanResponseData.updateData();
  return GAP.advertise(_advertisingData.data(), _advertisingData.dataLength(),
                       _scanResponseData.data(), _scanResponseData.dataLength());
}

void BLELocalDevice::stopAdvertise()
{
  GAP.stopAdvertise();
}

int BLELocalDevice::scan(bool withDuplicates)
{
  return GAP.scan(withDuplicates);
}

int BLELocalDevice::scanForName(String name, bool withDuplicates)
{
  return GAP.scanForName(name, withDuplicates);
}

int BLELocalDevice::scanForUuid(String uuid, bool withDuplicates)
{
  return GAP.scanForUuid(uuid, withDuplicates);
}

int BLELocalDevice::scanForAddress(String address, bool withDuplicates)
{
  return GAP.scanForAddress(address, withDuplicates);
}

void BLELocalDevice::stopScan()
{
  GAP.stopScan();
}

BLEDevice BLELocalDevice::central()
{
  HCI.poll();

  return ATT.central();
}

BLEDevice BLELocalDevice::available()
{
  HCI.poll();

  return GAP.available();
}

void BLELocalDevice::setEventHandler(BLEDeviceEvent event, BLEDeviceEventHandler eventHandler)
{
  if (event == BLEDiscovered)
  {
    GAP.setEventHandler(event, eventHandler);
  }
  else
  {
    ATT.setEventHandler(event, eventHandler);
  }
}

void BLELocalDevice::setAdvertisingInterval(uint16_t advertisingInterval)
{
  GAP.setAdvertisingInterval(advertisingInterval);
}

void BLELocalDevice::setConnectionInterval(uint16_t minimumConnectionInterval, uint16_t maximumConnectionInterval)
{
  L2CAPSignaling.setConnectionInterval(minimumConnectionInterval, maximumConnectionInterval);
}

void BLELocalDevice::setSupervisionTimeout(uint16_t supervisionTimeout)
{
  L2CAPSignaling.setSupervisionTimeout(supervisionTimeout);
}

void BLELocalDevice::setConnectable(bool connectable)
{
  GAP.setConnectable(connectable);
}

void BLELocalDevice::setTimeout(unsigned long timeout)
{
  ATT.setTimeout(timeout);
}

void BLELocalDevice::debug(Stream &stream)
{
  HCI.debug(stream);
}

void BLELocalDevice::noDebug()
{
  HCI.noDebug();
}

void BLELocalDevice::updateAttributes()
{
  extern void null_access(ble_evt_att_param_t * p_param);
  uint32_t cnt = GATT.attributeCount();
  for (int i = 0; i < cnt;)
  {
    BLELocalAttribute *pAttr = GATT.attribute(i);
    switch (pAttr->type())
    {
    case BLETypeService:
    {
      ble_att_param_t att_param;
      att_param.p_uuid_type = (void *)attr_uuid_type_primary_service;
      att_param.att_len = pAttr->uuidLength();
      att_param.p_uuid_value = (void *)pAttr->uuidData();
      att_param.property_value = GATT_DECLARATIONS_PROPERTIES_READ;
      att_param.db_permission_format = ATT_TYPE_FORMAT_16UUID;
      att_param.att_handler = NULL;
      RT58xBLE.add_attribute(&att_param);
      i++;
    }
    break;
    case BLETypeCharacteristic:
    {
      ble_att_param_t att_param;
      att_param.p_uuid_type = (void *)attr_uuid_type_characteristic;
      att_param.att_len = pAttr->uuidLength();
      att_param.p_uuid_value = (void *)pAttr->uuidData();
      att_param.property_value = GATT_DECLARATIONS_PROPERTIES_READ;
      att_param.db_permission_format = ATT_TYPE_FORMAT_16UUID;
      att_param.att_handler = NULL;
      RT58xBLE.add_attribute(&att_param);
      i++;
      BLELocalCharacteristic *chara = (BLELocalCharacteristic *)GATT.attribute(i);
      att_param.p_uuid_type = att_param.p_uuid_value;
      att_param.p_uuid_value = NULL;
      att_param.att_len = chara->valueLength();
      att_param.property_value = chara->properties();
      att_param.db_permission_format = 0;
      att_param.att_handler = NULL;
      RT58xBLE.add_attribute(&att_param);
      i++;
      int descCount = chara->descriptorCount();
      for (int j = 0; j < descCount; j++)
      {
        BLELocalDescriptor *desc = (BLELocalDescriptor *)chara->descriptor(j);
        BLELocalAttribute *pDescAttr = (BLELocalAttribute *)desc;
        if (pDescAttr->uuidLength() == 2)
        {
          uint16_t uuid = (uint16_t)strtol(pDescAttr->uuid(), NULL, 16);
          switch (uuid)
          {
          case 0x2902:
            att_param.p_uuid_type = (void *)attr_uuid_type_client_charc_configuration;
            att_param.p_uuid_value = chara->cccdValue();
            att_param.att_len = chara->cccdValueLength();
            att_param.property_value = GATT_DECLARATIONS_PROPERTIES_READ | GATT_DECLARATIONS_PROPERTIES_WRITE;
            att_param.db_permission_format = ATT_TYPE_FORMAT_16UUID;
            att_param.att_handler = NULL;
            RT58xBLE.add_attribute(&att_param);
            i++;
            break;
          default:
            break;
          }
        }
      }
    }
    break;
    case BLETypeDescriptor:
    case BLETypeUnknown:
    default:
      i++;
      break;
    }
  }
}

#if !defined(FAKE_BLELOCALDEVICE)
BLELocalDevice BLEObj;
BLELocalDevice &BLE = BLEObj;
#endif
