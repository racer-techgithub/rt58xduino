#pragma once
#ifndef __BLE_APP_H__
#define __BLE_APP_H__

#include <Arduino.h>

#ifdef __cplusplus
extern "C"
{
#endif

#include "middleware/ble_event.h"
#include "middleware/ble_att_gatt.h"
#include "middleware/ble_profile.h"

#ifdef __cplusplus
}
#endif

#define APP_P_HOST_ID 0

#define COUNTOF(x) (sizeof(x) / sizeof(x[0]))

typedef enum
{
    STATE_STANDBY,     /**< Application state: standby.*/
    STATE_ADVERTISING, /**< Application state: advertising.*/
    STATE_CONNECTED,   /**< Application state: connected.*/
} ble_state_t;

class RT58xBLE
{
public:
    RT58xBLE();
    void begin();
    void end();
    void add_attribute(ble_att_param_t *pvAttr);
    void poll();

private:
    static void ble_evt_indication_handler(uint32_t data_len);
    static QueueHandle_t BleEvtQ;
    static ble_att_param_t *p_ble_att_param[ATT_MAX_COUNT];
    static ble_att_handle_param_t p_ble_att_handle_param[ATT_MAX_COUNT];

    void evt_callback(ble_evt_param_t *p_param);
    void evt_handler(ble_evt_param_t *p_param);
    void att_handler(ble_evt_att_param_t *p_param);

    uint32_t attribute_count;
    uint32_t ble_link_state;
};

extern class RT58xBLE RT58xBLE;

#endif // !__BLE_APP_H__
