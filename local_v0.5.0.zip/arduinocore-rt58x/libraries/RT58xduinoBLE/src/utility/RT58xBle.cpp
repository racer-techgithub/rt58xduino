#include <ArduinoBLE.h>

#include "local/BLELocalAttribute.h"
#include "utility/ATT.h"
#include "utility/GATT.h"

#include "middleware/ble_profile.h"
#include "middleware/ble_api.h"
#include "middleware/ble_common.h"
#include "middleware/ble_gap.h"
#include "middleware/ble_att_gatt.h"
#include "middleware/ble_event.h"
#include "middleware/task_hci.h"

#include "stream_buffer.h"
#include "message_buffer.h"

#include "RT58xBle.h"

#ifdef UTIL_LOG_ENABLED
#include "bsp.h"
#include "bsp_console.h"
#include "util_log.h"
#include "util_printf.h"
#endif // !UTIL_LOG_ENABLED

/** Service Combination #00
 * @note included @ref ATT_GAPS_SERVICE @ref ATT_GATTS_SERVICE @ref ATT_DIS_SERVICE @ref ATT_TRSPS_SERVICE
 */
ble_att_param_t *RT58xBLE::p_ble_att_param[ATT_MAX_COUNT];

/** BLE Connection Link Parameter Definition
 * @attention Every active role in active links shall be defined related link parameters.
 */
ble_att_handle_param_t RT58xBLE::p_ble_att_handle_param[ATT_MAX_COUNT]; // Link 0 Server

QueueHandle_t RT58xBLE::BleEvtQ;

void RT58xBLE::ble_evt_indication_handler(uint32_t data_len)
{
    xQueueSend(BleEvtQ, &data_len, portMAX_DELAY);
}

RT58xBLE::RT58xBLE(void)
{
    /* initil Button and press button0 to disable sleep mode & initil Console & UART */
#ifdef UTIL_LOG_ENABLED
    bsp_init(BSP_INIT_DEBUG_CONSOLE, NULL);
    /* retarget stdout for utility & initial utility logging */
    utility_register_stdout(bsp_console_stdout_char, bsp_console_stdout_string);
    util_log_init();
#endif

    info_color(LOG_DEFAULT, "BLE stack initial...\n");

    taskENTER_CRITICAL();

    attribute_count = 0;
    p_ble_att_param[attribute_count++] = (ble_att_param_t *)&ATT_NULL_INVALID;
    att_db_mapping_size->size_map_server_db = attribute_count;
    att_db_link->p_server_db = (const ble_att_param_t *const *)p_ble_att_param;
    att_db_mapping->map_server_db = p_ble_att_handle_param;

    BleEvtQ = xQueueCreate(64, sizeof(uint32_t));

    ble_cfg_t gt_app_cfg = {.pf_evt_indication = ble_evt_indication_handler};
    ble_host_stack_init(&gt_app_cfg);

    task_hci_init();

    taskEXIT_CRITICAL();
}

void RT58xBLE::begin() {}

void RT58xBLE::end() {}

void RT58xBLE::add_attribute(ble_att_param_t *pvAttr)
{
    ble_att_param_t *p_att_param = (ble_att_param_t *)pvPortMalloc(sizeof(ble_att_param_t));
    memcpy(p_att_param, pvAttr, sizeof(ble_att_param_t));
    p_ble_att_param[attribute_count++] = p_att_param;
    att_db_mapping_size->size_map_server_db = attribute_count;
}

void RT58xBLE::poll()
{

    uint32_t evt_size;
    BaseType_t ret;

    for (;;)
    {

        taskENTER_CRITICAL();
        ret = xQueueReceive(BleEvtQ, &evt_size, 0);
        taskEXIT_CRITICAL();

        if (ret == pdFALSE)
        {
            return;
        }

        if (evt_size == 0)
        {
            return;
        }

        ble_tlv_t *p_ble_tlv = (ble_tlv_t *)pvPortMalloc(evt_size);
        int err = ble_event_msg_recvfrom((uint8_t *)p_ble_tlv, &evt_size);
        if (err)
        {
            vPortFree(p_ble_tlv);
            info_color(LOG_RED, "[%s] err = %d !\n", __func__, (ble_err_t)err);
            return;
        }

        switch (p_ble_tlv->type)
        {
        case BLE_APP_GENERAL_EVENT:
            evt_callback((ble_evt_param_t *)p_ble_tlv->value);
            evt_handler((ble_evt_param_t *)p_ble_tlv->value);
            break;
        case BLE_APP_SERVICE_EVENT:
        {
            ble_evt_att_param_t *p_ble_evt_att_param = (ble_evt_att_param_t *)p_ble_tlv->value;
            switch (p_ble_evt_att_param->gatt_role)
            {
            case BLE_GATT_ROLE_CLIENT:
                break;
            case BLE_GATT_ROLE_SERVER:
                att_handler(p_ble_evt_att_param);
                break;
            default:
                break;
            }
        }
        break;
        case BLE_APP_RETURN_PARAMETER_EVENT:
        default:
            break;
        }
        vPortFree(p_ble_tlv);
    }
}

void RT58xBLE::evt_callback(ble_evt_param_t *p_param)
{
    switch (p_param->event)
    {
    case BLE_ADV_EVT_SET_ENABLE:
    {
        ble_evt_adv_set_adv_enable_t *p_adv_enable = (ble_evt_adv_set_adv_enable_t *)&p_param->event_param.ble_evt_adv.param.evt_set_adv_enable;
        if (p_adv_enable->status == BLE_HCI_ERR_CODE_SUCCESS)
        {
            if (p_adv_enable->adv_enabled == true)
            {
                info_color(LOG_GREEN, "Advertising...\n");
                ble_link_state = STATE_ADVERTISING;
            }
            else
            {
                info_color(LOG_GREEN, "Idle.\n");
                ble_link_state = STATE_STANDBY;
            }
        }
        else
        {
            info_color(LOG_RED, "Advertising enable failed.\n");
        }
    }
    break;

    case BLE_GAP_EVT_CONN_COMPLETE:
    {
        ble_evt_gap_conn_complete_t *p_conn_param = (ble_evt_gap_conn_complete_t *)&p_param->event_param.ble_evt_gap.param.evt_conn_complete;

        if (p_conn_param->status != BLE_HCI_ERR_CODE_SUCCESS)
        {
            info_color(LOG_RED, "Connect failed, error code = 0x%02x\n", p_conn_param->status);
        }
        else
        {
            ble_link_state = STATE_CONNECTED;
            info_color(LOG_GREEN,
                       "Connected, ID=%d, Connected to %02x:%02x:%02x:%02x:%02x:%02x\n",
                       p_conn_param->host_id,
                       p_conn_param->peer_addr.addr[5],
                       p_conn_param->peer_addr.addr[4],
                       p_conn_param->peer_addr.addr[3],
                       p_conn_param->peer_addr.addr[2],
                       p_conn_param->peer_addr.addr[1],
                       p_conn_param->peer_addr.addr[0]);
        }
    }
    break;

    case BLE_GAP_EVT_CONN_PARAM_UPDATE:
    {
        ble_evt_gap_conn_param_update_t *p_conn_param = (ble_evt_gap_conn_param_update_t *)&p_param->event_param.ble_evt_gap.param.evt_conn_param_update;

        if (p_conn_param->status != BLE_HCI_ERR_CODE_SUCCESS)
        {
            info_color(LOG_RED, "Connection update failed, error code = 0x%02x\n", p_conn_param->status);
        }
        else
        {
            info_color(LOG_DEFAULT, "Connection updated\n");
            info_color(LOG_DEFAULT, "ID: %d, ", p_conn_param->host_id);
            info_color(LOG_DEFAULT, "Interval: %d, ", p_conn_param->conn_interval);
            info_color(LOG_DEFAULT, "Latency: %d, ", p_conn_param->periph_latency);
            info_color(LOG_DEFAULT, "Supervision Timeout: %d\n", p_conn_param->supv_timeout);
        }
    }
    break;

    case BLE_GAP_EVT_PHY_READ:
    case BLE_GAP_EVT_PHY_UPDATE:
    {
        ble_evt_gap_phy_t *p_phy_param = (ble_evt_gap_phy_t *)&p_param->event_param.ble_evt_gap.param.evt_phy;
        if (p_phy_param->status != BLE_HCI_ERR_CODE_SUCCESS)
        {
            info_color(LOG_RED, "PHY update/read failed, error code = 0x%02x\n", p_phy_param->status);
        }
        else
        {
            info_color(LOG_DEFAULT, "PHY updated/read, ID: %d, TX PHY: %d, RX PHY: %d\n", p_phy_param->host_id, p_phy_param->tx_phy, p_phy_param->rx_phy);
        }
    }
    break;

    case BLE_ATT_GATT_EVT_MTU_EXCHANGE:
    {
        ble_evt_mtu_t *p_mtu_param = (ble_evt_mtu_t *)&p_param->event_param.ble_evt_att_gatt.param.ble_evt_mtu;
        info_color(LOG_DEFAULT, "MTU Exchanged, ID:%d, size: %d\n", p_mtu_param->host_id, p_mtu_param->mtu);
    }
    break;

    case BLE_ATT_GATT_EVT_WRITE_SUGGESTED_DEFAULT_DATA_LENGTH:
    {
        ble_evt_suggest_data_length_set_t *p_data_len_param = (ble_evt_suggest_data_length_set_t *)&p_param->event_param.ble_evt_att_gatt.param.ble_evt_suggest_data_length_set;

        if (p_data_len_param->status == BLE_HCI_ERR_CODE_SUCCESS)
        {
            info_color(LOG_DEFAULT, "Write default data length, status: %d\n", p_data_len_param->status);
        }
        else
        {
            info_color(LOG_RED, "Write default data length, status: %d\n", p_data_len_param->status);
        }
    }
    break;

    case BLE_ATT_GATT_EVT_DATA_LENGTH_CHANGE:
    {
        ble_evt_data_length_change_t *p_data_len_param = (ble_evt_data_length_change_t *)&p_param->event_param.ble_evt_att_gatt.param.ble_evt_data_length_change;
        info_color(LOG_DEFAULT, "Data length changed, ID: %d\n", p_data_len_param->host_id);
        info_color(LOG_DEFAULT, "MaxTxOctets: %d  MaxTxTime:%d\n", p_data_len_param->max_tx_octets, p_data_len_param->max_tx_time);
        info_color(LOG_DEFAULT, "MaxRxOctets: %d  MaxRxTime:%d\n", p_data_len_param->max_rx_octets, p_data_len_param->max_rx_time);
    }
    break;

    case BLE_GAP_EVT_DISCONN_COMPLETE:
    {
        ble_evt_gap_disconn_complete_t *p_disconn_param = (ble_evt_gap_disconn_complete_t *)&p_param->event_param.ble_evt_gap.param.evt_disconn_complete;
        if (p_disconn_param->status != BLE_HCI_ERR_CODE_SUCCESS)
        {
            info_color(LOG_RED, "Disconnect failed, error code = 0x%02x\n", p_disconn_param->status);
        }
        else
        {
            ble_link_state = STATE_STANDBY;
            ble_cmd_adv_enable(APP_P_HOST_ID); // re-start adv
            info_color(LOG_GREEN, "Disconnect, ID:%d, Reason:0x%02x\n", p_disconn_param->host_id, p_disconn_param->reason);
        }
    }
    break;
    default:
        break;
    }
}

void RT58xBLE::evt_handler(ble_evt_param_t *p_param)
{
    typedef struct
    {
        ble_module_evt_t event;
        char *evt_name;
    } ble_evt_name_t;
    static const ble_evt_name_t ble_evt_name[] = {
        /**< Common module event.*/
        {BLE_COMMON_EVT_SET_CONTROLLER_INFO, (char *)"ble_COMMON_EVT_SET_CONTROLLER_INFO"},
        {BLE_COMMON_EVT_SET_EVENT_MASK, (char *)"ble_COMMON_EVT_SET_EVENT_MASK"},
        {BLE_COMMON_EVT_READ_BUFFER_SIZE, (char *)"ble_COMMON_EVT_READ_BUFFER_SIZE"},
        {BLE_COMMON_EVT_READ_LOCAL_VER, (char *)"ble_COMMON_EVT_READ_LOCAL_VER"},

        /**< GAP module event.*/
        {BLE_GAP_EVT_SET_RANDOM_ADDR, (char *)"ble_GAP_EVT_SET_RANDOM_ADDR"},
        {BLE_GAP_EVT_SET_VENDOR_CMD, (char *)"ble_GAP_EVT_SET_VENDOR_CMD"},
        {BLE_GAP_EVT_CONN_COMPLETE, (char *)"ble_GAP_EVT_CONN_COMPLETE"},
        {BLE_GAP_EVT_CONN_CANCEL, (char *)"ble_GAP_EVT_CONN_CANCEL"},
        {BLE_GAP_EVT_CONN_PARAM_UPDATE, (char *)"ble_GAP_EVT_CONN_PARAM_UPDATE"},
        {BLE_GAP_EVT_DISCONN_COMPLETE, (char *)"ble_GAP_EVT_DISCONN_COMPLETE"},
        {BLE_GAP_EVT_PHY_READ, (char *)"ble_GAP_EVT_PHY_READ"},
        {BLE_GAP_EVT_PHY_UPDATE, (char *)"ble_GAP_EVT_PHY_UPDATE"},
        {BLE_GAP_EVT_RSSI_READ, (char *)"ble_GAP_EVT_RSSI_READ"},
        {BLE_GAP_EVT_SET_LE_HOST_CH_CLASSIFICATION, (char *)"ble_GAP_EVT_SET_LE_HOST_CH_CLASSIFICATION"},
        {BLE_GAP_EVT_READ_CHANNEL_MAP, (char *)"ble_GAP_EVT_READ_CHANNEL_MAP"},

        /**< Advertising module event.*/
        {BLE_ADV_EVT_SET_PARAM, (char *)"ble_ADV_EVT_SET_PARAM"},
        {BLE_ADV_EVT_SET_DATA, (char *)"ble_ADV_EVT_SET_DATA"},
        {BLE_ADV_EVT_SET_SCAN_RSP, (char *)"ble_ADV_EVT_SET_SCAN_RSP"},
        {BLE_ADV_EVT_SET_ENABLE, (char *)"ble_ADV_EVT_SET_ENABLE"},

        /**< Scan module event.*/
        {BLE_SCAN_EVT_SET_PARAM, (char *)"ble_SCAN_EVT_SET_PARAM"},
        {BLE_SCAN_EVT_SET_ENABLE, (char *)"ble_SCAN_EVT_SET_ENABLE"},
        {BLE_SCAN_EVT_ADV_REPORT, (char *)"ble_SCAN_EVT_ADV_REPORT"},

        /**< ATT/ GATT module event.*/
        {BLE_ATT_GATT_EVT_DB_PARSE_COMPLETE, (char *)"ble_ATT_GATT_EVT_DB_PARSE_COMPLETE"},
        {BLE_ATT_GATT_EVT_GET_ATT_HANDLES_TABLE_COMPLETE, (char *)"ble_ATT_GATT_EVT_GET_ATT_HANDLES_TABLE_COMPLETE"},
        {BLE_ATT_GATT_EVT_MTU_EXCHANGE, (char *)"ble_ATT_GATT_EVT_MTU_EXCHANGE"},
        {BLE_ATT_GATT_EVT_DATA_LENGTH_CHANGE, (char *)"ble_ATT_GATT_EVT_DATA_LENGTH_CHANGE"},
        {BLE_ATT_GATT_EVT_WRITE_SUGGESTED_DEFAULT_DATA_LENGTH, (char *)"ble_ATT_GATT_EVT_WRITE_SUGGESTED_DEFAULT_DATA_LENGTH"},
        {BLE_ATT_GATT_EVT_DATA_LENGTH_SET, (char *)"ble_ATT_GATT_EVT_DATA_LENGTH_SET"},

        /**< Security module event.*/
        {BLE_SM_EVT_STK_GENERATION_METHOD, (char *)"ble_SM_EVT_STK_GENERATION_METHOD"},
        {BLE_SM_EVT_PASSKEY_CONFIRM, (char *)"ble_SM_EVT_PASSKEY_CONFIRM"},
        {BLE_SM_EVT_AUTH_STATUS, (char *)"ble_SM_EVT_AUTH_STATUS"},

        /**< vendor event.*/
        {BLE_VENDOR_EVT_SCAN_REQ_REPORT, (char *)"ble_VENDOR_EVT_SCAN_REQ_REPORT"},

    };
    for (int i = 0; i < COUNTOF(ble_evt_name); i++)
    {
        if (p_param->event == ble_evt_name[i].event)
        {
            info_color(LOG_RESET, "p_param->event: 0x%02X (%s)\n", p_param->event, ble_evt_name[i].evt_name);
        }
    }
    switch (p_param->event)
    {
    case BLE_GAP_EVT_CONN_COMPLETE:
    {
        ble_evt_gap_conn_complete_t *p = (ble_evt_gap_conn_complete_t *)&p_param->event_param.ble_evt_gap.param.evt_conn_complete;
        ATT.addConnection(p->host_id, p->role, p->peer_addr.addr_type, p->peer_addr.addr,
                          p->conn_interval,
                          p->periph_latency,
                          p->supv_timeout,
                          0);
    }

    break;
    case BLE_GAP_EVT_DISCONN_COMPLETE:
    {
        ble_evt_gap_disconn_complete_t *p = (ble_evt_gap_disconn_complete_t *)&p_param->event_param.ble_evt_gap.param.evt_conn_complete;
        ATT.removeConnection(p->host_id, p->reason);
    }
    default:
        break;
    }
}

void RT58xBLE::att_handler(ble_evt_att_param_t *p_param)
{
    typedef struct
    {
        ble_att_opcode_t opcode;
        char *opcode_name;
    } ble_evt_att_name_t;
    static const ble_evt_att_name_t ble_evt_att_name[] = {
        {OPCODE_ATT_ERROR_RESPONSE, (char *)"OPCODE_ATT_ERROR_RESPONSE"},
        {OPCODE_ATT_EXCHANGE_MTU_REQUEST, (char *)"OPCODE_ATT_EXCHANGE_MTU_REQUEST"},
        {OPCODE_ATT_EXCHANGE_MTU_RESPONSE, (char *)"OPCODE_ATT_EXCHANGE_MTU_RESPONSE"},
        {OPCODE_ATT_FIND_INFORMATION_REQUEST, (char *)"OPCODE_ATT_FIND_INFORMATION_REQUEST"},
        {OPCODE_ATT_FIND_INFORMATION_RESPONSE, (char *)"OPCODE_ATT_FIND_INFORMATION_RESPONSE"},
        {OPCODE_ATT_FIND_BY_TYPE_VALUE_REQUEST, (char *)"OPCODE_ATT_FIND_BY_TYPE_VALUE_REQUEST"},
        {OPCODE_ATT_FIND_BY_TYPE_VALUE_RESPONSE, (char *)"OPCODE_ATT_FIND_BY_TYPE_VALUE_RESPONSE"},
        {OPCODE_ATT_READ_BY_TYPE_REQUEST, (char *)"OPCODE_ATT_READ_BY_TYPE_REQUEST"},
        {OPCODE_ATT_READ_BY_TYPE_RESPONSE, (char *)"OPCODE_ATT_READ_BY_TYPE_RESPONSE"},
        {OPCODE_ATT_READ_REQUEST, (char *)"OPCODE_ATT_READ_REQUEST"},
        {OPCODE_ATT_READ_RESPONSE, (char *)"OPCODE_ATT_READ_RESPONSE"},
        {OPCODE_ATT_READ_BLOB_REQUEST, (char *)"OPCODE_ATT_READ_BLOB_REQUEST"},
        {OPCODE_ATT_READ_BLOB_RESPONSE, (char *)"OPCODE_ATT_READ_BLOB_RESPONSE"},
        {OPCODE_ATT_READ_MULTIPLE_REQUEST, (char *)"OPCODE_ATT_READ_MULTIPLE_REQUEST"},
        {OPCODE_ATT_READ_MULTIPLE_RESPONSE, (char *)"OPCODE_ATT_READ_MULTIPLE_RESPONSE"},
        {OPCODE_ATT_READ_BY_GROUP_TYPE_REQUEST, (char *)"OPCODE_ATT_READ_BY_GROUP_TYPE_REQUEST"},
        {OPCODE_ATT_READ_BY_GROUP_TYPE_RESPONSE, (char *)"OPCODE_ATT_READ_BY_GROUP_TYPE_RESPONSE"},
        {OPCODE_ATT_WRITE_REQUEST, (char *)"OPCODE_ATT_WRITE_REQUEST"},
        {OPCODE_ATT_WRITE_RESPONSE, (char *)"OPCODE_ATT_WRITE_RESPONSE"},
        {OPCODE_ATT_WRITE_COMMAND, (char *)"OPCODE_ATT_WRITE_COMMAND"},
        {OPCODE_ATT_PREPARE_WRITE_REQUEST, (char *)"OPCODE_ATT_PREPARE_WRITE_REQUEST"},
        {OPCODE_ATT_PREPARE_WRITE_RESPONSE, (char *)"OPCODE_ATT_PREPARE_WRITE_RESPONSE"},
        {OPCODE_ATT_EXECUTE_WRITE_REQUEST, (char *)"OPCODE_ATT_EXECUTE_WRITE_REQUEST"},
        {OPCODE_ATT_EXECUTE_WRITE_RESPONSE, (char *)"OPCODE_ATT_EXECUTE_WRITE_RESPONSE"},
        {OPCODE_ATT_HANDLE_VALUE_NOTIFICATION, (char *)"OPCODE_ATT_HANDLE_VALUE_NOTIFICATION"},
        {OPCODE_ATT_HANDLE_VALUE_INDICATION, (char *)"OPCODE_ATT_HANDLE_VALUE_INDICATION"},
        {OPCODE_ATT_HANDLE_VALUE_CONFIRMATION, (char *)"OPCODE_ATT_HANDLE_VALUE_CONFIRMATION"},
        {OPCODE_ATT_SIGNED_WRITE_COMMAND, (char *)"OPCODE_ATT_SIGNED_WRITE_COMMAND"},
        {OPCODE_ATT_RESTORE_BOND_DATA_COMMAND, (char *)"OPCODE_ATT_RESTORE_BOND_DATA_COMMAND"},
    };
    info_color(LOG_RESET, "\n=============================\n");
    info_color(LOG_RESET, "host_id: 0x%02X\n", p_param->host_id);
    info_color(LOG_RESET, "gatt_role: 0x%02X\n", p_param->gatt_role);
    info_color(LOG_RESET, "cb_index: 0x%02X\n", p_param->cb_index);
    info_color(LOG_RESET, "handle_num: 0x%02X\n", p_param->handle_num);
    info_color(LOG_RESET, "opcode: 0x%02X ", p_param->opcode);
    for (uint32_t i = 0; i < COUNTOF(ble_evt_att_name); i++)
    {
        if (p_param->opcode == ble_evt_att_name[i].opcode)
        {
            info_color(LOG_RESET, "(%s)\n", ble_evt_att_name[i].opcode_name);
            break;
        }
    }
    info_color(LOG_RESET, "event: 0x%02X\n", p_param->event);
    info_color(LOG_RESET, "length: 0x%02X\n", p_param->length);
    info_color(LOG_RESET, "data:");
    for (int i = 0; i < p_param->length; i++)
    {
        info_color(LOG_RESET, " 0x%02X", p_param->data[i]);
    }
    info_color(LOG_RESET, "\n");

    switch (p_param->opcode)
    {
    case OPCODE_ATT_WRITE_REQUEST:
    {
        BLELocalAttribute *attribute = GATT.attribute(p_param->handle_num - 1);
        switch (attribute->type())
        {
        case BLETypeCharacteristic:
        {
            BLELocalCharacteristic *charac = (BLELocalCharacteristic *)attribute;
            charac->writeValue(p_param->data, p_param->length);
        }
        break;
        case BLETypeDescriptor:
        {
            BLELocalDescriptor *desc = (BLELocalDescriptor *)attribute;
            BLELocalCharacteristic *characteristic = (BLELocalCharacteristic *)GATT.attribute(p_param->handle_num - 2);
            if (characteristic->descriptorCount())
            {
                if (characteristic->descriptor(0) == desc)
                {
                    characteristic->writeCccdValue(*(uint16_t *)p_param->data);
                }
            }
        }
        break;
        case BLETypeService:
        case BLETypeUnknown:
        default:
            break;
        }
    }
    break;
    case OPCODE_ATT_READ_REQUEST:
    {
        BLELocalAttribute *attribute = GATT.attribute(p_param->handle_num - 1);
        static ble_gatt_data_param_t ble_gatt_data_param;
        switch (attribute->type())
        {
        case BLETypeDescriptor:
        {
            BLELocalDescriptor *desc = (BLELocalDescriptor *)attribute;
            BLELocalCharacteristic *characteristic = (BLELocalCharacteristic *)GATT.attribute(p_param->handle_num - 2);
            if (characteristic->descriptorCount())
            {
                if (characteristic->descriptor(0) == desc)
                {
                    ble_gatt_data_param_t *p_ble_gatt_data_param = &ble_gatt_data_param;
                    p_ble_gatt_data_param->host_id = p_param->host_id;
                    p_ble_gatt_data_param->handle_num = p_param->handle_num;
                    p_ble_gatt_data_param->length = characteristic->cccdValueLength();
                    p_ble_gatt_data_param->p_data = (uint8_t *)characteristic->cccdValue();
                    ble_cmd_gatt_read_rsp(p_ble_gatt_data_param);
                }
            }
        }
        break;
        case BLETypeCharacteristic:
        {
            BLELocalCharacteristic *characteristic = (BLELocalCharacteristic *)attribute;
            ble_gatt_data_param_t *p_ble_gatt_data_param = &ble_gatt_data_param;
            p_ble_gatt_data_param->host_id = p_param->host_id;
            p_ble_gatt_data_param->handle_num = p_param->handle_num;
            p_ble_gatt_data_param->length = characteristic->valueLength();
            p_ble_gatt_data_param->p_data = (uint8_t *)characteristic->value();
            ble_cmd_gatt_read_rsp(p_ble_gatt_data_param);
        }
        break;
        case BLETypeService:
        case BLETypeUnknown:
        default:
            break;
        }
    }
    break;
    default:
        __BKPT(255);
        break;
    }
}

class RT58xBLE RT58xBLE;