/** @file
 *
 * @brief BOD driver file.
 *
 */

#ifndef __BOD_H__
#define __BOD_H__

/**************************************************************************************************
 *    INCLUDES
 *************************************************************************************************/


/**************************************************************************************************
 *    MACROS
 *************************************************************************************************/


/**************************************************************************************************
 *    CONSTANTS AND DEFINES
 *************************************************************************************************/


/**************************************************************************************************
 *    TYPEDEFS
 *************************************************************************************************/

typedef enum
{
    BOD_CONFIG_INT_POL_RISING      = 0,   /**< Rising edge. */
    BOD_CONFIG_INT_POL_FALLING     = 1,   /**< Falling edge. */
    BOD_CONFIG_INT_POL_BOTH        = 2,   /**< Both edge. */
} bod_config_int_pol_t;

typedef enum
{
    BOD_CONFIG_RISING_3P0V         = 0,   /**< Rising threshold voltage = 3.0V. */
    BOD_CONFIG_RISING_2P7V         = 1,   /**< Rising threshold voltage = 2.7V. */
    BOD_CONFIG_RISING_2P3V         = 2,   /**< Rising threshold voltage = 2.3V. */
    BOD_CONFIG_RISING_1P7V         = 3,   /**< Rising threshold voltage = 1.7V. */
} bod_config_rising_v_t;

typedef enum
{
    BOD_CONFIG_FALLING_1P7V        = 0,   /**< Rising threshold voltage = 1.7V. */
    BOD_CONFIG_FALLING_2P2V        = 1,   /**< Rising threshold voltage = 2.2V. */
    BOD_CONFIG_FALLING_2P6V        = 2,   /**< Rising threshold voltage = 2.6V. */
    BOD_CONFIG_FALLING_2P9V        = 3,   /**< Rising threshold voltage = 2.9V. */
} bod_config_falling_v_t;


/**
 * @brief BOD configuration.
 */
typedef struct 
{
    bod_config_int_pol_t     bod_int_pol;       /**< BOD interrupt polarity*/
    bod_config_rising_v_t    bod_rising_v;      /**< BOD rising threshold voltage*/
    bod_config_falling_v_t   bod_falling_v;     /**< BOD falling threshold voltage*/
} bod_config_t;

/**
 * @brief User cb handler prototype.
 *
 * This function is called when the requested number of samples has been processed.
 *
 * @param p_cb CB.
 */
typedef void (*bod_isr_handler_t)(void);


/**************************************************************************************************
 *    Global Prototypes
 *************************************************************************************************/
//#define BOD_INT_ENABLE()                 (PMU->PMU_COMP0.bit.BOD_INT_EN = ENABLE)       /**< Enable the BOD interrupt*/
#define BOD_INT_ENABLE()                 (PMU->PMU_PWR_CTRL.bit.BOD_INT_EN = ENABLE)    /**< Enable the BOD interrupt*/
//#define BOD_INT_DISABLE()                (PMU->PMU_COMP0.bit.BOD_INT_EN = DISABLE)      /**< Disable the BOD interrupt*/
#define BOD_INT_DISABLE()                (PMU->PMU_PWR_CTRL.bit.BOD_INT_EN = DISABLE)   /**< Disable the BOD interrupt*/
#define BOD_INT_CLEAR()                  (PMU->PMU_COMP1.bit.BOD_INT_CLR = ENABLE)      /**< Clear the BOD interrupt status*/
#define BOD_INT_STATUS_GET()             (PMU->PMU_COMP2.bit.BOD_INT_STA)               /**< Return the BOD interrupt status*/
#define BOD_OUT_GET()                    (PMU->PMU_COMP2.bit.BOD_OUT)                   /**< Return the BOD output result*/
//#define BOD_INT_POL(para_set)            (PMU->PMU_COMP0.bit.BOD_INT_POL = para_set)    /**< Set the BOD interrupt polarity*/
#define BOD_INT_POL(para_set)            (PMU->PMU_PWR_CTRL.bit.BOD_INT_POL = para_set)    /**< Set the BOD interrupt polarity*/
#define BOD_RISING_V(para_set)           (PMU->PMU_BOD_SEL.bit.BOD_R = para_set)        /**< Set the BOD rising voltage threshold*/
#define BOD_FALLING_V(para_set)          (PMU->PMU_BOD_SEL.bit.BOD_F = para_set)        /**< Set the BOD falling voltage threshold*/
#define BOD_NM_ENABLE()                  (PMU->PMU_EN_CTRL.bit.EN_BOD_NM = ENABLE)      /**< Enable the BOD in Normal Mode*/

void bod_register_int_callback(bod_isr_handler_t bod_int_callback);
void bod_int_enable(void);
void bod_int_disable(void);

uint32_t bod_init(bod_config_t *p_config, bod_isr_handler_t bod_int_callback);


#endif /* end of _BOD_H_ */

