
#ifndef _INCLUDE_SHA256_DEFINE_
#define _INCLUDE_SHA256_DEFINE_

  
#define  SHA256_DIGEST_SIZE                32
#define  SHA256_BLOCK_SIZE                 64

#define  ROM_START_FUN_ADDR        0x10000024
#define  ROM_UPDATE_FUN_ADDR       0x10000020
#define  ROM_FINISH_FUN_ADDR       0x1000001C


typedef struct {
    uint32_t total[2];
    uint32_t state[8];
    uint8_t buffer[64];
} sha256_context;


typedef void (*sha256_starts_rom_t)(sha256_context * ctx);
typedef void (*sha256_update_rom_t)(sha256_context * ctx, uint8_t * input, uint32_t length);
typedef void (*sha256_finish_rom_t)(sha256_context * ctx, uint8_t digest[SHA256_DIGEST_SIZE]);

#ifdef __cplusplus
extern "C"
{
#endif

extern void sha256_starts(sha256_context * ctx);

extern void sha256_update(sha256_context * ctx, uint8_t * input, uint32_t length);

extern void sha256_finish(sha256_context * ctx, uint8_t digest[SHA256_DIGEST_SIZE]);


extern uint32_t hmac_sha256(const uint8_t *key,
                uint32_t       key_length,
                const uint8_t *msg,
                uint32_t       msg_length,
                uint8_t       *output);
                    
#ifdef __cplusplus
}
#endif                    


#endif
