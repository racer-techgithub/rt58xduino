/**************************************************************************//**
 * @file     rf_mcu_spi.h
 * @version
 * @brief    header file for rf mcu with spi driver
 *
 ******************************************************************************/

#ifndef __RF_MCU_SPI_H__
#define __RF_MCU_SPI_H__

#include "cm3_mcu.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @brief Initialization of communication subsystem
 *
 * @param none
 *
 * @return void
 *
 */

#ifdef __cplusplus
}
#endif

#endif /* __RF_MCU_SPI_H__ */





