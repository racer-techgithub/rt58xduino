/******************************************************************************
*
* @File		phy_register.h
* @Version
* $Revision: 
* $Date: 
* @Brief
* @Note
*
******************************************************************************/
#ifndef _PHY_REGISTER_H
#define _PHY_REGISTER_H

/******************************************************************************
* INCLUDES
******************************************************************************/
#include "cm3_mcu.h"
#include "radio.h"

/******************************************************************************
* TYPEDEFS
******************************************************************************/
/* FIR Address */
#define ADDR_RX_FIR_COEF_S0_A                  (0x0238)
#define ADDR_RX_FIR_COEF_S0_B                  (0x023c)
#define ADDR_RX_FIR_COEF_S1_A                  (0x0240)
#define ADDR_RX_FIR_COEF_S1_B                  (0x0244)
#if (FIRMWARE_VERSION == FPGA)
#define ADDR_RX_FIR_COEF_S1_C                  (0x0248)
#define ADDR_RX_FIR_COEF_S1_D                  (0x024C)
#define ADDR_RX_FIR_COEF_S2_A                  (0x02d0)
#define ADDR_RX_FIR_COEF_S2_B                  (0x02d4)
#define ADDR_RX_FIR_COEF_S2_C                  (0x02d8)
#define ADDR_RX_FIR_COEF_S2_D                  (0x02dc)
#else
#define ADDR_RX_FIR_COEF_S2_A                  (0x0248)
#define ADDR_RX_FIR_COEF_S2_B                  (0x024c)
#define ADDR_RX_FIR_COEF_S2_C                  (0x0250)
#define ADDR_RX_FIR_COEF_S2_D                  (0x0254)
#endif

#define ADDR_TX_FIR_COEF_S0_A                  (0x0290)
#define ADDR_TX_FIR_COEF_S0_B                  (0x0294)
#define ADDR_TX_FIR_COEF_S0_C                  (0x0298)
#define ADDR_TX_FIR_COEF_S0_D                  (0x029C)
#define ADDR_TX_FIR_COEF_S1_A                  (0x02A0)
#define ADDR_TX_FIR_COEF_S1_B                  (0x02A4)
#define ADDR_TX_FIR_COEF_S1_C                  (0x02A8)
#define ADDR_TX_FIR_COEF_S1_D                  (0x02AC)
#define ADDR_TX_FIR_COEF_S2_A                  (0x0208)
#define ADDR_TX_FIR_COEF_S2_B                  (0x020C)
#define ADDR_TX_FIR_COEF_S2_C                  (0x0210)
#define ADDR_TX_FIR_COEF_S2_D                  (0x0214)


/* RX FIR Coefficient values */
#define VAL_RX_FIR_COEF_S0_A_500K            (0x06F9F4F5)
#define VAL_RX_FIR_COEF_S0_B_500K            (0x3F3A2C19)
#if (FIRMWARE_VERSION == FPGA)
#define VAL_RX_FIR_COEF_S1_A_500K            (0x00000000)
#define VAL_RX_FIR_COEF_S1_B_500K            (0x00000000)
#define VAL_RX_FIR_COEF_S1_C_500K            (0x1407FDF7)
#define VAL_RX_FIR_COEF_S1_D_500K            (0x39362D21)
#else
#define VAL_RX_FIR_COEF_S1_A_500K            (0x1407FDF7)
#define VAL_RX_FIR_COEF_S1_B_500K            (0x39362D21)
#endif
#define VAL_RX_FIR_COEF_S2_A_500K            (0xFF000000)
#define VAL_RX_FIR_COEF_S2_B_500K            (0xFCFBFCFE)
#define VAL_RX_FIR_COEF_S2_C_500K            (0x170D04FE)
#define VAL_RX_FIR_COEF_S2_D_500K            (0x37342D23)

#define VAL_RX_FIR_COEF_S0_A_250K            (0x1407FDF7)
#define VAL_RX_FIR_COEF_S0_B_250K            (0x39362D21)
#if (FIRMWARE_VERSION == FPGA)
#define VAL_RX_FIR_COEF_S1_A_250K            (0x00000000)
#define VAL_RX_FIR_COEF_S1_B_250K            (0x00000000)
#define VAL_RX_FIR_COEF_S1_C_250K            (0x1E160E07)
#define VAL_RX_FIR_COEF_S1_D_250K            (0x302F2B25)
#else
#define VAL_RX_FIR_COEF_S1_A_250K            (0x1E160E07)
#define VAL_RX_FIR_COEF_S1_B_250K            (0x302F2B25)
#endif
#define VAL_RX_FIR_COEF_S2_A_250K            (0xFF000000)
#define VAL_RX_FIR_COEF_S2_B_250K            (0xFCFBFCFE)
#define VAL_RX_FIR_COEF_S2_C_250K            (0x170D04FE)
#define VAL_RX_FIR_COEF_S2_D_250K            (0x37342D23)

#define VAL_RX_FIR_COEF_S0_A_125K            (0x1E160E07)
#define VAL_RX_FIR_COEF_S0_B_125K            (0x302F2B25)
#if (FIRMWARE_VERSION == FPGA)
#define VAL_RX_FIR_COEF_S1_A_125K            (0x00000000)
#define VAL_RX_FIR_COEF_S1_B_125K            (0x00000000)
#define VAL_RX_FIR_COEF_S1_C_125K            (0x01F6F5FA)
#define VAL_RX_FIR_COEF_S1_D_125K            (0x433C2A13)
#else
#define VAL_RX_FIR_COEF_S1_A_125K            (0x01F6F5FA)
#define VAL_RX_FIR_COEF_S1_B_125K            (0x433C2A13)
#endif

#define VAL_RX_FIR_COEF_S2_A_125K            (0xFFFF0000)
#define VAL_RX_FIR_COEF_S2_B_125K            (0xFDFCFCFD)
#define VAL_RX_FIR_COEF_S2_C_125K            (0x190F0701)
#define VAL_RX_FIR_COEF_S2_D_125K            (0x35332D24)

#define VAL_RX_FIR_COEF_S0_A_62P5K            (0x211D1914)
#define VAL_RX_FIR_COEF_S0_B_62P5K            (0x29282724)
#if (FIRMWARE_VERSION == FPGA)
#define VAL_RX_FIR_COEF_S1_A_62P5K            (0x00000000)
#define VAL_RX_FIR_COEF_S1_B_62P5K            (0x00000000)
#define VAL_RX_FIR_COEF_S1_C_62P5K            (0x1E160E07)
#define VAL_RX_FIR_COEF_S1_D_62P5K            (0x302F2B25)
#else
#define VAL_RX_FIR_COEF_S1_A_62P5K            (0x1E160E07)
#define VAL_RX_FIR_COEF_S1_B_62P5K            (0x302F2B25)
#endif
#define VAL_RX_FIR_COEF_S2_A_62P5K            (0xFC000204)
#define VAL_RX_FIR_COEF_S2_B_62P5K            (0xF7F5F6F9)
#define VAL_RX_FIR_COEF_S2_C_62P5K            (0x180D03FC)
#define VAL_RX_FIR_COEF_S2_D_62P5K            (0x34322C23)

/* TX FIR Coefficient values */
#define RF_TX_FIR0A_62p5K_VAL           (0x0100FF00)
#define RF_TX_FIR0B_62p5K_VAL           (0x0300FE00)
#define RF_TX_FIR0C_62p5K_VAL           (0x0505FCFE)
#define RF_TX_FIR0D_62p5K_VAL           (0x4628FAF4)
#define RF_TX_FIR1A_62p5K_VAL           (0x211A140E)
#define RF_TX_FIR1B_62p5K_VAL           (0x433A3229)
#define RF_TX_FIR1C_62p5K_VAL           (0x605A534B)
#define RF_TX_FIR1D_62p5K_VAL           (0x6D6C6966)
#define RF_TX_FIR2A_62p5K_VAL           (0xFFFFFF00)
#define RF_TX_FIR2B_62p5K_VAL           (0x00FFFFFF)
#define RF_TX_FIR2C_62p5K_VAL           (0x09060402)
#define RF_TX_FIR2D_62p5K_VAL           (0x100F0E0C)

#define RF_TX_FIR0A_125K_VAL            (0x0100FF00)
#define RF_TX_FIR0B_125K_VAL            (0x0300FE00)
#define RF_TX_FIR0C_125K_VAL            (0x0505FCFE)
#define RF_TX_FIR0D_125K_VAL            (0x4628FAF4)
#define RF_TX_FIR1A_125K_VAL            (0xFAF9FAFC)
#define RF_TX_FIR1B_125K_VAL            (0x100700FC)
#define RF_TX_FIR1C_125K_VAL            (0x4638291C)
#define RF_TX_FIR1D_125K_VAL            (0x64625C52)
#define RF_TX_FIR2A_125K_VAL            (0xFFFFFF00)
#define RF_TX_FIR2B_125K_VAL            (0x00FFFFFF)
#define RF_TX_FIR2C_125K_VAL            (0x09060402)
#define RF_TX_FIR2D_125K_VAL            (0x100F0E0C)

#define RF_TX_FIR0A_250K_VAL            (0x0100FF00)
#define RF_TX_FIR0B_250K_VAL            (0x0300FE00)
#define RF_TX_FIR0C_250K_VAL            (0x0505FCFE)
#define RF_TX_FIR0D_250K_VAL            (0x4628FAF4)
#define RF_TX_FIR1A_250K_VAL            (0xFDFF0102)
#define RF_TX_FIR1B_250K_VAL            (0xF8F6F7FA)
#define RF_TX_FIR1C_250K_VAL            (0x241407FD)
#define RF_TX_FIR1D_250K_VAL            (0x4E4B4134)
#define RF_TX_FIR2A_250K_VAL            (0xFFFFFF00)
#define RF_TX_FIR2B_250K_VAL            (0x00FFFFFF)
#define RF_TX_FIR2C_250K_VAL            (0x09060402)
#define RF_TX_FIR2D_250K_VAL            (0x100F0E0C)

#define RF_TX_FIR0A_500K_VAL            (0x0100FF00)
#define RF_TX_FIR0B_500K_VAL            (0x0300FE00)
#define RF_TX_FIR0C_500K_VAL            (0x0505FCFE)
#define RF_TX_FIR0D_500K_VAL            (0x4628FAF4)
#define RF_TX_FIR1A_500K_VAL            (0xFCFF0202)
#define RF_TX_FIR1B_500K_VAL            (0x080600FC)
#define RF_TX_FIR1C_500K_VAL            (0xF5F1F903)
#define RF_TX_FIR1D_500K_VAL            (0x4C412608)
#define RF_TX_FIR2A_500K_VAL            (0xFFFFFF00)
#define RF_TX_FIR2B_500K_VAL            (0x00FFFFFF)
#define RF_TX_FIR2C_500K_VAL            (0x09060402)
#define RF_TX_FIR2D_500K_VAL            (0x100F0E0C)

/* Modem register address, bitShift and bitmask*/
#define ADDR_SLINK_PACKET_FORMAT                (0x0100)
#define R_CRC_TYPE_RW                           0x04, 0x00000030
#define R_PHR_EXIST                             0x07, 0x00000080
#define R_TX_PHR_VALUE                          0x10, 0xffff0000

#define ADDR_RX_RSSI                            (0x01E4)
#define R_WB_RSSI                               0x00, 0x000000ff
#define R_IB_RSSI                               0x08, 0x0000ff00
#define R_LNA_GAIN_IDX                          0x10, 0x000f0000
#define R_TIA_GAIN_IDX                          0x14, 0x00f00000
#define R_VGA_GAIN_IDX                          0x18, 0x1f000000

#define ADDR_SLINK_DOWN_SAMPLE_FACTOR           (0x0258)
#define R_RX_DOWN_SAMPLE_FACTOR_S0              0x00, 0x0000007f
#define R_RX_DOWN_SAMPLE_FACTOR_S1              0x08, 0x00000f00
#define R_RX_DOWN_SAMPLE_FACTOR_S2              0x0c, 0x0000f000

#define ADDR_SLINK_TX                           (0x0280)
#define R_SLINK_PREAMBLE_LEN                    0x00, 0x0000ffff
#define R_SLINK_CODE_RATE                       0x10, 0x000f0000
#define R_SLINK_UPSAMPLER0_TYPE                 0x14, 0x00100000
#define R_SLINK_UPSAMPLER1_TYPE                 0x15, 0x00200000
#define R_SLINK_TX_UP_FACTOR0                   0x18, 0x0f000000
#define R_SLINK_TX_UP_FACTOR1                   0x1c, 0xf0000000

#define ADDR_SLINK_COMMON                       (0x0284)
#define R_SLINK_DE                              0x00, 0x00000001
#define R_SLINK_DOWNMODE                        0x01, 0x00000002
#if (FIRMWARE_VERSION == FPGA)
#define R_SLINK_PAPRMODE                        0x02, 0x00000004
#endif
#define R_SLINK_SYN_WORD_1                      0x08, 0x00000f00
#define R_SLINK_SYN_WORD_2                      0x0c, 0x0000f000
#define R_SLINK_SF                              0x10, 0x000f0000
#define R_SLINK_BW                              0x14, 0x00300000

#define ADDR_SLINK_RX_0                         (0x0288)
#define R_SLINK_SNR_TH                          0x00, 0x000000ff
#define R_SLINK_FACTOR_RESI_FREQ                0x08, 0x00000f00
#define R_SLINK_ALPHA_EST_ERR                   0x0c, 0x0000f000
#define R_SLINK_SYNCWRDCFOTRACKEN               0x10, 0x00010000
#define R_SLINK_DAGCEN                          0x11, 0x00020000
#define R_SLINK_CAD_EN                          0x12, 0x00040000
#define R_SLINK_PREAMBLECFOTRACKEN              0x13, 0x00080000
#define R_SLINK_DEMODCFOTRACKEN                 0x14, 0x00100000
#define R_SLINK_CAD_SNR_TH                      0x18, 0xff000000

#define ADDR_SLINK_RX_1                         (0x028C)
#define R_SLINK_AGC_REF                         0x00, 0x000000ff
#define R_SLINK_AGC_ALPHA                       0x08, 0x0000ff00
#define R_SLINK_DAGC_INIT_GAIN                  0x10, 0x000f0000
#define R_SLINK_CFOTRACKALPHA                   0x14, 0x00f00000

#define ADDR_SLINK_RX_STATUS                    (0x02C0)
#define R_SLINK_RX_SYNC_OK                      0x00, 0x00000001
#define R_SLINK_RX_DEM_STATE                    0x04, 0x000000f0
#define R_SLINK_CAD_PREAMBLE_COUNT              0x08, 0x0000ff00
#define R_SLINK_CAD_PREAMBLE_STATUS             0x10, 0xffff0000

#define ADDR_RFB_STATE                         (0x0198)
#define R_RFB_STATE                             0x08, 0x00000700
#endif /* _SLINK_REG_MAP_MODEM_H */
