/**************************************************************************//**
 * @file     rf_mcu.h
 * @version
 * @brief    header file for rf mcu
 *
 ******************************************************************************/

#ifndef __RF_MCU_H__
#define __RF_MCU_H__

#include "cm3_mcu.h"

#ifdef __cplusplus
extern "C"
{
#endif

#define RF_MCU_CTRL_BY_AHB              (0)
#define RF_MUC_CTRL_BY_SPI              (1)
#define CFG_RF_MCU_CTRL_TYPE            (RF_MCU_CTRL_BY_AHB)

void RfMcu_MemorySet(uint16_t sys_addr, const uint8_t *p_data, uint16_t data_length);
void RfMcu_MemoryGet(uint16_t sys_addr, uint8_t *p_data, uint16_t data_length);
void RfMcu_IoSet(uint8_t queue_id, const uint8_t *p_data, uint16_t data_length);
void RfMcu_IoGet(uint16_t queue_id, uint8_t *p_data, uint16_t data_length);
void RfMcu_HostCmdSet(uint8_t cmd);
void RfMcu_HostWakeUpMcu(void);
void RfMcu_HostModeEnable(void);
void RfMcu_HostModeDisable(void);
void RfMcu_HostResetMcu(void);
void RfMcu_InterruptDisableAll(void);
void RfMcu_InterruptEnableAll(void);
uint16_t RfMcu_InterruptEnGet(void);
void RfMcu_InterruptEnSet(uint16_t int_enable);
void RfMcu_InterruptClear(uint32_t value);
bool RfMcu_RxQueueCheck(void);
uint16_t RfMcu_RxQueueRead(uint8_t *rx_data, RF_MCU_RXQ_ERROR *rx_queue_error);
bool RfMcu_EvtQueueCheck(void);
uint16_t RfMcu_EvtQueueRead(uint8_t *evt, RF_MCU_RX_CMDQ_ERROR *rx_evt_error);
bool RfMcu_CmdQueueFullCheck(void);
RF_MCU_TX_CMDQ_ERROR RfMcu_CmdQueueSend(const uint8_t *cmd, uint32_t cmd_length);
RF_MCU_TXQ_ERROR RfMcu_TxQueueSend(uint8_t queue_id, const uint8_t *tx_data, uint32_t data_length);
RF_MCU_STATE RfMcu_McuStateRead(void);
void RfMcu_SysRdySignalWait(void);
uint8_t RfMcu_PowerStateCheck(void);
void RfMcu_SysInitNotify(void);
void RfMcu_DmaInit(void);
void RfMcu_RegSet(uint16_t reg_address, uint32_t value);
uint32_t RfMcu_RegGet(uint16_t reg_address);
void RfMcu_PmPageSelect(RF_MCU_PM_PAGE_SEL page);
void RfMcu_ImageLoad(const uint8_t *fw_image, uint32_t image_size);

#ifdef __cplusplus
}
#endif

#endif /* __RF_MCU_H__ */





