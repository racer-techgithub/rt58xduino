#ifndef __WIRING_H__
#define __WIRING_H__

#ifdef __cplusplus
#include "RT58xSerial.h"
#endif // !__cplusplus

#endif // !__WIRING_H__