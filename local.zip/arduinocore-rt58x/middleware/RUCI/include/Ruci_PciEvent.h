/******************************************************************************
*
* @File			Ruci_PciEvent.h
* @Version
* $Revision: 4235
* $Date: 2022-02-07
* @Brief
* @Note
* Copyright (C) 2019 Rafael Microelectronics Inc. All rights reserved.
*
******************************************************************************/
#ifndef _RUCI_PCI_EVENT_H
#define _RUCI_PCI_EVENT_H

#include "Ruci_Head.h"

#if (RUCI_ENABLE_PCI)

/******************************************************************************
* DEFINES
*****************************************************************************/

#pragma pack(push)
#pragma pack(1)
#define RUCI_PCI_EVENT_HEADER 0x16

// RUCI: CnfEvent --------------------------------------------------------------
#define RUCI_CNF_EVENT                          RUCI_NUM_CNF_EVENT, Ruci_ElmtType_CnfEvent, Ruci_ElmtNum_CnfEvent
#define RUCI_CODE_CNF_EVENT                     0x01
#define RUCI_LEN_CNF_EVENT                      6
#define RUCI_NUM_CNF_EVENT                      6
#define RUCI_PARA_LEN_CNF_EVENT                 3
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_CnfEvent[];
extern const uint8_t Ruci_ElmtNum_CnfEvent[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_CNF_EVENT {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         PciCmdHeader;
    uint8_t         PciCmdSubheader;
    uint8_t         Status;
} sRUCI_PARA_CNF_EVENT;

// RUCI: GetRegEvent -----------------------------------------------------------
#define RUCI_GET_REG_EVENT                      RUCI_NUM_GET_REG_EVENT, Ruci_ElmtType_GetRegEvent, Ruci_ElmtNum_GetRegEvent
#define RUCI_CODE_GET_REG_EVENT                 0x02
#define RUCI_LEN_GET_REG_EVENT                  7
#define RUCI_NUM_GET_REG_EVENT                  4
#define RUCI_PARA_LEN_GET_REG_EVENT             4
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_GetRegEvent[];
extern const uint8_t Ruci_ElmtNum_GetRegEvent[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_GET_REG_EVENT {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint32_t        Value;
} sRUCI_PARA_GET_REG_EVENT;

// RUCI: GetCrcReportEvent -----------------------------------------------------
#define RUCI_GET_CRC_REPORT_EVENT               RUCI_NUM_GET_CRC_REPORT_EVENT, Ruci_ElmtType_GetCrcReportEvent, Ruci_ElmtNum_GetCrcReportEvent
#define RUCI_CODE_GET_CRC_REPORT_EVENT          0x03
#define RUCI_LEN_GET_CRC_REPORT_EVENT           11
#define RUCI_NUM_GET_CRC_REPORT_EVENT           5
#define RUCI_PARA_LEN_GET_CRC_REPORT_EVENT      8
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_GetCrcReportEvent[];
extern const uint8_t Ruci_ElmtNum_GetCrcReportEvent[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_GET_CRC_REPORT_EVENT {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint32_t        CrcSuccessCount;
    uint32_t        CrcFailCount;
} sRUCI_PARA_GET_CRC_REPORT_EVENT;

// RUCI: DtmBurstTxDoneEvent ---------------------------------------------------
#define RUCI_DTM_BURST_TX_DONE_EVENT            RUCI_NUM_DTM_BURST_TX_DONE_EVENT, Ruci_ElmtType_DtmBurstTxDoneEvent, Ruci_ElmtNum_DtmBurstTxDoneEvent
#define RUCI_CODE_DTM_BURST_TX_DONE_EVENT       0x04
#define RUCI_LEN_DTM_BURST_TX_DONE_EVENT        3
#define RUCI_NUM_DTM_BURST_TX_DONE_EVENT        3
#define RUCI_PARA_LEN_DTM_BURST_TX_DONE_EVENT   0
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_DtmBurstTxDoneEvent[];
extern const uint8_t Ruci_ElmtNum_DtmBurstTxDoneEvent[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_DTM_BURST_TX_DONE_EVENT {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
} sRUCI_PARA_DTM_BURST_TX_DONE_EVENT;

// RUCI: GetRssiEvent ----------------------------------------------------------
#define RUCI_GET_RSSI_EVENT                     RUCI_NUM_GET_RSSI_EVENT, Ruci_ElmtType_GetRssiEvent, Ruci_ElmtNum_GetRssiEvent
#define RUCI_CODE_GET_RSSI_EVENT                0x05
#define RUCI_LEN_GET_RSSI_EVENT                 4
#define RUCI_NUM_GET_RSSI_EVENT                 4
#define RUCI_PARA_LEN_GET_RSSI_EVENT            1
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_GetRssiEvent[];
extern const uint8_t Ruci_ElmtNum_GetRssiEvent[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_GET_RSSI_EVENT {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         Rssi;
} sRUCI_PARA_GET_RSSI_EVENT;

// RUCI: GetPhyStatusEvent -----------------------------------------------------
#define RUCI_GET_PHY_STATUS_EVENT               RUCI_NUM_GET_PHY_STATUS_EVENT, Ruci_ElmtType_GetPhyStatusEvent, Ruci_ElmtNum_GetPhyStatusEvent
#define RUCI_CODE_GET_PHY_STATUS_EVENT          0x07
#define RUCI_LEN_GET_PHY_STATUS_EVENT           10
#define RUCI_NUM_GET_PHY_STATUS_EVENT           10
#define RUCI_PARA_LEN_GET_PHY_STATUS_EVENT      7
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_GetPhyStatusEvent[];
extern const uint8_t Ruci_ElmtNum_GetPhyStatusEvent[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_GET_PHY_STATUS_EVENT {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         WbRssi;
    uint8_t         IbRssi;
    uint8_t         LnaIdx;
    uint8_t         TiaIdx;
    uint8_t         VgaIdx;
    uint8_t         Lqi;
    uint8_t         Rssi;
} sRUCI_PARA_GET_PHY_STATUS_EVENT;

#pragma pack(pop)
#endif /* RUCI_ENABLE_PCI */
#endif /* _RUCI_PCI_EVENT_H */
