/******************************************************************************
*
* @File			Ruci_CmnHalCmd.c
* @Version
* $Revision:4235
* $Date: 2022-02-07
* @Brief
* @Note
* Copyright (C) 2019 Rafael Microelectronics Inc. All rights reserved.
*
*****************************************************************************/

/******************************************************************************
* INCLUDES
******************************************************************************/
#include "Ruci_CmnHalCmd.h"

#if (RUCI_ENDIAN_INVERSE)
#if (RUCI_ENABLE_CMN)

/******************************************************************************
* GLOBAL PARAMETERS
******************************************************************************/
// RUCI: SetAgc ----------------------------------------------------------------
const uint8_t Ruci_ElmtType_SetAgc[] = {
    1, 1, 1, 1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetAgc[] = {
    1, 1, 1, 1, 1, 1, 1
};

// RUCI: SetCalibrationEnable --------------------------------------------------
const uint8_t Ruci_ElmtType_SetCalibrationEnable[] = {
    1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetCalibrationEnable[] = {
    1, 1, 1, 1
};

// RUCI: SetCalibrationSetting -------------------------------------------------
const uint8_t Ruci_ElmtType_SetCalibrationSetting[] = {
    1, 1, 1, 1, 1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetCalibrationSetting[] = {
    1, 1, 1, 1, 1, 1, 2, 3
};

// RUCI: SetTxPower ------------------------------------------------------------
const uint8_t Ruci_ElmtType_SetTxPower[] = {
    1, 1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetTxPower[] = {
    1, 1, 1, 1, 1
};

// RUCI: GetTemperatureRpt -----------------------------------------------------
const uint8_t Ruci_ElmtType_GetTemperatureRpt[] = {
    1, 1, 1
};
const uint8_t Ruci_ElmtNum_GetTemperatureRpt[] = {
    1, 1, 1
};

// RUCI: GetVoltageRpt ---------------------------------------------------------
const uint8_t Ruci_ElmtType_GetVoltageRpt[] = {
    1, 1, 1
};
const uint8_t Ruci_ElmtNum_GetVoltageRpt[] = {
    1, 1, 1
};

#endif /* RUCI_ENABLE_CMN */
#endif /* RUCI_ENDIAN_INVERSE */
